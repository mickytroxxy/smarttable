import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { GlobalStyles } from '../styles/Global';
import { ToastAndroid,StatusBar,StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions,FlatList, ActivityIndicator,Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker,Polyline } from "react-native-maps";
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState,useRef } from "react";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import { db } from '../screens/service';
import geohash from "ngeohash";
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import MapViewDirections from 'react-native-maps-directions';
import { Container, Item, Input, Header, Content, ListItem, Left, Body, Right, Switch } from 'native-base';
const GOOGLE_MAPS_APIKEY = 'AIzaSyDjFgObNakHOgKAQyyBCQZSrmIH-26Ny4U';
import axios from 'axios';
let parallaxHeight = 0;
function TrackUserScreen({ route,navigation }) {
  const { userObj,requestObject } = route.params;
  const [userLocation,setUserLocation]=useState({latitude:userObj.latitude,longitude:userObj.longitude});
  const [initialState,setInitialState] = useState({distance:0,duration:0,show:false});
  const {height} = Dimensions.get("screen");
  return(
    <ParallaxScroll
      headerHeight={50}
      isHeaderFixed={false}
      parallaxHeight={height-220}
      fadeOutParallaxBackground={true}
      renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue}/>}
      renderParallaxForeground={({ animatedValue }) => <Foreground setInitialState={setInitialState} navigation={navigation} userObj={userObj} requestObject={requestObject} setLocation={setUserLocation} />}
      parallaxBackgroundScrollSpeed={5}
      useNativeDriver={true}
      parallaxForegroundScrollSpeed={2.5}
      showsVerticalScrollIndicator={false}
      >
      {initialState.show&&(<ParallaxBody navigation={navigation} userObj={userObj} userLocation={userLocation} initialState={initialState}/>)}
    </ParallaxScroll>
  )
}
const Background = props =>{
  return(
    <View style={GlobalStyles.ProfileHeader}>
        
    </View>
  )
}
const Foreground = props =>{
  const mapView = React.useRef();
  const [region,setRegion] = React.useState(null)
  React.useEffect(() => {
    props.navigation.addListener("focus", async() => {
      db.collection("users").doc(props.userObj.phoneNumber).onSnapshot(function(doc) {
        navigator.geolocation.getCurrentPosition(position => {
          const { latitude, longitude } = position.coords;
          setRegion({...region,
            myLocation:{latitude:latitude,longitude:longitude},
            userLocation:{latitude:doc.data().latitude,longitude:doc.data().longitude}
          })
        },error => {
          alert(error.message)
        },{ 
          enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
      }); 
    });
  }, [region]);
  if(region){
    return(
      <View style={GlobalStyles.ProfileHeader}>
        <MapView 
            ref = {mapView}
            style={styles.mapStyle}
            type region={{
              latitude: (region.myLocation.latitude + region.userLocation.latitude) / 2,
              longitude: (region.myLocation.longitude + region.userLocation.longitude) / 2,
              latitudeDelta: Math.abs(region.myLocation.latitude - region.userLocation.latitude) * 2,
              longitudeDelta: Math.abs(region.myLocation.longitude - region.userLocation.longitude) * 2
            }} showsCompass={true} rotateEnabled={false} showsUserLocation={false} moveOnMarkerPress={false}
            >
            <MapViewDirections
                origin={region.myLocation}
                destination={region.userLocation}
                apikey={GOOGLE_MAPS_APIKEY}
                strokeWidth={3}
                strokeColor="#2471a3"
                mode="DRIVING"
                optimizeWaypoints={true}
                resetOnChange={false}
                onReady={result=>{
                  if (parseFloat(result.duration)!=0) {
                   props.setInitialState({duration:parseFloat(result.duration),distance:parseFloat(result.distance).toFixed(2),show:true}); 
                  }
                }}
              />
            <Marker backgroundColor="pink" coordinate={{ latitude: region.myLocation.latitude, longitude: region.myLocation.longitude }}/>
            <Marker
                backgroundColor="pink"
                coordinate={{
                  latitude: region.userLocation.latitude,
                  longitude: region.userLocation.longitude
                }}
              >
              <FontAwesome name="heart" color="tomato" size={24}></FontAwesome>
            </Marker>
          </MapView>
      </View>
    )
  }else{
    return(
      <View style={{flex:1,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
        <ActivityIndicator size={36} color="large"></ActivityIndicator>
      </View>
    )
  }
}
const ParallaxBody = props =>{
  const [addressDetails,setAddressDetails]=useState({
    address:'',distance:props.initialState.distance,prevLocation:props.userLocation,lastStamp:Date.now(),
    duration:props.initialState.duration,speed:(props.initialState.distance / props.initialState.duration)
  });
  React.useEffect(() => {
    //props.navigation.addListener("focus", async() => {
      db.collection("users").doc(props.userObj.phoneNumber).onSnapshot(function(doc) {
        const result = doc.data();
        navigator.geolocation.getCurrentPosition(position => {
          const { latitude, longitude } = position.coords;
          reverseGeoCode(result.latitude,result.longitude,(address)=>{
            if (addressDetails.prevLocation.latitude!=result.latitude) {
              var distance = addressDetails.distance - getDistance(latitude,longitude,result.latitude,result.longitude);
              var minSpent = (Date.now() - addressDetails.lastStamp) / 60000;
              var speed = distance / minSpent;
              var duration = (((getDistance(latitude,longitude,result.latitude,result.longitude)) / speed) * 60).toFixed(1);
            }else{
              var distance = addressDetails.distance;
              var speed = addressDetails.speed;
              var duration = addressDetails.duration;
            }
            setAddressDetails({...addressDetails,distance:distance,address:address,duration:duration,speed:speed,lastStamp:Date.now()});
          });
        },error => {
          alert(error.message)
        },{ 
          enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
      }); 
    //});
  }, [addressDetails.distance]);
  if (props.initialState.show) {
    return(
      <Animatable.View style={GlobalStyles.MapFooter} animation="fadeInUpBig" duration={1000} useNativeDriver={true}>
        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
          <TouchableOpacity style={{flex:1,flexDirection:'row'}}>
            <FontAwesome name="ellipsis-h" color="#c792f5" size={24}></FontAwesome>
          </TouchableOpacity>
        </View>
        <View style={GlobalStyles.mapFooterHeader}>
          <Text style={{fontFamily:'sans-serif-thin',fontSize:13,color:'#353434'}}>Track {props.userObj.fname}'s Location</Text>
          <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.7}}>
            <Left>
            <FontAwesome name="map-marker" size={24} style={{marginTop:10}} color="#7395f6"></FontAwesome>
            </Left>
            <Body>
              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>{addressDetails.address}</Text>
            </Body>
            <Right>
              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{parseFloat(addressDetails.distance).toFixed(1)}km</Text>
            </Right>
          </ListItem>
          <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.7,marginTop:-20,}}>
            <Left>
            <MaterialIcons name="timer" size={24} style={{marginTop:10}} color="orange"></MaterialIcons>
            </Left>
            <Body>
              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold',marginTop:10}}>
                ARRIVES IN
              </Text>
            </Body>
            <Right>
              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',marginTop:10}}>{addressDetails.duration.toFixed(2)}mins</Text>
            </Right>
          </ListItem>
        </View>
      </Animatable.View>
    )
  }else{
    return(
      <View style={{flex:1,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
        <ActivityIndicator size={36} color="large"></ActivityIndicator>
      </View>
    )
  }
}
function reverseGeoCode(latitude,longitude,cb){
  axios.request({
    method: 'post',
    url: `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&sensor=true&key=${GOOGLE_MAPS_APIKEY}`,
  }).then((response) => {
    cb(response.data.results[1].formatted_address);
  }).catch((e) => {
    alert(e);
  });
}
function getDistance(lat1, lon1, lat2, lon2) {
  var R = 6371; 
  var dLat = toRad(lat2-lat1);
  var dLon = toRad(lon2-lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c;
  return d;
}
function toRad(Value){
  return Value * Math.PI / 180;
}
export default TrackUserScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
  }
});
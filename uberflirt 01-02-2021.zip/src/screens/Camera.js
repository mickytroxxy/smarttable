import React, { useEffect, useState } from 'react';
import {StyleSheet, View, Text, Dimensions, Platform,TouchableOpacity,ActivityIndicator } from 'react-native';
import { Camera } from 'expo-camera';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Feather from "react-native-vector-icons/Feather";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import * as Permissions from 'expo-permissions';
import * as ImagePicker from 'expo-image-picker';
export default function CameraScreen({route,navigation}) {
  const { mediaObj } = route.params;
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [camera, setCamera] = useState(null);
  const [type, setType] = useState(!mediaObj.isSelfie?Camera.Constants.Type.back:Camera.Constants.Type.front);
  const [flashMode,setFlashMode]=useState(Camera.Constants.FlashMode.off);
  const [image, setImage] = useState(null);
  // Screen Ratio and image padding
  const [imagePadding, setImagePadding] = useState(0);
  const [ratio, setRatio] = useState('4:3');  // default is 4:3
  const { height, width } = Dimensions.get('window');
  const screenRatio = height / width;
  const [isRatioSet, setIsRatioSet] =  useState(false);

  // on screen  load, ask for permission to use the camera
  useEffect(() => {
    async function getCameraStatus() {
      const { status } = await Permissions.askAsync(Permissions.CAMERA);
      setHasCameraPermission(status == 'granted');
    }
    getCameraStatus();
  }, []);

  // set the camera ratio and padding.
  // this code assumes a portrait mode screen
  const prepareRatio = async () => {
    let desiredRatio = '4:3';  // Start with the system default
    // This issue only affects Android
    if (Platform.OS === 'android') {
      const ratios = await camera.getSupportedRatiosAsync();
      let distances = {};
      let realRatios = {};
      let minDistance = null;
      for (const ratio of ratios) {
        const parts = ratio.split(':');
        const realRatio = parseInt(parts[0]) / parseInt(parts[1]);
        realRatios[ratio] = realRatio;
        const distance = screenRatio - realRatio; 
        distances[ratio] = realRatio;
        if (minDistance == null) {
          minDistance = ratio;
        } else {
          if (distance >= 0 && distance < distances[minDistance]) {
            minDistance = ratio;
          }
        }
      }
      desiredRatio = minDistance;
      //  calculate the difference between the camera width and the screen height
      const remainder = Math.floor(
        (height - realRatios[desiredRatio] * width) / 2
      );
      // set the preview padding and preview ratio
      setImagePadding(remainder / 2);
      setRatio(desiredRatio);
      // Set a flag so we don't do this 
      // calculation each time the screen refreshes
      setIsRatioSet(true);
    }
  };

  // the camera must be loaded in order to access the supported ratios
  const setCameraReady = async() => {
    if (!isRatioSet) {
      await prepareRatio();
    }
  };
  const takePicture = async () => {
    if (camera) {
      const data = await camera.takePictureAsync(null);
      savePhoto(data.uri)
    }
  }
  const pickImage = async () => {
    if(!mediaObj.isSelfie){
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: mediaObj.type=="avatar"?[1, 1]:null,
        quality: 0.7,
      });
      if (!result.cancelled) {
        savePhoto(result.uri)
      }
    }
  };
  const savePhoto = (path) =>{
    navigation.navigate("SavePhotoScreen",{path:path,mediaObj:mediaObj});
  }
  if (hasCameraPermission === null) {
    return (
      <View style={styles.information}>
        <ActivityIndicator size="large" color="#757575"></ActivityIndicator>
      </View>
    );
  } else if (hasCameraPermission === false) {
    return (
      <View style={styles.information}>
        <Text>No access to camera</Text>
      </View>
    );
  } else {
    return (
      <View style={styles.container}>
        <Camera
          type={type} whiteBalance={'auto'} flashMode={flashMode}
          style={[styles.cameraPreview, {marginTop: imagePadding, marginBottom: imagePadding}]}
          onCameraReady={setCameraReady}
          ratio={ratio}
          ref={(ref) => {
            setCamera(ref);
          }}>
            <View style={{flex: 1,flexDirection:'row', padding:10}}>
          <View style={{flex:2}}>
            <TouchableOpacity onPress={()=>{navigation.goBack()}}>
                <MaterialIcons name="highlight-off" size={36} color="#fff" alignSelf="center"></MaterialIcons>
              </TouchableOpacity>
          </View>
          <View style={{flex:2}}>
            <TouchableOpacity style={{flexDirection:'row-reverse'}} onPress={()=>{setFlashMode(flashMode === 0? 1: 0)}}>
              {flashMode===0?(
                <MaterialIcons name="flash-on" size={36} color="#fff" alignSelf="center"></MaterialIcons>
              ):(
                <MaterialIcons name="flash-off" size={36} color="#fff" alignSelf="center"></MaterialIcons>
              )}
            </TouchableOpacity>
          </View>
        </View>
          <View style={styles.cameraActionView}>
            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
              <TouchableOpacity onPress={()=>{pickImage()}}><FontAwesome name="image" size={36} color="#fff" alignSelf="center"></FontAwesome></TouchableOpacity>
            </View>
            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
              <TouchableOpacity onPress={()=>{takePicture()}}>
                <MaterialIcons name="radio-button-checked" size={100} color="#fff" alignSelf="center"></MaterialIcons>
              </TouchableOpacity>
            </View>
            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
              {!mediaObj.isSelfie?(
                <TouchableOpacity onPress={ () => {setType(type === Camera.Constants.Type.back? Camera.Constants.Type.front: Camera.Constants.Type.back);}}>
                  <MaterialIcons name="switch-camera" size={40} color="#fff" alignSelf="center"></MaterialIcons>
                </TouchableOpacity>
              ):(
                <TouchableOpacity>
                  <MaterialIcons name="sync" size={40} color="#757575" alignSelf="center"></MaterialIcons>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </Camera>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  information: { 
    flex: 1,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
  },
  cameraPreview: {
    flex: 1,
  },cameraActionView:{
    justifyContent:'center',
    flexDirection:'row'
  },
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    width: '100%', height: '100%',
  },
});
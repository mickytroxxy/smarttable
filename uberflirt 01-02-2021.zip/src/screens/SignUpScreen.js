import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React,{useState} from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet,ToastAndroid, Platform, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import * as Animatable from 'react-native-animatable'; //061 746 2677 dayalagovender@gmail.com
import { AuthContext } from "../components/context";
import { db } from '../screens/service';
import geohash from "ngeohash";
import SpinnerScreen from '../screens/SpinnerScreen';
let parallaxHeight = 0;
const SignUpScreen = ({navigation}) =>{
  const {height} = Dimensions.get("screen");
  parallaxHeight = parseInt((0.05 * parseFloat(height)).toFixed(0));
  const [parallaxH,setParallaxH]= useState(parallaxHeight);
  return(
    <ParallaxScroll
      headerHeight={50}
      isHeaderFixed={false}
      parallaxHeight={parallaxH}
      fadeOutParallaxBackground={true}
      renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue}/>}
      renderParallaxForeground={({ animatedValue }) => <Foreground navigation={navigation}/>}
      parallaxBackgroundScrollSpeed={5}
      useNativeDriver={true}
      parallaxForegroundScrollSpeed={2.5}
      showsVerticalScrollIndicator={false}
      >
      <ParallaxBody navigation={navigation} setParallaxH={setParallaxH} />
    </ParallaxScroll>
  )  
};
const Background = props =>{
  return(
    <View></View>
  )
}
const Foreground = props =>{
  return(
    <View></View>
  )
}
const ParallaxBody = props =>{
  const [data,setData]=React.useState({
    fname: '',password:'',check_textInputChange:false,secureTextEntry:true,confirm_password:'',phone_number:'',check_phoneInputChange:false
  })
  const { setUserTokenFn } = React.useContext(AuthContext);
  const [location, setLocation] = React.useState({currentLongitude: 0,currentLatitude: 0,latitudeDelta: 10,longitudeDelta: 10});
  const [loading,setIsLoading]=React.useState({
      isLoading:false, text:''
  })
  const navigation = props.navigation;
  React.useEffect(() => {
    navigator.geolocation.getCurrentPosition(position => {
      setLocation({...location,currentLongitude: position.coords.longitude,currentLatitude: position.coords.latitude});
    },error => alert(error.message),{ 
      enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    );
  }, []);
  const textInputChange = (val,valType)=>{
      if(val.length!=0){
          if(valType=="fullName"){
              setData({ ...data, fname: val, check_textInputChange: true });
          }else if(valType=="password"){
              setData({...data, password:val})
          }else if (valType=="phoneNumber") {
              setData({...data, phone_number:val, check_phoneInputChange:true})
          }
      }else{
          if(valType=="fullName"){
              setData({ ...data, fname: val, check_textInputChange: false });
          }else if(valType=="password"){
              setData({...data, password:val})
          }else if (valType=="phoneNumber") {
              setData({...data, phone_number:val, check_phoneInputChange:false})
          }
      }
  }
  const updateSecureTextEntry = ()=>{
      setData({
          ...data,
          secureTextEntry: !data.secureTextEntry,
      })
  }
  const saveUser = (fname, phoneNumber, password)=>{
    if (fname.length > 5 && phoneNumber.length > 8) {
      if (password.length > 5) {
        setIsLoading({...loading,isLoading: true,text:'Creating your account, Please wait...'})
        const hash = geohash.encode(location.currentLatitude, location.currentLongitude);
        db.collection("users").where("phoneNumber", "==", phoneNumber).get().then(querySnapshot => {
          const data = querySnapshot.docs.map(doc => doc.data());
          if(data.length==0){
            db.collection("users").doc(phoneNumber).set({fname: fname, phoneNumber: phoneNumber,password: password,latitude:location.currentLatitude,longitude:location.currentLongitude,geohash:hash,avatar:"",balance:0,availability:'FREE',notificationToken:'' }).then(function() {
              setUserTokenFn(phoneNumber);
              setIsLoading({...loading,isLoading: false,text:''})
            }).catch(function(error) {});
          }else{
            db.collection("users").doc(phoneNumber).update({fname: fname,password: password,latitude:location.currentLatitude,longitude:location.currentLongitude,geohash:hash,availability:'FREE',notificationToken:''}).then(function() {}).catch(function(error) {
              setUserTokenFn(phoneNumber);
              setIsLoading({...loading,isLoading: false,text:''})
            });
          } 
        });
      } else {
        showToast("Password field should be at least 6 characters long!");
      }
    } else {
      showToast("Invalid Full Name or Invalid phone number!");
    }
  }
  const showToast = (message)=>{
    ToastAndroid.show(message, ToastAndroid.SHORT); 
  }
  return (
    <Animatable.View animation="fadeInUpBig" useNativeDriver={true} style={styles.footer}>
      <Text style={styles.newLabel}>FULL NAME</Text>
      <View style={styles.action}>
        <FontAwesome name="user-o" color="#e2cdf7" size={20}></FontAwesome>
        <TextInput
          style={styles.textInput}
          placeholder="FULL NAME"
          autoCapitalize="none"
          onChangeText={val => textInputChange(val, "fullName")}
          onFocus={()=>{props.setParallaxH(0)}}
        ></TextInput>
        {data.check_textInputChange ? (
          <Animatable.View animation="bounceIn">
            <Feather name="check-circle" color="green" size={20}></Feather>
          </Animatable.View>
        ) : null}
      </View>

      <Text style={styles.newLabel}>PHONE NUMBER</Text>
      <View style={styles.action}>
        <Feather name="phone" color="#e2cdf7" size={20}></Feather>
        <TextInput
          style={styles.textInput}
          placeholder="Phone number"
          autoCapitalize="none"
          keyboardType={"phone-pad"}
          onChangeText={val => textInputChange(val, "phoneNumber")}
          onFocus={()=>{props.setParallaxH(0)}}
        ></TextInput>
        {data.check_phoneInputChange ? (
          <Animatable.View animation="bounceIn">
            <Feather name="check-circle" color="green" size={20}></Feather>
          </Animatable.View>
        ) : null}
      </View>

      <Text style={styles.newLabel}>PASSWORD</Text>
      <View style={styles.action}>
        <Feather name="lock" color="#e2cdf7" size={20}></Feather>
        <TextInput
          style={styles.textInput}
          placeholder="Your Password"
          autoCapitalize="none"
          secureTextEntry={data.secureTextEntry ? true : false}
          onChangeText={val => textInputChange(val, "password")}
          onFocus={()=>{props.setParallaxH(0)}}
        ></TextInput>
        <TouchableOpacity onPress={() => updateSecureTextEntry()}>
          {data.secureTextEntry ? (
            <Feather name="eye-off" color="grey" size={20}></Feather>
          ) : (
            <Feather name="eye" color="grey" size={20}></Feather>
          )}
        </TouchableOpacity>
      </View>
      <View style={styles.button}>
        <TouchableOpacity
          onPress={() => {
            saveUser(data.fname, data.phone_number, data.password);
            props.setParallaxH(parallaxHeight);
          }}
        >
          <LinearGradient
            colors={["#e44528","#d6a8e7","#f3bf4f"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }}
            style={styles.signIn}
          >
            <Text
              style={
                ([styles.textSign],
                { color: "#fff", fontWeight: "bold", fontSize: 20 })
              }
            >
              Create Account
            </Text>
          </LinearGradient>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {navigation.goBack();props.setParallaxH(parallaxHeight)}}
          style={
            {
              borderColor: "#009387",
              borderWidth: 1,
              marginTop: 15,
              borderRadius: 15,
              width: Dimensions.get("screen").width - 20,
              height: 50,
              justifyContent: "center",
              alignItems: "center",
            }
          }
        >
          <Text style={[styles.textSign,{fontSize:14,color:'#757575'}]}>Already Have An Account</Text>
        </TouchableOpacity>
      </View>
      {loading.isLoading?(
        <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
      ):null}
    </Animatable.View>
  );
}
export default SignUpScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#009387"
  },
  header: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 50
  },
  footer: {
    flex: 3,
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
    marginLeft: 5,
    marginRight: 5,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.9,
    shadowRadius: 2.84,
    elevation: 5,
    paddingBottom:50,
  },
  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 30
  },
  text_footer: {
    color: "#05375a",
    fontSize: 18
  },
  action: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f2f2f2",
    paddingBottom: 5
  },
  actionError: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#FF0000",
    paddingBottom: 5
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : -3,
    paddingLeft: 10,
    color: "#05375a"
  },
  errorMsg: {
    color: "#FF0000",
    fontSize: 14
  },
  button: {
    alignItems: "center",
    marginTop: 50
  },
  signIn: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 15
  },
  signUp: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold"
  },
  newLabel: {
    marginTop: 15,
    color: "#009387",
    fontWeight: "bold"
  }
});
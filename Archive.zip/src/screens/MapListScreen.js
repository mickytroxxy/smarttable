import React from 'react';
import { SafeAreaView } from 'react-navigation';
//import { StyleSheet, Text, View, SafeAreaView, Button } from 'react-native';

const MapListScreen = ({navigation}) =>{
    return(
        <SafeAreaView forceInset={{top:'always'}}>

        </SafeAreaView>
    )
};
export default MapListScreen;

import useUsers from './usersHook';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Text, View, Image, Dimensions, ActivityIndicator,TextInput } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker } from "react-native-maps";
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Feather from "react-native-vector-icons/Feather";
import {MaterialIcons } from "@expo/vector-icons";
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import { Item, Input, ListItem, Left, Body, Right, Button } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { getRequests } from '../screens/MainContext';
import {TouchableOpacity} from 'react-native-gesture-handler'
import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';
import { db,storage } from '../screens/service';
import axios from 'axios';
import * as Font from 'expo-font';
import ModalScreen from './Modal';
const RootStack = createDrawerNavigator();
let myObject, users,usersArray=null,searchedUsers=null,showToast,startCoords,confirmDialog,globalUserToken,searchedLocation=false,getUsersByLocation;
let parallaxHeight = 0;
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});
function MapViewScreen({ navigation }) {
  const {height} = Dimensions.get("screen");
  parallaxHeight = parseInt((0.575 * parseFloat(height)).toFixed(0));
  const [usersNew,startCoordsNew,confirmDialogNew,testTokenNew,showToastNew,getUsersByLocationNew,updateMyLocation,getRequests] = useUsers();
  users=usersNew;startCoords=startCoordsNew;confirmDialog=confirmDialogNew;globalUserToken=testTokenNew;getUsersByLocation=getUsersByLocationNew,showToast=showToastNew;
  const [parallaxH,setParallaxH]= useState(parallaxHeight);
  const [usersLocation, setUsersLocation] = React.useState([{latitude: 0,longitude: 0,latitudeDelta: 10,longitudeDelta: 10, phoneNumber:''}]);
  const [location, setLocation] = React.useState({currentLongitude: 0,currentLatitude: 0,latitudeDelta: 10,longitudeDelta: 10});
  const [modalVisible, setModalVisible] = useState(false);
  const [modalAttr, setModalAttr] = useState({toOpen:'REPAY CREDITS',headerText:'REPAY CREDITS',values:''});
  const mechantId = 15759218;
  const return_url = 'http://165.227.73.148:3500/payFastSuccess/';
  const cancel_url = 'http://165.227.73.148:3500/failedUser/';
  function closeModal() {
    setModalVisible(false);
  }
  React.useEffect(() => {
    if(startCoords){
      setLocation({...location,currentLongitude: startCoords.longitude,currentLatitude: startCoords.latitude});
      setUsersLocation(users);
      if(globalUserToken){
        const myIndex = users.map(function(e) { return e.phoneNumber; }).indexOf(globalUserToken)
        myObject = users[myIndex];
        updateMyLocation(globalUserToken);
        registerForPushNotificationsAsync();
        setTimeout(() => {
          checkIfIOwe(globalUserToken);
        }, 15000);
      }
    }
  }, [startCoords,users]);
  const checkIfIOwe =(globalUserToken)=>{
    getUserBalance(globalUserToken, (myBalance)=>{
      myBalance = parseFloat(myBalance)
      if(myBalance < 0){
        myBalance = (0 - myBalance);
        setModalAttr({...modalAttr,values:myBalance})
        setModalVisible(true);
      }
    })
  }
  const callback = async (amount,status)=> {
    const baseUrl = "https://www.payfast.co.za/eng/process?cmd=_paynow&receiver="+mechantId+"&item_name=uberflirt credit purchase&item_description=uberFlirt credit purchase&amount="+amount+"&return_url="+encodeURIComponent(return_url)+"&cancel_url="+encodeURIComponent(cancel_url)+""
    if(amount!=null && amount>=10){
      navigation.navigate("WebBrowser",{amount:amount,userObj:myObject,baseUrl:baseUrl});
    }else{
      alert('Invalid amount!')
    }
  }
  return(
    <ParallaxScroll
      headerHeight={50}
      isHeaderFixed={false}
      parallaxHeight={parallaxH}
      fadeOutParallaxBackground={true}
      renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue}/>}
      renderParallaxForeground={({ animatedValue }) => <Foreground navigation={navigation} usersLocation={usersLocation} location={location}/>}
      parallaxBackgroundScrollSpeed={5}
      useNativeDriver={true}
      parallaxForegroundScrollSpeed={2.5}
      showsVerticalScrollIndicator={false}
      >
      <ParallaxBody navigation={navigation}setParallaxH={setParallaxH} parallaxH={parallaxH} />
      <ModalScreen isVisible={modalVisible} closeModal={closeModal} callback={callback} modalAttr={modalAttr}/>
    </ParallaxScroll>
  )
}
function  getUserBalance(user,cb) {
    db.collection("users").where("phoneNumber", "==", user).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data[0].balance);
    });
}
const registerForPushNotificationsAsync = async()=> {
  let token;
  if (Constants.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      alert('Failed to get push token for push notification!');
      return;
    }
    token = (await Notifications.getExpoPushTokenAsync()).data;
    db.collection("users").doc(globalUserToken).update({notificationToken:token}).then(function() {}).catch(function(error) {});
  } else {
    alert('Must use physical device for Push Notifications');
  }

  if (Platform.OS === 'android') {
    Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
    });
  }

  return token;
}
const Background = props =>{
    return(
        <View style={GlobalStyles.ProfileHeader}>
            
        </View>
    )
}
const Foreground = props =>{
  let location = props.location;
  let usersLocation = props.usersLocation;
  if(searchedLocation){
    location = searchedLocation;
  }else{
    location = location;
  }
  return(
    <View style={GlobalStyles.ProfileHeader}>
      <Animatable.View animation="slideInRight" duration={2000} useNativeDriver={true} style={GlobalStyles.floatBtnsView}>
        <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={()=>{props.navigation.openDrawer()}}>
          <MaterialIcons name="menu" size={22} color="teal" alignSelf="center"></MaterialIcons>
        </TouchableOpacity>
        <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={() => {if(users.length>0){props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:myObject})}}}>
          <MaterialIcons name="account-circle" size={24} color="green" alignSelf="center"></MaterialIcons>
        </TouchableOpacity>
        <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={()=>{if(users.length>0){props.navigation.navigate("PostScreen",{myToken: globalUserToken})}}}>
          <Feather name="instagram" size={24} color="orange" alignSelf="center"></Feather>
        </TouchableOpacity>
        {getRequests(globalUserToken)!=0?(
          <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={()=>{if(users.length>0){props.navigation.navigate("NotificationScreen",{myToken: globalUserToken})}}}>
            <MaterialIcons name="notifications-active" size={24} color="tomato" alignSelf="center"></MaterialIcons>
          </TouchableOpacity>
        ):(
          <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={()=>{if(users.length>0){props.navigation.navigate("NotificationScreen",{myToken: globalUserToken})}}}>
            <MaterialIcons name="notifications-none" size={24} color="#757575" alignSelf="center"></MaterialIcons>
          </TouchableOpacity>
        )}
      </Animatable.View>
      <MapView 
        style={styles.mapStyle}
        type region={{
          latitude: location.currentLatitude,
          longitude: location.currentLongitude,
          latitudeDelta: 0.3,
          longitudeDelta: 0.3
        }} showsCompass={true} rotateEnabled={false} showsUserLocation={false} moveOnMarkerPress={false}
        >
        <Marker backgroundColor="pink" coordinate={{ latitude: location.currentLatitude, longitude: location.currentLongitude }}/>
        {usersLocation.map((item, i) =>  {
          if(item.phoneNumber!=globalUserToken){
            return (
              <Marker key={i}
                backgroundColor="pink"
                coordinate={{
                latitude: item.latitude,
                longitude: item.longitude
                }}
                onPress={() => props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:item})}
              >
                <FontAwesome name="heart" color="tomato" size={12}></FontAwesome>
              </Marker>
            );
          }
        })}
      </MapView>
    </View>
  )
}
const ParallaxBody = props =>{
  const [predictions,setPredictions]=useState({
    predictionsArray:null,
    showPredictions:false,
  });
  const startPlaceSearch = (key_word) =>{
    if(key_word.length>2){
      axios
      .request({
        method: 'post',
        url: `https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyDjFgObNakHOgKAQyyBCQZSrmIH-26Ny4U&input=${key_word}`,
      })
      .then((response) => {
        setPredictions({...predictions, predictionsArray:response.data.predictions,showPredictions:true});
      })
      .catch((e) => {
        alert(e.response);
      });
    }else{
      setPredictions({...predictions, predictionsArray:null,showPredictions:false})
    }
  }
  const displaySearchedLocation = (place_id)=>{
    axios.request({
      method: 'post',
      url: `https://maps.googleapis.com/maps/api/place/details/json?placeid=${place_id}&key=AIzaSyDjFgObNakHOgKAQyyBCQZSrmIH-26Ny4U`,
    }).then((response) => {
      searchedLocation = {currentLatitude:response.data.result.geometry.location.lat,currentLongitude:response.data.result.geometry.location.lng};
      searchUserByLocation(searchedLocation.currentLatitude,searchedLocation.currentLongitude);
    }).catch((e) => {
      alert(e);
    });
  }
  const searchUserByLocation = (latitude,longitude) =>{
    getUsersByLocation(latitude,longitude,function(usersSearched){
      searchedUsers = usersSearched;
      hideSearchView();
    })
  }
  const refreshPage = ()=>{
    navigator.geolocation.getCurrentPosition(position => {
      const { latitude, longitude } = position.coords;
      searchedLocation = {currentLatitude:latitude,currentLongitude:longitude};
      searchUserByLocation(latitude,longitude);
    },error => {},{ 
      enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    );
  }
  if(searchedLocation){
    var nearByUsers = searchedUsers;
  }else{
    var nearByUsers = users;
  }
  const hideSearchView = ()=>{
    props.setParallaxH(parallaxHeight);
    setPredictions({...predictions, predictionsArray:null,showPredictions:false})
  }

  const [fontsLoaded,setFontsLoaded]=useState(false);
  let customFonts = {
    'MontserratAlternates-Light': require('..//../fonts/MontserratAlternates-Light.otf'),
  };
  const loadFontsAsync = async ()=> {
    await Font.loadAsync(customFonts);
    setFontsLoaded(true);
  }
  let fontFamily = 'sans-serif-thin';
  if(fontsLoaded){
    fontFamily = 'MontserratAlternates-Light';
  }

  React.useEffect(()=>{
    loadFontsAsync();
  },[])
  if(nearByUsers!=null){
    return(
      <Animatable.View style={GlobalStyles.MapFooter} animation="fadeInUpBig" duration={2000} useNativeDriver={true}>
          <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
            {props.parallaxH==parallaxHeight?(
              <Button onPress={()=>hideSearchView()} style={{alignSelf:'center',backgroundColor:'#fff',height:30,elevation:0}}>
                <FontAwesome backgroundColor="#fff" style={{alignSelf:'center',alignItems:'center',alignContent:'center'}} name="ellipsis-h" color="#757575" size={30}></FontAwesome>
              </Button>
            ):(
              <Button onPress={()=>hideSearchView()} style={{alignSelf:'center',backgroundColor:'#fff',height:36,elevation:0,width:100,left:42}}>
                <Feather backgroundColor="#fff" name="chevrons-down" color="green" size={24}></Feather>
              </Button>
            )}
          </View>
          <View style={GlobalStyles.mapFooterHeader}>
            <Text style={{fontFamily:'sans-serif-thin',fontSize:13,color:'#353434'}}>Nice to see you!</Text>
            <Text style={{fontFamily:'sans-serif-condensed',fontSize:22,color:'#05375a',fontWeight:'bold',marginTop:10,}}>Where Could Be Your Crush?</Text>
          </View>
          <View style={{marginTop:10,height:40}}>
                <Grid style={GlobalStyles.searchInputHolder}>
                  <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                      <FontAwesome name="search" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                  </Col>
                  <Col style={{justifyContent:'center'}}>
                      <TextInput
                        placeholder="Give us a location"
                        autoCapitalize="none"
                        onFocus={()=>props.setParallaxH(0)} onChangeText={(val)=>startPlaceSearch(val)}
                        //onBlur={()=>hideSearchView()}
                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                      />
                  </Col>
                </Grid>
          </View>
          {/**<Item noBorder rounded style={GlobalStyles.searchInputText}><FontAwesome name="search" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome><Input placeholder='Give us a location' style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14}} onFocus={()=>props.setParallaxH(0)} onChangeText={(val)=>startPlaceSearch(val)} /></Item> */}
            {!predictions.showPredictions ? (
              <View style={{marginTop:15}}>
                  {
                    nearByUsers.length>0?
                    nearByUsers.map((user, i) =>  {
                      if(user.phoneNumber!=globalUserToken){
                        return (
                          <Animatable.View animation="slideInUp" key={i} duration={1000} useNativeDriver={true}>
                            <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon onPress={() => {props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:user});hideSearchView()}}>
                              <Left><Image source={{uri: user.avatar!=""?user.avatar:'https://picsum.photos/400/400'}} style={GlobalStyles.listAvatar} ></Image></Left>
                              <Body>
                                <Text style={{color:'#2a2828',fontFamily:fontFamily}}>{user.fname}</Text>
                              </Body>
                              <Right>
                                <Text style={{color:'#2a2828',fontFamily:fontFamily}}>{getDistance(startCoords.latitude, startCoords.longitude, user.latitude, user.longitude).toFixed(2)}km</Text>
                              </Right>
                            </ListItem>
                          </Animatable.View>
                        );
                      }
                    }):
                    (
                      [{key:1}].map((user, i) =>  {
                        return (
                          <View style={{flex:1,alignContent:'center',alignItems:'center',justifyContent:'center'}} key={i}>
                            <Text style={{fontFamily:fontFamily,fontSize:18,color:'#05375a',fontWeight:'bold',marginTop:10,}}>We couldn't find anyone around!</Text>
                            <TouchableOpacity onPress={()=>{refreshPage()}} style={{alignContent:'center',alignItems:'center',justifyContent:'center',marginTop:10}}>
                              <FontAwesome name="repeat" size={36} color="#757575"></FontAwesome>
                            </TouchableOpacity>
                          </View>
                        );
                      })
                    )
                  }
              </View>
            ):(
              <View style={{marginTop:15,}}>
                {predictions.predictionsArray.map((item, i) =>  {
                  return (
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} key={i} icon onPress={() => displaySearchedLocation(item.place_id)}>
                      <Left><MaterialIcons name="add-location" size={30} color="#c792f5" alignSelf="center"></MaterialIcons></Left>
                      <Body>
                        <Text style={{color:'#2a2828',fontFamily:fontFamily}}>{item.description}</Text>
                      </Body>
                    </ListItem>
                  );
                })}
            </View>
            )}
      </Animatable.View>
    )
  }
}
function getDistance(lat1, lon1, lat2, lon2) {
  var R = 6371; 
  var dLat = toRad(lat2-lat1);
  var dLon = toRad(lon2-lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c;
  return d;
}
function toRad(Value){
  return Value * Math.PI / 180;
}
export default MapViewScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
  }
});
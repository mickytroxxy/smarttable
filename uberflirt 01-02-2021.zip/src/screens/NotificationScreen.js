import 'react-native-gesture-handler';
import {TouchableOpacity} from 'react-native-gesture-handler'
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import React, {useState } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView} from "react-native";
import { db } from '../screens/service';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Feather from "react-native-vector-icons/Feather";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import SpinnerScreen from '../screens/SpinnerScreen'
import {Content, List, ListItem, Left, Body, Right, Thumbnail, Text } from 'native-base';
const RootStack = createStackNavigator();
let userToken = null;
import * as Font from 'expo-font';
const NotificationScreen = ({route,navigation}) =>{
    const { myToken } = route.params;
    userToken =myToken;
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="NotificationScreen" component={PageContent} options={{
            headerLeft: () => (
                <MaterialIcons.Button backgroundColor="#fff" name="keyboard-backspace" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></MaterialIcons.Button>
            ), 
            title:"REQUESTS",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    let requestArray = [];
    const [requests,setRequests]=useState(true);
    const [loading,setIsLoading]=React.useState({
        isLoading:false, text:''
    })
    const [fontsLoaded,setFontsLoaded]=useState(false);
    let customFonts = {
        'MontserratAlternates-Light': require('..//../fonts/MontserratAlternates-Light.otf'),
    };
    const loadFontsAsync = async ()=> {
        await Font.loadAsync(customFonts);
        setFontsLoaded(true);
    }
    let fontFamily = 'sans-serif-thin';
    if(fontsLoaded){
        fontFamily = 'MontserratAlternates-Light';
    }
    React.useEffect(()=>{
        const getRequests = async ()=>{
            await db.collection("requests").where("sender", "==", userToken).get().then(querySnapshot => {
                const data1 = querySnapshot.docs.map(doc => doc.data());
                if (data1.length>0) {
                    data1.map((item, i) => {
                        requestArray.push(item);
                        if(i===0){setTimeout(() => {getWhereIreceived()}, 500);}  
                    })
                }else{
                    getWhereIreceived();
                }
            });
        }
        const getWhereIreceived = ()=>{
            db.collection("requests").where("receiver", "==", userToken).get().then(querySnapshot => {
                const data2 = querySnapshot.docs.map(doc => doc.data());
                if (data2.length>0) {
                    data2.map((item, i) => {
                        requestArray.push(item)
                        if(i===0){setTimeout(() => {
                            setRequests(requestArray);
                        }, 500);}  
                    })
                }else{
                    if (requestArray.length==0) {
                        setRequests([]);
                    }else{
                        setRequests(requestArray);
                    }
                }
            });
        }
        loadFontsAsync();
        getRequests();
    },[])
    const getUserProfile = async (user)=>{
        setIsLoading({...loading,isLoading: true,text:'Fetching user data, Please wait...'})
        await db.collection("users").where("phoneNumber", "==", user).get().then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            if (data.length>0) {
                setIsLoading({...loading,isLoading: false,text:''})
                data.map((item, i) => {
                    navigation.navigate("ProfileScreen",{myToken: userToken,userObject:item})
                })
            }
        });
    }
    if(requests==true){
        return(
            <View style={{justifyContent:'center',alignContent:'center',flex:1,alignItems:'center'}}>
                <ActivityIndicator size="large" color="teal"></ActivityIndicator>
            </View>
        )
    }else if(requests.length==0){
        return(
            <View style={{justifyContent:'center',alignContent:'center',flex:1,alignItems:'center'}}>
                <MaterialIcons name="mood-bad" size={120} color="#757575"></MaterialIcons>
                <Text style={{color:'#000',fontFamily:'sans-serif-thin'}}>You Have No Pending Requests</Text>
            </View>
        )
    }else if (requests.length>0) {
        return(
            <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:"#fff",marginTop:10}}>
                <List>
                    {   
                        requests.map((item, i) =>  {
                            let isSenderMyself = false;
                            let  user = null;
                            if (item.sender==userToken) {
                                isSenderMyself = true;
                                user = item.receiver;
                            }else{
                                isSenderMyself = false;
                                user = item.sender;
                            }
                            return(
                                <TouchableOpacity key={i} onPress={()=>{getUserProfile(user)}}>
                                    <ListItem avatar noBorder style={{borderBottomWidth:0.6,borderBottomColor:'#f0ece7'}}>
                                        <Left>
                                            {isSenderMyself?(
                                                <Feather name="arrow-up-circle" size={36} color="orange"></Feather>
                                            ):(
                                                <Feather name="arrow-down-circle" size={36} color="green"></Feather>
                                            )}
                                        </Left>
                                        <Body>
                                            <Text style={{fontFamily:fontFamily}}>{item.requestType}</Text>
                                            <Text note style={{fontFamily:fontFamily}}>{timeSince(parseFloat(item.requestDate))}</Text>
                                        </Body>
                                        <Right>
                                            <Text style={{color:'#2a2828',fontFamily:fontFamily}}>{item.fee} Credits</Text>
                                        </Right>
                                    </ListItem>
                                </TouchableOpacity>
                            )
                        })
                    }
                </List>
                {loading.isLoading?(
                    <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
                ):null}
            </ScrollView>
        )
    }        
};
function timeSince(date) {
    let seconds = Math.floor((Date.now() - date) / 1000);
    let unit = "second";
    let direction = "ago";
    if (seconds < 0) {
      seconds = -seconds;
      direction = "from now";
    }
    let value = seconds;
    if (seconds >= 31536000) {
      value = Math.floor(seconds / 31536000);
      unit = "yr";
    } else if (seconds >= 86400) {
      value = Math.floor(seconds / 86400);
      unit = "day";
    } else if (seconds >= 3600) {
      value = Math.floor(seconds / 3600);
      unit = "hr";
    } else if (seconds >= 60) {
      value = Math.floor(seconds / 60);
      unit = "min";
    }
    if (value != 1)
      unit = unit + "s";
    return value + " " + unit + " " + direction;
}
export default NotificationScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,
        borderColor:'#009387',borderWidth:1,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 25,
        borderColor: '#AEB5BC',
        borderRadius:5,
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        borderWidth:1,
        padding:5,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        //backgroundColor:'#92e6f5',
        borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
});

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
//import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Platform, Text, View, SafeAreaView, TextInput, TouchableOpacity, Image, Dimensions, ToastAndroid } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {MaterialIcons,FontAwesome,Feather} from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
//import { AuthContext } from '../components/context'
import * as Font from "expo-font";

const Stack = createStackNavigator();

const RegisterScreen = ({navigation}) =>{
    return(
        <View style={styles.container}>
            <Text>REGISTER SCREEN</Text>
        </View>
    )
};
export default RegisterScreen;
const styles = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignContent:'center',
        flex:1,
        alignItems:'center',
    }
});
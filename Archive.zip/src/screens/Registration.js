import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MapView from 'react-native-maps';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
const Stack = createStackNavigator();
const Registration = ({navigation}) =>{
    return(
        <View style={GlobalStyles.container}>
            <Text>Details Screen</Text>
            <Button title="Go to Details again" onPress={()=>navigation.push("REGISTER")} />
            <Button title="Go to Home" onPress={()=>navigation.navigate("WELCOME")} />
            <Button title="Go Back" onPress={()=>navigation.goBack()} />
            <Button title="Go First screen" onPress={()=>navigation.popToTop()} />
        </View>
    )
};
export default Registration;


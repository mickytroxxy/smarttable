import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import {ToastAndroid, StyleSheet, Platform, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable'; //061 746 2677 dayalagovender@gmail.com
import Icon from 'react-native-vector-icons/Ionicons'
import { AuthContext } from "../components/context";
import { db } from '../screens/service'
const Stack = createStackNavigator();
const AddKinScreen = ({navigation}) =>{
  return(
    <Stack.Navigator screenOptions={{headerStyle: {elevation: 0,shadowOpacity: 0,backgroundColor: "#009387",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
    <Stack.Screen name="AddKinScreen" component={PageContent} options={{
        title: "ADD NEXT OF KIN",
        headerLeft: () => (
            <Icon.Button
            name="ios-arrow-back"
            size={25}
            backgroundColor="#009387" onPress={() => {
                navigation.goBack();
            }}
            ></Icon.Button>
        )
        }}/>
    </Stack.Navigator>
  )
};
function PageContent({ navigation }) {
  const [userToken, setUserToken] = React.useState(null);  
  const [data,setData]=React.useState({
      fname: '',check_textInputChange:false,secureTextEntry:true,relationship:'',phone_number:'',check_phoneInputChange:false
    })
    const { getUserToken } = React.useContext(AuthContext);
    const textInputChange = (val,valType)=>{
        if(val.length!=0){
            if(valType=="fullName"){
                setData({ ...data, fname: val, check_textInputChange: true });
            }else if(valType=="relationship"){
              setData({...data, relationship:val, check_relInputChange:true})
            }else if (valType=="phoneNumber") {
                setData({...data, phone_number:val, check_phoneInputChange:true})
            }
        }else{
            if(valType=="fullName"){
                setData({ ...data, fname: val, check_textInputChange: false });
            }else if(valType=="password"){
                setData({...data, password:val})
            }else if (valType=="phoneNumber") {
                setData({...data, phone_number:val, check_phoneInputChange:false})
            }
        }
    }
    React.useEffect(() => {
      getUserToken(function (userToken) {
        setUserToken(userToken);
      });
    }, [navigation]);
    const saveKin = (fname, phoneNumber, relationship)=>{
      if (fname.length > 5 && phoneNumber.length > 8) {
        if (relationship.length > 2) {
          let rowId = (1000000 + Math.random() * (10000000 - 1000000)).toString();
          db.collection("nextofkins").doc(rowId).set({fname: fname, phoneNumber: phoneNumber,relationship: relationship, user:userToken })
          .then(function() {
              showToast("Next Of Kin Added!");
              navigation.goBack();
          })
          .catch(function(error) {
              console.error("Error writing document: ", error);
          });
        } else {
          showToast("relationship field should be at least 3 characters long!");
        }
      } else {
        showToast("Invalid Full Name or Invalid phone number!");
      }
    }
    const showToast = (message)=>{
        ToastAndroid.show(message, ToastAndroid.SHORT); 
    }
    return (
        <ScrollView style={{ backgroundColor: "#009387", padding: 5 }}>
            <View style={styles.header}></View>
            <View style={GlobalStyles.outterHolder}>
                <View animation="fadeInUpBig" style={styles.footer}>
                <Text style={styles.newLabel}>FULL NAME</Text>
                <View style={styles.action}>
                    <FontAwesome name="user-o" color="#009387" size={20}></FontAwesome>
                    <TextInput
                    style={styles.textInput}
                    placeholder="FULL NAME"
                    autoCapitalize="none"
                    onChangeText={val => textInputChange(val, "fullName")}
                    ></TextInput>
                    {data.check_textInputChange ? (
                    <Animatable.View animation="bounceIn">
                        <Feather name="check-circle" color="green" size={20}></Feather>
                    </Animatable.View>
                    ) : null}
                </View>

                <Text style={styles.newLabel}>PHONE NUMBER</Text>
                <View style={styles.action}>
                    <Feather name="phone" color="#009387" size={20}></Feather>
                    <TextInput
                    style={styles.textInput}
                    placeholder="Phone number"
                    autoCapitalize="none"
                    keyboardType={"phone-pad"}
                    onChangeText={val => textInputChange(val, "phoneNumber")}
                    ></TextInput>
                    {data.check_phoneInputChange ? (
                    <Animatable.View animation="bounceIn">
                        <Feather name="check-circle" color="green" size={20}></Feather>
                    </Animatable.View>
                    ) : null}
                </View>
                
                <Text style={styles.newLabel}>RELATIONSHIP</Text>
                <View style={styles.action}>
                    <Feather name="user-plus" color="#009387" size={20}></Feather>
                    <TextInput
                    style={styles.textInput}
                    placeholder="Relationship"
                    autoCapitalize="none"
                    onChangeText={val => textInputChange(val, "relationship")}
                    ></TextInput>
                    {data.check_relInputChange ? (
                    <Animatable.View animation="bounceIn">
                        <Feather name="check-circle" color="green" size={20}></Feather>
                    </Animatable.View>
                    ) : null}
                </View>
                
                <View style={styles.button}>
                    <TouchableOpacity
                    onPress={() => {
                        saveKin(data.fname, data.phone_number, data.relationship);
                    }}
                    >
                    <LinearGradient
                        colors={["#08d4c4", "#01ab9d"]}
                        style={styles.signIn}
                    >
                        <Text
                        style={
                            ([styles.textSign],
                            { color: "#fff", fontWeight: "bold", fontSize: 20 })
                        }
                        >
                        Save
                        </Text>
                    </LinearGradient>
                    </TouchableOpacity>
                  
                </View>
                </View>
            </View>
        </ScrollView>
    );
}
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
  Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
}
export default AddKinScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#009387"
  },
  header: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 50
  },
  footer: {
    flex: 3,
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
    marginLeft: 5,
    marginRight: 5
  },
  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 30
  },
  text_footer: {
    color: "#05375a",
    fontSize: 18
  },
  action: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f2f2f2",
    paddingBottom: 5
  },
  actionError: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#FF0000",
    paddingBottom: 5
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : -12,
    paddingLeft: 10,
    color: "#05375a"
  },
  errorMsg: {
    color: "#FF0000",
    fontSize: 14
  },
  button: {
    alignItems: "center",
    marginTop: 50
  },
  signIn: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  signUp: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold"
  },
  newLabel: {
    marginTop: 25,
    color: "#009387",
    fontWeight: "bold"
  }
});
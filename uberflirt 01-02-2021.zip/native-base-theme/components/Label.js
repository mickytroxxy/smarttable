// @flow

export default () => {
  const labelTheme = {
    '.focused': {
      width: 0
    },
    fontSize: 17
  };

  return labelTheme;
};

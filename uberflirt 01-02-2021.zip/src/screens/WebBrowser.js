import React, { useEffect, useState } from "react";
import { View,Text,StyleSheet,TouchableOpacity,ActivityIndicator } from "react-native";
import { WebView } from 'react-native-webview';
import { db,storage } from '../screens/service';
import FontAwesome from "react-native-vector-icons/FontAwesome";
const WebBrowser = ({route,navigation}) =>{
    const { amount,userObj,baseUrl } = route.params;
    const [successStatus,setSuccessStatus]=useState('processing');
    if (successStatus=="processing") {
        return(
            <WebView
                source={{ uri: baseUrl }}
                onLoadStart={(syntheticEvent) => {
                    const { nativeEvent } = syntheticEvent;
                    if (nativeEvent.url.includes("empiredigitalspty")) {
                        setSuccessStatus("failed");
                    }else if (nativeEvent.url.includes("uberflirt")) {
                        setSuccessStatus("loading");
                    }
                }}
            />
        )
    }else if (successStatus=="processed") {
        return(
            <View style={styles.container}>
                <FontAwesome name="check-circle" color="green" size={200}></FontAwesome>
                <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',}}>TOP UP OF R{amount} WAS SUCCESSFUL. HAPPY MEETUP</Text>
                <TouchableOpacity style={{marginTop:50}} onPress={()=>navigation.goBack()}>
                    <FontAwesome name="arrow-circle-left" color="#757575" size={50}></FontAwesome>
                </TouchableOpacity>
            </View>
        )
    }else if (successStatus=="failed") {
        return(
            <View style={styles.container}>
                <FontAwesome name="times-circle-o" color="tomato" size={200}></FontAwesome>
                <View>
                    <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',padding:10,alignItems: 'center',alignContent:'center'}}>ERROR! EITHER YOU CANCELLED THE TRANSACTION OR YOUR PAYMENT WASN'T VALID</Text>
                </View>
                <TouchableOpacity style={{marginTop:50}} onPress={()=>navigation.goBack()}>
                    <FontAwesome name="arrow-circle-left" color="#757575" size={50}></FontAwesome>
                </TouchableOpacity>
            </View>
        )
    }
    else if (successStatus=="loading") {
        const newBal = parseFloat(userObj.balance) + parseFloat(amount);
        const transactionId = userObj.phoneNumber+Date.now();
        db.collection("users").doc(userObj.phoneNumber).update({balance:newBal}).then(function() {
            db.collection("transactions").doc(transactionId).set({sender:userObj.phoneNumber,receiver:userObj.phoneNumber,amount:amount,transactionId:transactionId,date:Date.now(),transactionType:'TOP UP',fname:userObj.fname,avatar:userObj.avatar}).then(function() {
                setSuccessStatus("processed")
            }).catch(function(error) {});
        }).catch(function(error) {});
        return(
            <View style={styles.container}>
                <ActivityIndicator size="large" color="#0000ff" style={{marginTop:50}}/>
            </View>
        )
    }
}
export default WebBrowser;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
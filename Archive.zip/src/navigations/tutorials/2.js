import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.welcome}>LOGIN TO MY APP</Text>
      <StatusBar style="auto" />
      <TextInput style={styles.input} placeholder="Username" />
      <TextInput style={styles.input} placeholder="Password" secureTextEntry />
      <View style={styles.btnContainer}>
        <TouchableOpacity style={styles.userBtn} onPress={()=>alert("Login")}>
          <Text style={styles.btnText}>LOGIN</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.userBtn}>
          <Text style={styles.btnText}>REGISTER</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387',
    alignItems: 'center',
    justifyContent: 'center',
  },
  welcome:{
    fontSize:24,
    fontWeight:'bold',
    margin:10,
    color:'#fff',
  },
  input:{
    width:"90%",
    backgroundColor:'#fff',
    padding:15,
    marginBottom:15,
    borderRadius:5,
  },
  userBtn:{
    backgroundColor:'#FFD700',
    padding:15,
    width:'45%',
    margin:10,
    borderRadius:20,    
  },
  btnContainer:{
    flexDirection:"row",
    textAlign:'center',
    width:'90%',
  },
  btnText:{
    textAlign:'center',
    color:'#fff',
    fontWeight:'bold',
  }
});

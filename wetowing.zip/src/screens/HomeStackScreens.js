import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import MapViewScreen from './MapViewScreen';
import KinList from  './KinList';
import AddKinScreen from  './AddKin';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { DrawerContent } from "../screens/DrawerContent";
//const RootStack = createStackNavigator();
const RootStack = createDrawerNavigator();
const HomeStackScreens = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "#009387",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        drawerContent={props=><DrawerContent {...props} />}>
          <RootStack.Screen
            name="MapViewScreen"
            component={MapViewScreen}
            options={{ title: "YOUR LOCATION" }}
          />
          <RootStack.Screen
            name="KinList"
            component={KinList}
            options={{ title: "Next Of Kin", headerLeft:"" }}
          />
          <RootStack.Screen
            name="AddKinScreen"
            component={AddKinScreen}
            options={{ title: "add", headerLeft:"" }}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default HomeStackScreens;
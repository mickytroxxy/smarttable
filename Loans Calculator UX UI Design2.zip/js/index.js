const periods = [3,6,12,24,36];
let selectedPeriod=3,chart,seriesData={index:0,depositType:'Fixed'},investmentAmount = 500;
$(document).ready(()=>appIsReady());

const appIsReady=()=>{
    listPeriods();
    prepareCharts();
    displayReturnsData();
    $(".investment_amount_input").val(parseFloat(investmentAmount))
};
const listPeriods = () => periods.map((period) => $(".period-select").append("<option>"+period+" Months</option>"));


//Below method get called from the appIsReady method
const prepareCharts=()=>{
    // Create the chart
    chart=Highcharts.chart('container', {
        chart: {
            type: 'column'
        },
        title: {text: ''},
        exporting: {enabled: false},
        credits: {enabled: false},
        xAxis: {
            type: 'category',
            labels: {
                useHTML: true,                
                formatter: function (data) {
                    let activePeriod='';
                    if(data.value=='Fixed'){
                        activePeriod="active-period";
                    }
                    return '<div class="centeredCategory '+activePeriod+' active-period'+data.value+'">'+data.value+'<div style="margin-top:-22px;font-size:9px;">DEPOSIT</div></div>'
                },
            },
            lineWidth: 0,
        },
        yAxis: {
            title: {
                text: 'Total percent market share'
            },
            visible:false,
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                borderRadius: 5,
                dataLabels: {
                    enabled: false,
                    //format: '{point.y:.1f}%'
                },
                point: {
                    events: {
                        click: function () {
                            barChartClicked(this);
                        }
                    }
                }
            }
        },

        tooltip: {
            headerFormat: '',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>R {point.y:.2f}</b><br/>'
        },

        series: [
            {
                data: calculateDataSetFromApi(api),
            }
        ],
        
    });
}
const barChartClicked=(args)=>{
    $(chart.series[0].data).each(function(){
        this.update({color:"#adaaaa"});
    });
    seriesData={index:args.index,depositType:args.name};
    args.update({color: args.defaultColor});
    displayReturnsData();
}
$(document).on("change",".investmentType", function(e) {
    const selectedInvestmentType = $(this).val();
    $(chart.series[0].data).each(function(){
        selectedInvestmentType.includes(this.name)?(this.update({color:this.defaultColor}),seriesData={index:this.index,depositType:this.name}):this.update({color:"#adaaaa"});
    });
    displayReturnsData();
});
//Get executed when we press period labels
$(document).on("change",".period-select", function(e) {
    const period = parseInt($(this).val().split(" ")[0]);
    selectedPeriod=period;
    updateSeriesData();
});
//We try to strip the api to new object understandable by highcharts api
const calculateDataSetFromApi=(api)=>{
    const dataSetObject = [];
    api.map((obj)=>{
        let values;
        obj.periodNRate.map((periodNRateObj)=>{
            if(selectedPeriod==periodNRateObj.period){
                values = ((periodNRateObj.rate/100) * investmentAmount) + (investmentAmount);
            }
        })
        if(obj.type.includes('Fixed')){
            dataSetObject.push({name: 'Fixed',y: values,marker: {enabled: false},color: '#0d1a5c',defaultColor: '#0d1a5c'})
        }else if(obj.type.includes('Notice')){
            dataSetObject.push({name: 'Notice',y: values,marker: {enabled: false},color:'#adaaaa',defaultColor: '#f07ef7'})
        }else if(obj.type.includes('Access')){
            dataSetObject.push({name: 'Access',y: values,marker: {enabled: false},color:'#adaaaa',defaultColor: '#7ef7df'})
        }else if(obj.type.includes('Tax')){
            dataSetObject.push({name: 'Tax',y: values,marker: {enabled: false},color:'#adaaaa',defaultColor: '#faac75'})
        }
    });
    return dataSetObject;
}
//The investment button is clicked
const investBtnClicked=()=>{
    api.map((data)=>{
        if(data.type.includes(seriesData.depositType)){
            data.periodNRate.map(({period,rate})=>{
                if(period==selectedPeriod){
                    const returnAmount = (((rate/100) * investmentAmount) + investmentAmount).toFixed(2);
                    alert("Hello you have chosen to invest R"+investmentAmount.toFixed(2)+ " for "+selectedPeriod+" months, Your return amount will be R"+returnAmount,"INVESTMENT AMOUNT");
                }
            })
        }
    });
}
//When user update the investment amount
const newInvestmentAmountEntered=()=>{
    let amount=$(".investment_amount_input").val().replaceAll(/\s/g,'');
    if(amount.includes('R')){
        amount=amount.slice(1,amount.length)
    }
    investmentAmount = parseFloat(amount);
    investmentAmount>499&&updateSeriesData();
}
//We update the chart according to new values | depends on the investment amount and period selected
const updateSeriesData=()=>{
    chart.series[0].update({data:calculateDataSetFromApi(api)});
    displayReturnsData();
}
const displayReturnsData=()=>{
    $(".otherInvestmentTypes").html("");
    $(chart.series[0].data).each(function(){
        let icon, investmentType=this.name,investmentTypeAmount=formatToCurrency(this.y);
        let displayName = investmentType.includes("Tax")?"Tax Free":investmentType+" Deposit";
        if(investmentType.includes("Fixed")){
            icon = "accessacumulatorico.svg";
        }else if(investmentType.includes("Notice")){
            icon = "noticedepositico.svg";
        }else if(investmentType.includes("Access")){
            icon = "accessacumulatorico.svg";
        }else if(investmentType.includes("Tax")){
            icon = "taxfreeico.svg";
        }
        if(!investmentType.includes(seriesData.depositType)){
            $(".otherInvestmentTypes").append("<div class='other-inv'><img class='inv-other-ico' src='"+icon+"' width='100px' alt="+this.name+"/><div><p class='other-inv-title'>"+displayName+"</p><p class='big-return-other'>"+investmentTypeAmount+"</p><p class='other-inv-term'> Investment after "+selectedPeriod+" months term</p></div></div>");
        }else{
            $(".selected-header-inv-type").text(displayName);
            $(".big-return").text(investmentTypeAmount);
            $(".return-inv-term").text("Investment after "+selectedPeriod+" months")
        }
    });
}
const formatToCurrency = (val) => {
    return "R " + val.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&, ");
};
const $$ = Dom7;
const app = new Framework7({modalTitle: '',material: true,pushState: true});
const mainView = app.addView('.view-main', {dynamicNavbar: true,domCache: true});
const periods = [3,6,12,24,36];
let selectedPeriod=3,chart,seriesData={index:0,color:'#000',depositType:'Fixed'},investmentAmount = 500;
//Initializing the app
$(document).ready(()=>appIsReady());
const appIsReady=()=>{
    listMOnths();
    prepareCharts()
};

const listMOnths=()=>{
    let scrollmenu_btn_active='scrollmenu_btn_active';
    periods.map((period)=>{
        if(period!=3){
            scrollmenu_btn_active='';
        }
        $(".scrollmenu").append("<a href='#' class='scrollmenu_btn scrollmenu_btn"+period+" "+scrollmenu_btn_active+"' period="+period+">"+period+"</a>")
    })
}
//Below method get called from the appIsReady method
const prepareCharts=()=>{
    chart = Highcharts.chart('container', {
        chart: {type: 'areaspline'},
        title: {text: ''},
        exporting: {enabled: false},
        credits: {enabled: false},
        yAxis:{visible:false,min:550},
        legend: {align: 'center',x: 0,verticalAlign: 'top',y: 0,floating: true,x: 0},
        xAxis: {
            min: 0.49,
            max: periods.length - 1.49,
            scrollbar: {
                enabled: true
            },
            tickLength: 0,
            tickmarkPlacement:0,
            categories:periods,
            labels: {
                useHTML: true,                
                formatter: function (data) {
                    return '<div class="centeredCategory">'+data.value+'<div style="margin-top:-22px;font-size:9px;">MONTHS</div></div>'
                }
            }
        },
        tooltip: {
            color:'#fff',
            borderRadius:20,
            useHTML:true,
            formatter: function() {
                return '<span style="color:#fff"><b>R'+ parseFloat(this.y).toFixed(2) +'</b></span>';
            },
        },
        plotOptions: {
            areaspline: {fillOpacity: 0.3},
            series: {
                showInLegend: true,
                states: {
                    inactive: {opacity: 1},
                    hover: {brightness: 0},
                    select: {enabled: false}
                }
            },
        },
        series: calculateDataSetFromApi(api),
    });
}
//This get executed when a user click on the the investment tab. We then update the seriesData object with the currently selected investment tab
const investmentTypeTabClicked=(investmentTabClicked)=>{
    $(".investment_tabs_text").removeClass("active-tab");
    $(chart.series).each(function(){
        if(this.name!=investmentTabClicked){
            this.update({ opacity: 0.2,color: '#c1c0bf' });
        }else{
            $("."+investmentTabClicked).addClass("active-tab")
            this.update({ opacity: 1,color:this.userOptions.defaultColor });
            seriesData={index:this.index,color:this.color,depositType:this.name};
        }
    });
}
//Get executed when we press period labels
$(document).on("click",".scrollmenu_btn", function(e) {
    const period = $(this).attr("period");
    $(".scrollmenu_btn").removeClass("scrollmenu_btn_active");
    $(".scrollmenu_btn"+period).addClass("scrollmenu_btn_active");
    const tooltip = chart.tooltip;
    selectedPeriod=period;
    tooltip.update({backgroundColor: seriesData.color});
    tooltip.refresh(chart.series[seriesData.index].points[periods.indexOf(parseFloat(period))]);
});

//We try to strip the api to new object understandable by highcharts api
const calculateDataSetFromApi=(api)=>{
    const dataSetObject = [];
    api.map((obj)=>{
        let values = []
        periods.map((period)=>{
            obj.periodNRate.map((periodNRateObj)=>{
                period==periodNRateObj.period&&values.push(((periodNRateObj.rate/100) * investmentAmount) + (period?investmentAmount:0))
            })
        });
        if(obj.type.includes('Fixed')){
            dataSetObject.push({name: 'Fixed',data: values,marker: {enabled: false},color: '#000',defaultColor: '#000',opacity: 1,showInLegend:false})
        }else if(obj.type.includes('Notice')){
            dataSetObject.push({name: 'Notice',data: values,marker: {enabled: false},opacity: 0.2,color:'#f07ef7',defaultColor: '#f07ef7',showInLegend:false})
        }else if(obj.type.includes('Access')){
            dataSetObject.push({name: 'Access',data: values,marker: {enabled: false},opacity: 0.2,color:'#7ef7df',defaultColor: '#7ef7df',showInLegend:false})
        }else if(obj.type.includes('Tax')){
            dataSetObject.push({name: 'Tax',data: values,marker: {enabled: false},opacity: 0.2,color:'#faac75',defaultColor: '#faac75',showInLegend:false})
        }
    });
    return dataSetObject;
}
//The investment button is clicked
const investBtnClicked=()=>{
    api.map((data)=>{
        if(data.type.includes(seriesData.depositType)){
            data.periodNRate.map(({period,rate})=>{
                if(period==selectedPeriod){
                    const returnAmount = (((rate/100) * investmentAmount) + investmentAmount).toFixed(2);
                    app.alert("Hello you have chosen to invest R"+investmentAmount.toFixed(2)+ " for "+selectedPeriod+" months, Your return amount will be R"+returnAmount,"INVESTMENT AMOUNT");
                }
            })
        }
    });
}
//When user update the investment amount
const newInvestmentAmountEntered=()=>{
    let amount=$(".investment_amount_input").val();
    if(amount.includes('R')){
        amount=amount.slice(1,amount.length)
    }
    investmentAmount = parseFloat(amount);
    investmentAmount>499&&updateSeriesData();
}
//We update the chart according to new values | depends on the investment amount
const updateSeriesData=()=>{
    api.map((obj)=>{
        let values = []
        periods.map((period)=>{
            obj.periodNRate.map((periodNRateObj)=>{
                period==periodNRateObj.period&&values.push(((periodNRateObj.rate/100) * investmentAmount) + (period?investmentAmount:0))
            })
        });
        chart.series.map(data => obj.type.includes(data.name) && data.update({data:values},true));
    });
}
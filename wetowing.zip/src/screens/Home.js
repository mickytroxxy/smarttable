import React, { useEffect, useState } from "react";
//import * as React from "react";
import {
  View,
  Text,
  Button,
  Alert,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { AuthContext } from "../components/context";
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker } from "react-native-maps";
import {Location,Permissions} from 'expo';
import { HelperText } from "react-native-paper";
import { createDrawerNavigator } from '@react-navigation/drawer';
import HomeStackScreens from "./HomeStackScreens";
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
function Home() {
  return (
    <HomeStackScreens></HomeStackScreens>
  );
}
export default Home;
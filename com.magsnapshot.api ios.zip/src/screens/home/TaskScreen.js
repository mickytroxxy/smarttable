import { createStackNavigator } from '@react-navigation/stack';
import React, {useState,useContext } from "react";
import { StyleSheet, View, Linking ,ActivityIndicator,ScrollView, Platform,TouchableOpacity,Text,TextInput, Alert} from "react-native";
import {MaterialIcons,FontAwesome,Feather,Ionicons } from "@expo/vector-icons";
import {Card, CardItem, Right } from 'native-base';
import { UserContext } from '../../../components/context';
import { Col, Row, Grid } from 'react-native-easy-grid';
const RootStack = createStackNavigator();
const TaskScreen = ({navigation}) =>{
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="TaskScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"DRIVER`S TASKS",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const [isLoading,setIsLoading]=React.useState(true);
    const {fontFamilyObj,getCurrentLocation,lastIndex,carObj,showToast,userState,confirmDialog,getNetworkStatus} = useContext(UserContext);
    const [tasks,setTasks]=React.useState();
    const [myLocation,setMyLocation]=React.useState(null);
    React.useEffect(()=>{
        getCurrentLocation((latitude,longitude)=>{
            getNetworkStatus((socket,url)=>{
                socket.emit("getDriverTasks",userState.userDetails.userId,(result)=>{
                    setMyLocation({latitude,longitude})
                    setTasks(result);
                    setIsLoading(false);
                })
            })
        });
    },[])
    const handleAction=(action,lat,lng,label,taskId)=>{
        if(action==1){
            confirmDialog("ACCEPT TRIP","Please complete this task in time!","Proceed","No",(cb)=>{
                if(cb){
                    getNetworkStatus((socket,url)=>{
                        socket.emit("taskAction",taskId,1,(result)=>{
                            if(result){
                                showToast("Thank you, trip accepted, you may proceed!");
                                startLocationLog(lat,lng,label,taskId);
                            }
                        })
                    })
                }
            })
        }else if(action==0){
            confirmDialog("CANCEL TRIP","Are you sure you want to cancel this trip? You may have to explain why your cancelled this to your management!","Proceed","No",(cb)=>{
                if(cb){
                    getNetworkStatus((socket,url)=>{
                        socket.emit("taskAction",taskId,2,(result)=>{
                            if(result){
                                showToast("You just cancelled your trip!")
                            }
                        })
                    })
                }
            })
        }
    }
    const startLocationLog=(lat,lng,label,taskId)=>{
        openMap(lat,lng,label);
        function loop(){
            setTimeout(() => {
                getCurrentLocation((latitude,longitude)=>{
                    if(getDistance(lat,lng,latitude,longitude)>1){
                        getNetworkStatus((socket,url)=>{
                            socket.emit("updateLocation",latitude,longitude,userState.userDetails.userId,(result)=>{
                                if(result){
                                    loop();
                                }
                            })
                        })
                    }else{
                        Alert.alert("TRIP COMPLETE","Hello there, you have arrived at your destination, thank you!")
                    }
                });
            }, 1000*60);
        }
        loop();
    }
    const openMap=(lat,lng,label)=>{
        //const scheme = Platform.select({ ios: 'maps:0,0?q=', android: 'geo:0,0?q=' });
        const scheme = Platform.OS === 'ios' ? 'maps:0,0?q=' : 'geo:0,0?q='; 
        const latLng = `${lat},${lng}`;
        const url = Platform.select({
            ios: `${scheme}${label}@${latLng}`,
            android: `${scheme}${latLng}(${label})`
        });
        Linking.openURL(url); 
    }
    return(
        <View style={styles.container}>
            {isLoading?(
                <View style={{justifyContent:'center',flex:1}}>
                    <ActivityIndicator size={50} color="#757575"></ActivityIndicator>
                </View>
            ):(
                <ScrollView showsVerticalScrollIndicator={false}>
                    {(tasks && myLocation)&&tasks.map((item,i)=>(
                        <Card key={i}>
                            <CardItem header style={{elevation:3,borderBottomColor:'#757575'}}>
                            <Text style={{fontFamily:fontFamilyObj.customBold}}>Place to go</Text>
                            </CardItem>
                            <CardItem>
                                <FontAwesome name="bullseye" size={24} color="teal"></FontAwesome>
                                <Text style={{fontFamily:fontFamilyObj.customBold,marginLeft:10,color:'#757575'}}>Reason</Text>
                                <Right>
                                    <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>{item.description}</Text>
                                </Right>
                            </CardItem>
                            <CardItem>
                                <FontAwesome name="bullseye" size={24} color="teal"></FontAwesome>
                                <Text style={{fontFamily:fontFamilyObj.customBold,marginLeft:10,color:'#757575'}}>Distance</Text>
                                <Right>
                                    <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>{getDistance(myLocation.latitude, myLocation.longitude, item.driverLat, item.driverLon).toFixed(1)}KM</Text>
                                </Right>
                            </CardItem>
                            <CardItem>
                                <FontAwesome name="bullseye" size={24} color="teal"></FontAwesome>
                                <Text style={{fontFamily:fontFamilyObj.customBold,marginLeft:10,color:'#757575'}}>Estimated Arrival Time</Text>
                                <Right>
                                    <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>{timeEstimator(getDistance(myLocation.latitude, myLocation.longitude, item.driverLat, item.driverLon))}</Text>
                                </Right>
                            </CardItem>
                            <CardItem footer>
                                <Grid>
                                    <Col style={{alignItems:'center'}}>
                                        <TouchableOpacity onPress={()=>handleAction(0,item.driverLat,item.driverLon,item.description,item.id)}>
                                            <FontAwesome name="times-circle" size={36} color="tomato"></FontAwesome>
                                        </TouchableOpacity>
                                    </Col>
                                    <Col style={{alignItems:'center'}}>
                                        <TouchableOpacity onPress={()=>handleAction(1,item.driverLat,item.driverLon,item.description,item.id)}>
                                            <FontAwesome name="check-circle" size={36} color="green"></FontAwesome>
                                        </TouchableOpacity>
                                    </Col>
                                </Grid>
                            </CardItem>
                        </Card>
                    ))}
                </ScrollView>
            )}
        </View>
    )
};
const timeEstimator=(distance)=>{
    const n = ((distance) / 60 * 60);
    var num = n;
    var hours = (num / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return rhours + ":" + rminutes + " min(s).";
}
function timeConvert(n) {
    
}
function getDistance(lat1, lon1, lat2, lon2) {
    var R = 6371; 
    var dLat = toRad(lat2-lat1);
    var dLon = toRad(lon2-lon1);
    var lat1 = toRad(lat1);
    var lat2 = toRad(lat2);
  
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    var d = R * c;
    return d;
  }
  function toRad(Value){
    return Value * Math.PI / 180;
  }
export default TaskScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#fff'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5'
    }
});

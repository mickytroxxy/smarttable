import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions,FlatList, ActivityIndicator,Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker } from "react-native-maps";
import {Location,Permissions} from 'expo';
import { LinearGradient } from 'expo-linear-gradient';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import { AuthContext } from "../components/context";
import { StatusBar } from "expo-status-bar";
import { socket } from "../screens/Socket";
import { ListItem, Avatar, Input } from "react-native-elements";
import { ScrollView } from "react-native-gesture-handler";
import Feather from "react-native-vector-icons/Feather";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { db } from '../screens/service'
const Stack = createStackNavigator();
const KinList = ({navigation}) =>{
  return(
    <Stack.Navigator screenOptions={{headerStyle: {elevation: 0,shadowOpacity: 0,backgroundColor: "#009387",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
    <Stack.Screen name="KinList" component={PageContent} options={{
        title: "NEXT OF KIN",
        headerLeft: () => (
            <Icon.Button
            name="ios-arrow-back"
            size={25}
            backgroundColor="#009387" onPress={() => {
                navigation.goBack();
            }}
            ></Icon.Button>
        ),
        headerRight: () => (
            <Icon.Button
            name="ios-add-circle-outline"
            size={25}
            backgroundColor="#009387"
            onPress={() => {
                navigation.navigate("AddKinScreen");
            }}
            ></Icon.Button>
        )
        }}/>
    </Stack.Navigator>
  )
};
function PageContent({ navigation }) {
  const [nextOfKinObj,setNextOfKinObj] = React.useState(null)
  const { signOut, getUserToken } = React.useContext(AuthContext);
  const [isLoading, setIsLoading] = React.useState(true);
  const [userToken, setUserToken] = React.useState(null);
  React.useEffect(() => {
        navigation.addListener("focus", () => {
            getUserToken(function (userToken) {
                setUserToken(userToken);
                db.collection("nextofkins")
                .where("user", "==", userToken)
                .get()
                .then(querySnapshot => {
                  const data = querySnapshot.docs.map(doc => doc.data());
                  setNextOfKinObj(data)
                  setIsLoading(false)
                });
            })
            socket.emit("getUserKins",'globalUserToken',(result)=>{
                
            })
        });
    }, [navigation]);
  if(isLoading){
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }} >
        <ActivityIndicator size="large" color="green"></ActivityIndicator>
        <Text>{isLoading.message}</Text>
      </View>
    );
  }else{
    return (
      <ScrollView style={{ backgroundColor: "#009387", padding: 5 }}>
            <View style={GlobalStyles.outterHolder}>
            {nextOfKinObj.map((item, i) => (
                <ListItem key={i} bottomDivider>
                <FontAwesome name="user-o" color="#009387" size={20}></FontAwesome>
                <ListItem.Content>
                    <ListItem.Title>{item.fname}</ListItem.Title>
                    <ListItem.Subtitle>{item.relationship} ({item.phoneNumber})</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
                </ListItem>
            ))}
            </View>
        </ScrollView>
    );
  }
}
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
  Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
}
export default KinList;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
  }
});
import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
//import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import { StyleSheet, Platform, View, SafeAreaView, Image, ScrollView, Modal, Alert,Button, Dimensions , TouchableOpacity} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
//import Icon from 'react-native-vector-icons/Ionicons';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Animated,{Easing} from 'react-native-reanimated';
import ActionSheet from './ActionSheet';
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import { db,storage } from '../screens/service';
import ModalScreen from './Modal';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { Container, Header, Content, List, ListItem, Left, Body, Right, Thumbnail, Text } from 'native-base';
const Stack = createStackNavigator();
import { MenuProvider } from 'react-native-popup-menu';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
  } from 'react-native-popup-menu';  
const CreditScreen = ({route,navigation}) =>{
    const { userObj } = route.params;
    const avatar = userObj.avatar;
    return(
        <ParallaxScroll
            headerHeight={50}
            isHeaderFixed={false}
            parallaxHeight={400}
            fadeOutParallaxBackground={true}
            renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue} userObj={userObj}/>}
            renderParallaxForeground={({ animatedValue }) => <Foreground userObj={userObj} navigation={navigation}/>}
            parallaxBackgroundScrollSpeed={5}
            useNativeDriver={true}
            parallaxForegroundScrollSpeed={2.5}
            >
            <ParallaxBody navigation={navigation} userObj={userObj}/>
            
        </ParallaxScroll>
    )
};
const Background = props =>{
    return(
        <View style={{flex:3,padding:5,backgroundColor:'#fff'}}>
            <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:50,borderBottomLeftRadius:500,borderBottomRightRadius:500}}>
                <View style={{height:380}}>
                    <View style={{alignContent:'center',alignItems:'center',marginTop:60}}>
                        <Text style={{color:'#fff',fontWeight:'bold',fontSize:20,fontFamily:'sans-serif-medium',}}>CREDITS INFO</Text>
                        <LinearGradient colors={["#68418a","#f14da1"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:50,borderRadius:100,width:200,height:200,marginTop:35,}}>
                            <View style={{alignContent:'center',alignItems:'center',flex:1,marginTop:75}}>
                            <Text style={{color:'#fff',fontWeight:'bold',fontSize:30,fontFamily:'sans-serif-medium',}}>{props.userObj.balance}c</Text>
                            </View>
                        </LinearGradient>
                    </View>
                </View>
            </LinearGradient>
        </View>
    )
}
const ParallaxBody = props =>{
    const [showTransactions,setShowTransactions]=useState([]);
    let user;
    let transactionArray = [];
    React.useEffect(() => {
        getMyTransactions();
    }, []);
    const getMyTransactions = async ()=>{
        await db.collection("transactions").where("sender", "==", props.userObj.phoneNumber).get().then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            data.map((item, i) =>  {
                transactionArray.push(item);
                if (i===0) {
                    db.collection("transactions").where("receiver", "==", props.userObj.phoneNumber).get().then(querySnapshot => {
                        const data = querySnapshot.docs.map(doc => doc.data());
                        data.map((item, i) =>  {
                            transactionArray.push(item)
                            if(i==0){
                                setTimeout(() => {
                                    setShowTransactions(transactionArray)
                                }, 1500);
                            }
                        })
                    }); 
                }
            })
        });
    }
    return(
        <View style={[GlobalStyles.CreditFooter,{paddingBottom:50}]}>
           <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.ProfileFooterHeader}>
                <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                    <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                </View>
                <View style={styles.statsContainer}>
                <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>TRANSACTIONS</Text>
                </View>
                </LinearGradient>

            <Content>
                <List>
                {   showTransactions.length>0?
                    showTransactions.map((item, i) =>  {
                        let isIncrease = true;
                        if ((item.sender==props.userObj.phoneNumber) && (item.transactionType!="TOP UP")) {
                            isIncrease = false;
                        }else if ((item.sender==props.userObj.phoneNumber) && (item.transactionType=="TOP UP")) {
                            isIncrease = true;
                        }else{
                            isIncrease = true;
                        }
                        return(
                            <ListItem avatar key={i}>
                            <Left>
                                <Thumbnail source={{ uri: item.avatar }} />
                            </Left>
                            <Body>
                                <Text>{item.fname}</Text>
                                <Text note>({item.transactionType }) {timeSince(parseFloat(item.date))}</Text>
                            </Body>
                            <Right>
                                {isIncrease?(
                                    <View style={{flex:1,flexDirection:'row'}}>
                                        <Text note style={{fontSize:18,color:'teal',marginTop:-4}}>+ </Text>
                                        <Text note>{item.amount}</Text>
                                    </View>
                                ):(
                                    <View style={{flex:1,flexDirection:'row'}}>
                                        <Text note style={{fontSize:18,color:'tomato',marginTop:-4}}>- </Text>
                                        <Text note>{item.amount}</Text>
                                    </View>
                                )}
                            </Right>
                            </ListItem>
                        )
                    })
                    :[{key:1}].map((transactionItem, i) =>  {})
                }
                </List>
            </Content>
        </View>
    )
}
function timeSince(date) {
    let seconds = Math.floor((Date.now() - date) / 1000);
    let unit = "second";
    let direction = "ago";
    if (seconds < 0) {
      seconds = -seconds;
      direction = "from now";
    }
    let value = seconds;
    if (seconds >= 31536000) {
      value = Math.floor(seconds / 31536000);
      unit = "yr";
    } else if (seconds >= 86400) {
      value = Math.floor(seconds / 86400);
      unit = "day";
    } else if (seconds >= 3600) {
      value = Math.floor(seconds / 3600);
      unit = "hr";
    } else if (seconds >= 60) {
      value = Math.floor(seconds / 60);
      unit = "min";
    }
    if (value != 1)
      unit = unit + "s";
    return value + " " + unit + " " + direction;
}
const Foreground = props =>{
    const [modalVisible, setModalVisible] = useState(false);
    const [modalAttr, setModalAttr] = useState({toOpen:'BUY CREDITS',headerText:'BUY CREDITS',values:''});
    function closeModal() {
        setModalVisible(false);
    }
    async function callback(amount,status) {
        if(status=="PAYMENT"){
            if(amount!=null && amount>=120){
                props.navigation.navigate("WebBrowser",{amount:amount,userObj:props.userObj});
            }else{
                alert('INVALID AMOUNT','Please enter a value which is equal or greater than R120')
            }
        }
    }
    const selectedCreditMenu = (option)=>{
        if(option===1){
            setModalVisible(true);
        }
    }
    return(
        <View style={{flex:1}}>
            <View style={{padding:10,flexDirection:'row',flex:3}}>
                <TouchableOpacity style={{padding:5,flex:2}} onPress={()=>{props.navigation.goBack()}}>
                    <FontAwesome name="angle-left" color="#fff" size={36}></FontAwesome>
                </TouchableOpacity>
                <TouchableOpacity style={{padding:5,flex:2,flexDirection:'row-reverse'}}>
                    <Menu onSelect={value => {selectedCreditMenu(value)}}>
                    <MenuTrigger><FontAwesome name="navicon" color="#fff" size={30}></FontAwesome></MenuTrigger>
                    <MenuOptions>
                        <MenuOption value={1} text='TOP UP CREDITS' />
                        <MenuOption value={2} text='TRANSFER CREDITS'></MenuOption>
                        <MenuOption value={3} text='WITHDRAW CREDITS' />
                    </MenuOptions>
                    </Menu>
                </TouchableOpacity>
            </View>
            <View style={{flex:0.5,flexDirection:'row',bottom:10}}>
                <TouchableOpacity style={{padding:5,flex:2}} onPress={()=>{props.navigation.goBack()}}>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{width:50,height:50,padding:10,borderRadius:100,alignItems:'center'}}>
                        <FontAwesome name="arrow-circle-right" color="#fff" size={30}></FontAwesome>
                    </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity style={{padding:5,flex:2,flexDirection:'row-reverse'}}>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{width:50,height:50,padding:10,borderRadius:100,alignItems:'center'}}>
                        <FontAwesome name="plus-circle" color="#fff" size={30}></FontAwesome>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
            <ModalScreen isVisible={modalVisible} closeModal={closeModal} callback={callback} modalAttr={modalAttr}/>
        </View>
    )
}
export default CreditScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,
        borderColor:'#009387',borderWidth:1,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 25,
        borderColor: '#AEB5BC',
        borderRadius:5,
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        borderWidth:1,
        padding:5,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        //backgroundColor:'#92e6f5',
        borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
});

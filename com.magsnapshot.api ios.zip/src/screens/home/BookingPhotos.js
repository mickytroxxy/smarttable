import React,{useContext,useState} from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Dimensions } from 'react-native';
import {FontAwesome,Feather} from 'react-native-vector-icons';
import { UserContext } from '../../../components/context'
import ModalScreen from './Modal';
import GridImageView from 'react-native-grid-image-viewer';
import { socket } from '../../../components/socket';
import moment from 'moment';
let photoExistObj=[],getNetworkStat;
const BookingPhotos = ({route,navigation}) =>{
    const {fontFamilyObj,carObj,showToast,getNetworkStatus,getLastIndex} = useContext(UserContext);
    getNetworkStat=getNetworkStatus;
    const { options } = route.params;
    const [photos,setPhotos]=useState([]);
    const [modalStatus, setModalStatus] = useState({isVisible:false,result:null,target:"add-comment"});
    function closeModal(response) {
        setModalStatus({...modalStatus,isVisible:false});
        if(response){
            visitCamera(response.value);
        }
    }
    React.useEffect(()=>{
        const tempPhotos = [];
        const localUrl = "http://192.168.0.185:8080";
        const remoteUrl = "http://196.61.18.205:8080";
        let baseImg = null;
        getLastIndex();
        if(options.category=="BOOKING PHOTOS"){
            getBookingPhotos(carObj.Key_Ref,(result,uri)=>{
                uri.includes(".185")?baseImg=localUrl:baseImg=remoteUrl;
                result&&result.map((item, i) =>  {
                    const url = baseImg+"/mag_qoutation/mag_snapshot/security_images/"+carObj.Key_Ref+"/"+item.url;
                    tempPhotos.push({image:url});
                    if(i==0){
                        setPhotos(tempPhotos);
                    }
                })
            });
        }else{
            getOtherPhotos(options.category,carObj.Key_Ref,(result,uri)=>{
                uri.includes(".185")?baseImg=localUrl:baseImg=remoteUrl;
                result&&result.map((item, i) =>  {
                    const url = baseImg+"/mag_qoutation/photos/"+carObj.Key_Ref+"/"+item.picture_name;
                    tempPhotos.push({image:url});
                    if(i==0){
                        setPhotos(tempPhotos);
                    }
                })
            })
        }
    },[])
    const goToCamera=()=>{
        if(options.category=="WORK IN PROGRESS"){
            setModalStatus({...modalStatus,isVisible:true})
        }else{
            visitCamera("")
        }
    }
    const visitCamera=(comment)=>{
        checkIfPhotoExist(options.category,options.subCategory,(counter)=>{
            if(counter!="canNot"){
                navigation.navigate("CameraScreen",{options,counter,comment})
            }else{
                showToast("More than enough photos were taken today!")
            }
        });
    }
    return(
        <View style={styles.container}>
            <View style={{flex:0.5,marginTop:30,alignContent:'center',alignItems:'center'}}>
                <View style={{backgroundColor:'#5586cc',padding:7,borderRadius:10}}>
                    <TouchableOpacity style={{flexDirection:'row'}} onPress={()=>navigation.goBack()}>
                        <FontAwesome name="times-circle-o" size={22} color="#fff" style={{marginTop:3}}></FontAwesome>
                        <Text style={{fontSize:18,fontFamily:fontFamilyObj.customBold,color:'#fff'}}> {options.category}</Text>
                    </TouchableOpacity>
                </View>
            </View>
            <View style={{flex:2.5}}>
                {photos&&(
                    <GridImageView data={photos} />
                )}
            </View>
            <View style={[styles.galleryOptionFooter,{width:'96%',alignSelf:'center',justifyContent:'center'}]}>
                <View style={styles.center}><Text style={[styles.center,{fontFamily:fontFamilyObj.customBold,color:'#757575',fontSize:18}]}>{options.subCategory}</Text></View>
                <View style={styles.center}>
                    <TouchableOpacity onPress={goToCamera}>
                        <Feather name="camera" size={75} color="#5586cc"></Feather>
                    </TouchableOpacity>
                </View>
            </View>
            <ModalScreen modalStatus={modalStatus} closeModal={closeModal}/>
        </View>
    )
};
const getBookingPhotos = (activeKeyRef,cb) =>{
    getNetworkStat((socket,url)=>{
        socket.emit("getBookings",activeKeyRef,(result)=>{
            photoExistObj=result;
            cb(result,url);
        })
    })
}
const getOtherPhotos = (category,activeKeyRef,cb) =>{
    getNetworkStat((socket,url)=>{
        socket.emit("getOtherPhotos",activeKeyRef,category,(result)=>{
            photoExistObj=result;
            cb(result,url);
        })
    })
}
const checkIfPhotoExist = (category,stage,cb) =>{
    let wipCounter = 0;
    const nowDate = moment(new Date(Date.now())).format("YYYY-MM-DD");
    var counter = photoExistObj.length;
    if(photoExistObj.length>0){
        if(category=="BOOKING PHOTOS"){
            photoExistObj.map((item, i) =>  {
                var date = item.date;
                var photo_type = item.photo_type;
                if(date==nowDate && photo_type==stage){
                    wipCounter="canNot";
                }
                counter--;
                if(counter==0){
                    cb(wipCounter)
                }
            })
        }else if(category=="WORK IN PROGRESS"){
            photoExistObj.map((item, i) =>  {
                var date = item.date;
                var photo_type = item.stage;
                if(date==nowDate && photo_type==stage){
                    wipCounter++;
                }
                counter--;
                if(counter==0){
                    if(wipCounter>3){
                        cb("canNot");
                    }else{
                        cb(wipCounter)
                    }
                }
            })
        }else{
            cb(wipCounter)
        }
    }else{
        cb(wipCounter)
    }
}
export default BookingPhotos;
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#e8e9f5'
    },
    center:{
        alignContent:'center',alignItems:'center',justifyContent:'center'
    },
    carDetails:{
        width:'98%',
        alignSelf:'center',
        backgroundColor:'#fff',
        flex:1.5,
        borderRadius:20,
        marginTop:35,
    },
    performAction:{
        width:'98%',
        alignSelf:'center',
        flex:2.5,
    },
    cardBtn:{
        justifyContent:'center',
        alignItems:'center',
        alignContent:'center',
        height:100,
        width:'94%',
        borderRadius:20
    },
    galleryOptionFooter: {
        flex: 1,
        backgroundColor: "#fff",
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        //paddingVertical: 10,
        //paddingHorizontal: 5,
        shadowColor: "#B0B0B0",
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        zIndex:100,
    },
});
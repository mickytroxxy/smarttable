import * as firebase from 'firebase';
import 'firebase/firestore';
import 'firebase/storage'
const firebaseConfig = {
  apiKey: "AIzaSyCJjFLGuROwW1OOGFIqlWDh4YRFMJK1Mi8",
  authDomain: "wetowing-9fcd4.firebaseapp.com",
  databaseURL: "https://wetowing-9fcd4.firebaseio.com",
  projectId: "wetowing-9fcd4",
  storageBucket: "wetowing-9fcd4.appspot.com",
  messagingSenderId: "48619118693",
  appId: "1:48619118693:web:21edd38e014e04dccce68c"
};
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}
export const storage = firebase.storage();
export const db = firebase.firestore();
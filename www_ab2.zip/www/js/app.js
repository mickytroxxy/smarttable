var $ = Dom7;
var app = new Framework7({
  name: 'africanBank', // App name
  theme: 'auto', // Automatic theme detection
  el: '#app', // App root element
  // App store just like redux
  store: store,
  // App routes
  routes: routes,
  on: {
    init: ()=> {
      deviceIsReady();
    },
  }
});
let investmentAmount = 500;
let areaChart;
const months = [3,6,12,24,36,48];
let investmentChartToShow = false;
const api = [
  {
    type: 'Fixed Deposit',
    periodNRate: [{period:3,rate:8},{period:6,rate:10.5},{period:12,rate:12},{period:24,rate:14.3},{period:36,rate:25},{period:48,rate:45}],
  },
  {
    type: 'Notice Deposit',
    periodNRate: [{period:3,rate:11},{period:6,rate:8.5},{period:12,rate:17},{period:24,rate:1.3},{period:36,rate:29},{period:48,rate:56}],
  },
  {
    type: 'Access Deposit',
    periodNRate: [{period:3,rate:5},{period:6,rate:8.5},{period:12,rate:16},{period:24,rate:90.3},{period:36,rate:28},{period:48,rate:400}],
  },
  {
    type: 'Tax Free',
    periodNRate: [{period:3,rate:4},{period:6,rate:7},{period:12,rate:10},{period:24,rate:12.3},{period:36,rate:15},{period:48,rate:25}],
  },
]
function deviceIsReady() {
  setTimeout(() => {
    listMonths();
    createChart(calculateDataSetFromApi(api));
  }, 1000);
}
function listMonths() {
  months.map((month)=>{
    $(".months-select").append("<option value="+month+">"+month+"</option>");
  })
}
const createChart=(datasets)=>{
  areaChart = app.areaChart.create({
    el: '.area-chart-simple',
    tooltip: true,
    axis: true,
    axisLabels: months,
    toggleDatasets: true,
    //lineChart: true,
    datasets: datasets,
    formatTooltipTotal:()=>{
      return '';
    }
  });
}
const calculateDataSetFromApi=(api)=>{
  const dataSetObject = [];
  api.map((obj)=>{
    let values = []
    months.map((period)=>{
      obj.periodNRate.map((periodNRateObj)=>{
        period==periodNRateObj.period&&values.push(((periodNRateObj.rate/100) * investmentAmount) + investmentAmount)
      })
    });
    if(obj.type.includes('Fixed')){
      (!investmentChartToShow||investmentChartToShow=='Fixed')&&dataSetObject.push({label: 'Fixed Deposit',color: '#000',values: values});
    }else if(obj.type.includes('Notice')){
      (!investmentChartToShow||investmentChartToShow=='Notice')&&dataSetObject.push({label: 'Notice Deposit',color: '#f07ef7',values: values});
    }else if(obj.type.includes('Access')){
      (!investmentChartToShow||investmentChartToShow=='Access')&&dataSetObject.push({label: 'Access Deposit',color: '#7ef7df',values: values});
    }else if(obj.type.includes('Tax')){
      (!investmentChartToShow||investmentChartToShow=='Tax')&&dataSetObject.push({label: 'Tax Free',color: 'orange',values: values});
    }
  })
  return dataSetObject;
}
const investmentTypeTabClicked = investmentType => {
  investmentChartToShow==investmentType?investmentChartToShow = false:investmentChartToShow = investmentType;
  areaChart.update({datasets: calculateDataSetFromApi(api)});
}
const newInvestmentAmountEntered=()=>{
  let investment_amount_input= $(".investment_amount_input").val();
  if(investment_amount_input.includes('R')){
    investment_amount_input = investment_amount_input.slice(1,investment_amount_input.length)
  }
  if(parseFloat(investment_amount_input) >= 500)
    investmentAmount = parseFloat(investment_amount_input);
    investmentChartToShow=false;
    areaChart.update({datasets: calculateDataSetFromApi(api)});
}
const investBtnClicked=()=>{
  //const periodSelected = $(".months-select").val();
  app.dialog.alert("You are about to invest "+investmentAmount)
}
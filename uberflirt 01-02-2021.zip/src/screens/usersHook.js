import React, { useEffect, useState } from "react";
import { db } from '../screens/service';
import geohash from "ngeohash";
import {Alert,ToastAndroid } from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Permissions from 'expo-permissions';
const getGeohashRange = (latitude,longitude,distance) => {
  const lat = 0.0144927536231884; // degrees latitude per mile
  const lon = 0.0181818181818182; // degrees longitude per mile
  const lowerLat = latitude - lat * distance;
  const lowerLon = longitude - lon * distance;
  const upperLat = latitude + lat * distance;
  const upperLon = longitude + lon * distance;
  const lower = geohash.encode(lowerLat, lowerLon);
  const upper = geohash.encode(upperLat, upperLon);
  return {
    lower,
    upper
  };
};
const useUsers = () => {
  const [users, usersSet] = React.useState([]);
  const [startCoords, setsTartCoords] = React.useState(null);
  const [userToken,setUserToken]=useState();
  const getUserToken = async(cb)=>{
    try {
      setUserToken(await AsyncStorage.getItem("userToken"));
    } catch (e) {
      showToast(e);
    }
  }
  React.useEffect(() => {
    async function fetchUsers() {
      navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        setsTartCoords({latitude:latitude,longitude:longitude});
        getUserToken();
        const range = getGeohashRange(latitude, longitude, 250);
        db.collection("users").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).limit(50).get().then(querySnapshot => {
          const data = querySnapshot.docs.map(doc => doc.data());
          usersSet(data);
        });
      },error => alert(error.message),{ 
        enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
      );
    }
    if(askPermissionsAsync()){
      fetchUsers();
    }
  }, []);
  return [users,startCoords,confirmDialog,userToken,showToast,getUsersByLocation,updateMyLocation];
};
const askPermissionsAsync = async () => {
    const { status: location } = await Permissions.askAsync(Permissions.LOCATION);
    if (location !== "granted") {
      alert("location service roll not  granted");
      return false;
    }else{
        return true;
    }
};
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
  Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
}
function getUsersByLocation(latitude,longitude,cb){
  const range = getGeohashRange(latitude, longitude, 50);
  db.collection("users").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).limit(50).get().then(querySnapshot => {
    const data = querySnapshot.docs.map(doc => doc.data());
    cb(data);
  });
}
const updateMyLocation = async (userToken)=>{
  await db.collection("requests").where("sender", "==", userToken).where("status", "==", "INTERESTED").get().then(querySnapshot => {
    const data = querySnapshot.docs.map(doc => doc.data());
    if (data.length>0) {
      trackMyLocaation(userToken);
    }else{
      db.collection("requests").where("receiver", "==", userToken).where("status", "==", "INTERESTED").get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        if(data.length>0){
          trackMyLocaation(userToken);
        }
      });
    } 
  });
  updateOnce(userToken);
}
const updateOnce = (userToken) =>{
  navigator.geolocation.getCurrentPosition(position => {
    const { latitude, longitude } = position.coords;
    const hash = geohash.encode(latitude, longitude);
    db.collection("users").doc(userToken).update({latitude:latitude,longitude:longitude,geohash:hash}).then(function() {}).catch(function(error) {});
  },error => {
    //alert(error.message)
  },{ 
    enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
  );
}
const trackMyLocaation = (userToken) =>{
  navigator.geolocation.watchPosition(position => {
    const { latitude, longitude } = position.coords;
    const hash = geohash.encode(latitude, longitude);
    db.collection("users").doc(userToken).update({latitude:latitude,longitude:longitude,geohash:hash}).then(function() {}).catch(function(error) {});
  },error => {
    //alert(error.message)
  },{ 
    enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
  );
}
const showToast = (message)=>{
  ToastAndroid.show(message, ToastAndroid.SHORT); 
}
export default useUsers;

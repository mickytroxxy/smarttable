import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from "@react-navigation/native";
import MapViewScreen from './MapViewScreen';
import ProfileScreen from  './ProfileScreen';
import CreditScreen from  './CreditScreen';
import WebBrowser from  './WebBrowser';
import TrackUserScreen from  './TrackUserScreen';
import CameraScreen from  './Camera';
import PostScreen from  './PostScreen';
import SavePhotoScreen from  './SavePhoto';
import ContactUsScreen from  './ContactUsScreen';
import NotificationScreen from  './NotificationScreen';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { DrawerContent } from "../screens/DrawerContent";
const RootStack = createDrawerNavigator();
const HomeStackScreens = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "#009387",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        drawerContent={props=><DrawerContent {...props} />}>
          <RootStack.Screen
            name="MapViewScreen"
            component={MapViewScreen}
          />
          <RootStack.Screen
            name="TrackUserScreen"
            component={TrackUserScreen}
            options={{ title: "TrackUserScreen", headerLeft:"",unmountOnBlur: true }}
          />
          <RootStack.Screen
            name="ProfileScreen"
            component={ProfileScreen}
            unmountOnBlur={true}
            options={{ title: "add", headerLeft:"",unmountOnBlur: true}}
          />
          <RootStack.Screen
            name="CreditScreen"
            component={CreditScreen}
            options={{ title: "CreditScreen", headerLeft:"" }}
          />
          <RootStack.Screen
            name="WebBrowser"
            component={WebBrowser}
            options={{ title: "", headerLeft:"",unmountOnBlur: true }}
          />
          <RootStack.Screen
            name="CameraScreen"
            component={CameraScreen}
            options={{ title: "", headerLeft:"",unmountOnBlur: true }}
          />
          <RootStack.Screen
            name="PostScreen"
            component={PostScreen}
            options={{ title: "", headerLeft:"", }}
          />
          <RootStack.Screen
            name="SavePhotoScreen"
            component={SavePhotoScreen}
            options={{ title: "", headerLeft:"",unmountOnBlur: true }}
          />
          <RootStack.Screen
            name="NotificationScreen"
            component={NotificationScreen}
            options={{ title: "", headerLeft:"",unmountOnBlur: true }}
          />
          <RootStack.Screen
            name="ContactUsScreen"
            component={ContactUsScreen}
            options={{ title: "", headerLeft:""}}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default HomeStackScreens;
import React,{useContext} from 'react';
import RootStackScreens from "../screens/welcome/RootStackScreens";
import HomeStackScreens from "../screens/home/HomeStackScreens";
import { UserContext } from '../../components/context';
export default function App() {
  const {userState} = useContext(UserContext);
  if(!userState.isUserLogged){
    return(
        <RootStackScreens />
    )
  }else{
    return(
        <HomeStackScreens />
    )
  }
}
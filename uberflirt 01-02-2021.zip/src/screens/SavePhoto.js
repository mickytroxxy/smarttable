import React,{useState,useEffect} from 'react'
import { Dimensions, Button, ImageBackground } from 'react-native'
import { ImageManipulator } from 'expo-image-crop';
import useUsers from './usersHook';
import SpinnerScreen from '../screens/SpinnerScreen';
let isEdited = false;
import { db,storage } from '../screens/service';
import geohash from "ngeohash";
const SavePhotoScreen = ({route,navigation})=>{
    const { path,mediaObj } = route.params;
    const [states,setStates]=useState({isVisible:true,uri:path})
    const { width, height } = Dimensions.get('window');
    const [users,startCoords,confirmDialog,testToken,showToast,getUsersByLocation,updateMyLocation] = useUsers();
    const [loading,setIsLoading]=React.useState({
        isLoading:false, text:''
    })
    const pictureChosen = (res) =>{
        savePhoto(res.uri);
        isEdited=true;
    }
    const onToggleModal = () => {
        setStates({...states,isVisible:!states.isVisible});
        if(!isEdited){
            navigation.goBack();navigation.goBack();
        }
    }
    const uploadDone = ()=>{
        setIsLoading({...loading,isLoading: false,text:''})
        navigation.goBack();navigation.goBack();
    }
    const uri = states.uri;
    const savePhoto = async (file)=>{
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const userToken = mediaObj.userToken;
        let storageRef=null;

        if (mediaObj.type=="avatar") {
            const filename = mediaObj.userToken+".png";
            storageRef = storage.ref().child('avatars/'+userToken+'/'+filename);
        }else{
            const filename = file.substring(file.lastIndexOf('/')+1);
            storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
        }
        setIsLoading({...loading,isLoading: true,text:'Uploading your '+mediaObj.type+', Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            storageRef.getDownloadURL().then(downloadURL => {
                if (mediaObj.type=="avatar") {
                    db.collection("users").doc(userToken).update({avatar:downloadURL}).then(function() {
                        showToast("Your avatar has been updated!");
                        uploadDone();
                    }).catch(function(error) {});
                }else if(mediaObj.type=="photo"){
                    var uuid = Math.floor(Math.random() * (10000000 - 100000000 + 1)) + 100000000;
                    db.collection("photos").doc(uuid.toString()).set({url:downloadURL,phoneNumber:userToken,documentId:uuid.toString()}).then(function() {
                        showToast("Your photo has been uploaded!");
                        uploadDone();
                    }).catch(function(error) {});
                }else if(mediaObj.type=="idPhoto"){
                    db.collection("aboutusers").doc(userToken).update({idPhoto:downloadURL}).then(function() {
                        showToast("Your ID verification photo has been updated!");
                        uploadDone();
                    }).catch(function(error) {});
                }else if(mediaObj.type=="selfiePhoto"){
                    db.collection("aboutusers").doc(userToken).update({selfiePhoto:downloadURL}).then(function() {
                        showToast("Your selfie verification photo has been updated!");
                        uploadDone();
                    }).catch(function(error) {});
                }else if(mediaObj.type=="instaPhoto"){
                    navigator.geolocation.getCurrentPosition(position => {
                        var uuid = Math.floor(Math.random() * (10000000 - 100000000 + 1)) + 100000000 + Date.now();
                        const hash = geohash.encode(position.coords.latitude, position.coords.longitude);
                        db.collection("instaPhotos").doc(uuid.toString()).set({url:downloadURL,phoneNumber:userToken,caption:'',geohash:hash,latitude:position.coords.latitude,longitude:position.coords.longitude,time:Date.now(),likes:0,documentId:uuid.toString()}).then(function() {
                            showToast("Your photo has been uploaded!");
                            uploadDone();
                        }).catch(function(error) {});
                    },error => alert(error.message),{ 
                        enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
                    );
                }
            })
        });
    }
    return(
        <ImageBackground resizeMode="contain" style={{justifyContent: 'center', padding: 20, alignItems: 'center', height, width, backgroundColor: 'black',}} source={ {uri}}>
            {(mediaObj.type=="avatar" || mediaObj.type=="idPhoto" || mediaObj.type=="selfiePhoto")?(
                <ImageManipulator photo={ {uri} } saveOptions={{ "compress": 0.5}} isVisible={states.isVisible} onPictureChoosed={(res) => {pictureChosen(res)}}  onToggleModal={onToggleModal} fixedMask={ {"width": width-5, "height": width-5} }/>
            ):(
                <ImageManipulator photo={ {uri} } isVisible={states.isVisible} onPictureChoosed={(res) => {pictureChosen(res)}}  onToggleModal={onToggleModal}/>
            )}
            {loading.isLoading?(
                <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
            ):null}
        </ImageBackground>
    )
}
export default SavePhotoScreen;
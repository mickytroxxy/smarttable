<h1 align="center">
  <img src="/assets/logo.png" width="150">
<br>
<br>
Tiktok React Native
</h1>

<p align="center">Recreating Tiktok React Native with styled components</p>
<p align="center">Watch on <a href="https://www.youtube.com/watch?v=1oi83QsTG90">Youtube</a></p>

<div align="center">
   <a href="https://www.youtube.com/watch?v=1oi83QsTG90">
   <img align="center" src="/assets/app.gif" width="230px">
   </a>

</div>

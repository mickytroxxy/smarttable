import "react-native-gesture-handler";
import "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import React, { useEffect, useState } from "react";
import {ToastAndroid } from "react-native";
import RootStackScreen from "./src/screens/RootStackScreen";
import Home from "./src/screens/Home";
import { AuthContext } from "./src/components/context";
import { socket } from "./src/screens/Socket";
import { db } from "./src/screens/service";
import { View } from "react-native-animatable";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Text,
  ActivityIndicator,
} from "react-native";
function App() {
  const [isLoading, setIsLoading] = React.useState(true);
  const [userToken, setUserToken] = React.useState(null);
  const showToast = (message)=>{
    ToastAndroid.show(message, ToastAndroid.SHORT); 
  }
  const authContext = React.useMemo(
    () => ({
      setUserTokenFn: async (phoneNumber) => {
        try {
          await AsyncStorage.setItem("userToken", phoneNumber);
          setUserToken(phoneNumber), setIsLoading(false);
        } catch (e) {
          showToast(e);
        }
      },
      signOut: async () => {
        try {
          await AsyncStorage.removeItem("userToken");
          setUserToken(null), setIsLoading(false);
        } catch (e) {
          showToast(e);
        }
      },
      getUserToken: (cb) => {
        setTimeout( async() => {
          try {
            cb(await AsyncStorage.getItem("userToken"))
          } catch (e) {
            showToast(e);
          }
        }, 500);
      },
    }),
    []
  );
  useEffect(() => {
    setTimeout(async() => {
      try {
        setUserToken(await AsyncStorage.getItem("userToken")),
        setIsLoading(false);
      } catch (e) {
        showToast(e);
      }
    }, 500);
  }, []);
  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="green"></ActivityIndicator>
        <Text>Authenticating...</Text>
      </View>
    );
  }else{
    return (
      <AuthContext.Provider value={authContext}>
        {userToken === null ? <RootStackScreen /> : <Home />}
        <StatusBar style="light" />
      </AuthContext.Provider>
    );
  }
}
export default App;
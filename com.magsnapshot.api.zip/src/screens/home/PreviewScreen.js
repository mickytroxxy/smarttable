import React,{useContext,useState} from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, Image, Dimensions,ActivityIndicator } from 'react-native';
const PreviewScreen = ({route,navigation}) =>{
    const {url} = route.params;
    React.useEffect(()=>{
       
    },[])
    return(
        <View style={styles.container}>
            <View style={{width:300,height:300,justifyContent:'center'}}>
                <Image source={{uri:url}} style={{height:300}}></Image>
            </View>
        </View>
    )
};
export default PreviewScreen;
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#fff',
        alignContent:'center',alignItems:'center',justifyContent:'center'
    },
    cardHeader:{
        elevation:1,height:40,justifyContent:'center',padding:3,borderTopLeftRadius:5,borderTopRightRadius:5
    },
    cardRows:{
        height:40,borderBottomWidth:1,borderBottomColor:'#e3e6ea',
        justifyContent:'center',backgroundColor:'#fff',marginLeft:2,marginRight:2
    },
    center:{
        alignContent:'center',alignItems:'center',justifyContent:'center'
    },
    carDetails:{
        width:'98%',
        alignSelf:'center',
        backgroundColor:'#fff',
        flex:1.5,
        borderRadius:20,
        marginTop:35,
    },
    performAction:{
        width:'98%',
        alignSelf:'center',
        flex:2.5,
    },
    cardBtn:{
        justifyContent:'center',
        alignItems:'center',
        alignContent:'center',
        height:100,
        width:'94%',
        borderRadius:20
    },
    galleryOptionFooter: {
        flex: 1,
        backgroundColor: "#fff",
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        //paddingVertical: 10,
        //paddingHorizontal: 5,
        shadowColor: "#B0B0B0",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        zIndex:100,
    },
});
import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import SpinnerScreen from '../screens/SpinnerScreen';
import React, { useEffect, useState } from "react";
import { StyleSheet,Modal, Platform, Text, View, SafeAreaView, Image, ScrollView, Alert,Button, Dimensions , TouchableOpacity} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import { db,storage } from '../screens/service';
import { AuthContext } from "../components/context";
import { Col, Row, Grid } from 'react-native-easy-grid';
import { useIsFocused } from '@react-navigation/native';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import useUsers from './usersHook';
import ModalScreen from './Modal';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import ImageViewer from 'react-native-image-zoom-viewer';
import { Container, Item, Input, Header, Content, ListItem, Left, Body, Right, Switch,List } from 'native-base';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
  } from 'react-native-popup-menu';  
const Stack = createStackNavigator();
let profileOwner = true;
let userToken = null;
let userObj = null;
let viewerToken = null;
let loopCounter = -1;
let requestObj = null;
let users,startCoords,confirmDialog,globalUserToken,showToast;
const ProfileScreen = ({route,navigation}) =>{
    const isFocused = useIsFocused();
    if(isFocused);
    const [usersNew,startCoordsNew,confirmDialogNew,testTokenNew,showToastNew] = useUsers();
    users=usersNew;startCoords=startCoordsNew;confirmDialog=confirmDialogNew;showToast=showToastNew;
    const [avatar, setAvatar ] = useState("../assets/media2.jpg");
    const [requestObject, setRequestObject] = useState(null);
    const { myToken, userObject } = route.params;
    let friendToken = userObject.phoneNumber;
    const [loading,setIsLoading]=React.useState({
        isLoading:false, text:''
    })
    userObj = [userObject];
    viewerToken = myToken;
    if(myToken==friendToken){
        userToken = myToken;
        profileOwner = true;
    }else{
        userToken = friendToken;
        profileOwner=false;
    }
    React.useEffect(() => {
        navigation.addListener("focus", async() => {
            if (Platform.OS !== 'web') {
                const { status } = await ImagePicker.requestCameraRollPermissionsAsync();
                if (status !== 'granted') {
                    alert('Sorry, we need camera roll permissions to make this work!');
                }
            }
            setAvatar(userObj[0].avatar);
            getConnectionStatus();
        });
    }, []);
    const getConnectionStatus = ()=>{
        db.collection("requests")
        .where("connectionId", "in", [userToken+viewerToken,viewerToken+userToken])
        .get().then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            if (data.length>0) {
                requestObj=data[0];
                setRequestObject(data[0])
            }else{
                requestObj = null;
                setRequestObject(null)
            }
        });
    }
    return(
        <ParallaxScroll
            headerHeight={50}
            isHeaderFixed={false}
            parallaxHeight={250}
            fadeOutParallaxBackground={true}
            renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue} avatar={avatar}/>}
            renderParallaxForeground={({ animatedValue }) => <Foreground setIsLoading={[loading,setIsLoading]} setAvatar={setAvatar} requestObject={requestObject} setRequestObject={setRequestObject}/>}
            parallaxBackgroundScrollSpeed={5}
            useNativeDriver={true}
            parallaxForegroundScrollSpeed={2.5}
            >
            <ParallaxBody navigation={navigation} setRequestObject={setRequestObject} setIsLoading={[loading,setIsLoading]}/>
            {loading.isLoading?(
                <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
            ):null}
        </ParallaxScroll> 
    )
};
const Background = props =>{
    return(
        <View style={GlobalStyles.ProfileHeader}>
            <Animatable.Image animation="slideInDown" duration={1500} useNativeDriver={true} source={{uri: props.avatar!=""?props.avatar:'https://picsum.photos/400/400'}} style={GlobalStyles.profilepic} resizeMode="stretch"></Animatable.Image>
        </View>
    )
}
const ParallaxBody = props =>{
    const [photosArray, setPhotosArray] = React.useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [photoBrowserVisible, setPhotoBrowserVisible] = useState(false);
    const [modalAttr, setModalAttr] = useState({toOpen:'FILE BROWSER',headerText:'SELECT FROM',values:''});
    const [prices,setPrices]=useState(
        {Drink:0,Massage:0,Flirting:0,Booking:0,DrinkDesc:'NO DESCRIPTION',MassageDesc:'NO DESCRIPTION',FlirtingDesc:'NO DESCRIPTION',BookingDesc:'NO DESCRIPTION'}
    )
    const [aboutUser,setAboutUser]=useState({
        phoneNumber:userToken,
        about:'This user does not have the about info. Please be cautious about this user',
        birthDay:'01/01/2002',
        gender:'UNKNOWN',
        selfiePhoto:'',
        idPhoto:'',
        facebookLink:'www.facebook.com/uberflirt'
    })
    function closeModal() {
        setModalVisible(false);
    }
    async function callback(file,status) {
        if(status=="FILE"){
            const response = await fetch(file);
            const blob = await response.blob();
            var metadata = {contentType: 'image/png',};
            const filename = file.substring(file.lastIndexOf('/')+1);
            const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your file, Please wait...'})
            await storageRef.put(blob,metadata).then(function(snapshot) {
                const newArray = photosArray.concat({url:file});
                setPhotosArray(newArray);
                storageRef.getDownloadURL().then(downloadURL => {
                    var uuid = Math.floor(Math.random() * (10000000 - 100000000 + 1)) + 100000000;
                    db.collection("photos").doc(uuid.toString()).set({url:downloadURL,phoneNumber:userToken,documentId:uuid.toString()}).then(function() {
                        showToast("Your photo has been uploaded!");
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error writing document: ", error);
                    });
                })
            });
        }else if(status=="FEE"){
            updateFee(file);
        }else if(status=="REQUESTSENDING"){
            sendRequest(file);
        }else if(status=="ABOUT"){
            updateAbout(file);
        }else if(status=="BIRTHDAY"){
            updateBirthDay(file);
        }else if(status=="GENDER"){
            updateGender(file);
        }else if(status=="FACEBOOK"){
            updateFacebook(file);
        }else if(status=="SELFIE"){
            updateSelfie(file);
        }else if(status=="ID PHOTO"){
            updateIdPhoto(file);
        }
    }
    React.useEffect(() => {
        props.navigation.addListener("focus", async() => {
            db.collection("photos").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                setPhotosArray(data)
            });
            db.collection("prices").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                if(data.length>0){
                    setPrices(data[0]);
                }else{
                    setPrices({Drink:0,Massage:0,Flirting:0,Booking:0,DrinkDesc:'NO DESCRIPTION',MassageDesc:'NO DESCRIPTION',FlirtingDesc:'NO DESCRIPTION',BookingDesc:'NO DESCRIPTION'})
                }
            });
            db.collection("aboutusers").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                if(data.length>0){
                    setAboutUser(data[0])
                }
            });
            if(profileOwner){
                db.collection("aboutusers").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                    const data = querySnapshot.docs.map(doc => doc.data());
                    if (data.length==0) {
                        db.collection("aboutusers").doc(userToken).set(aboutUser).then(function() {
                            showToast("Please setup your about section!");
                        }).catch(function(error) {});
                    }
                });
            }
        });
    }, []);
    const actionTaken =(option)=>{
        if(profileOwner){
            setModalVisible(true);
            setModalAttr({...modalAttr,headerText:"UPDATE "+option+" FEE",toOpen:"UPDATE FEE MODAL",values:[prices[option],prices[option+"Desc"]]})
        }else{
            setModalVisible(true);
            setModalAttr({...modalAttr,headerText:"THEIR "+option+" FEE IS "+prices[option]+"c",toOpen:"SEND A REQUEST",values:[prices[option],prices[option+"Desc"]]})
        }
    }
    const sendRequest = (returnArray)=>{
        let connectionId;
        const price = returnArray[0];
        const requestType = returnArray[1];
        if ( requestObj==null ) {
            connectionId = viewerToken+userToken;
        }else{
            connectionId = requestObj.connectionId;
        }
        confirmDialog("SEND "+requestType.toUpperCase()+" REQUEST","This user requires "+price+"c for this request, Your account will be deducted by "+price+"c just after you confirm the arrival of "+userObj[0].fname,"Confirm","Cancel",(cb)=>{
            if(cb){
                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Placing your request, Please wait...'});
                getUserBalance(viewerToken, (balance)=>{
                    if(balance>=parseFloat(price)){
                        db.collection("requests").doc(connectionId).set({sender:viewerToken,fee:price,receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now()}).then(function() {
                            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                            showToast("Your request has been send for approval");
                            props.setRequestObject({sender:viewerToken,fee:price,receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now()})
                        }).catch(function(error) {
                            console.error("Error writing document: ", error);
                        });
                    }
                })
            }
        })
    }
    const updateFee = (returnArray)=>{
        let newPrices = null;
        confirmDialog("CONFIRM UPDATE","Are you sure you want to update your "+returnArray[1]+" fee to "+returnArray[0]+'c?',"Confirm","Cancel",(cb)=>{
            if(cb){
                if(returnArray[1]=="Drink"){
                    newPrices = {
                        Drink:returnArray[0],Massage:prices.Massage,Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:returnArray[1],MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc
                    };
                }else if(returnArray[1]=="Massage"){
                    newPrices = {
                        Drink:prices.Drink,Massage:returnArray[0],Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:returnArray[1],FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc
                    };
                }else if(returnArray[1]=="Flirting"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:returnArray[0],Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:returnArray[1],BookingDesc:prices.BookingDesc
                    };
                }else if(returnArray[1]=="Booking"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:prices.Flirting,Booking:returnArray[0],phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:returnArray[1]
                    };
                }
                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your service fee, Please wait...'})
                db.collection("prices").doc(userToken).set(newPrices).then(function() {
                    showToast("Your fee updates where applied!");
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    setPrices(newPrices);
                }).catch(function(error) {
                    console.error("Error writing document: ", error);
                });
            }
        })
    }
    const editProfile = (option) =>{
        setModalVisible(true);
        setModalAttr({toOpen:option,headerText:option,values:''})
    }
    const updateSelfie = async (file) =>{
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = file.substring(file.lastIndexOf('/')+1);
        const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your selfie photo, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            storageRef.getDownloadURL().then(downloadURL => {
                db.collection("aboutusers").doc(userToken).update({selfiePhoto:downloadURL}).then(function() {
                    showToast("Your selfie verification photo has been updated!");
                    setAboutUser({...aboutUser,selfiePhoto:downloadURL});
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                }).catch(function(error) {});
            })
        });
    }
    const updateIdPhoto = async (file) =>{
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = file.substring(file.lastIndexOf('/')+1);
        const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your ID photo, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            storageRef.getDownloadURL().then(downloadURL => {
                db.collection("aboutusers").doc(userToken).update({idPhoto:downloadURL}).then(function() {
                    showToast("Your ID verification photo has been updated!");
                    setAboutUser({...aboutUser,idPhoto:downloadURL});
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                }).catch(function(error) {});
            })
        });
    }
    const updateAbout = (about)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your about section, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({about:about}).then(function() {
            showToast("Your about section has been updated!");
            setAboutUser({...aboutUser,about:about});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateBirthDay = (birthDay)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your birth day, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({birthDay:birthDay}).then(function() {
            showToast("Your birth day has been updated!");
            setAboutUser({...aboutUser,birthDay:birthDay});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateGender = (gender)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your gender, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({gender:gender}).then(function() {
            showToast("Your gender has been updated!");
            setAboutUser({...aboutUser,gender:gender});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateFacebook = (facebookLink)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your facebook link, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({facebookLink:facebookLink}).then(function() {
            showToast("Your facebook link has been updated!");
            setAboutUser({...aboutUser,facebookLink:facebookLink});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const ageCalculator = (birthDay) =>{
        var birth = new Date(birthDay);
        var check = new Date();
        var milliDay = 1000 * 60 * 60 * 24;
        var ageInDays = (check - birth) / milliDay;
        var ageInYears =  Math.floor(ageInDays / 365 );
        var age =  ageInDays / 365 ;
        return age;
    }
    return(
        <Animatable.View style={GlobalStyles.ProfileFooter} animation="slideInUp" duration={1000} useNativeDriver={true}>
            <View style={styles.ProfileFooterHeader}>
                <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                    <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                </View>
                {profileOwner?(
                    <View style={styles.statsContainer}>
                    <View style={styles.statsBox}>
                        <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>483</Text>
                        <Text style={[styles.text, styles.subText]}>Meetups</Text>
                    </View>
                    <View style={[styles.statsBox, { borderColor: "#e1ece7", borderLeftWidth: 0.5, borderRightWidth: 0.5 }]}>
                        <TouchableOpacity onPress={() => {props.navigation.navigate("CreditScreen",{userObj: userObj[0]})}}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>{userObj[0].balance}</Text>
                            <Text style={[styles.text, styles.subText]}>Credits</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.statsBox}>
                    <TouchableOpacity onPress={() => {props.navigation.navigate("Settings",{fname: userObj[0].fname, phoneNumber: userObj[0].phoneNumber,password: userObj[0].password,latitude:userObj[0].latitude,longitude:userObj[0].longitude,geohash:userObj[0].geohash,avatar:userObj[0].avatar })}}>
                        <MaterialIcons name="account-circle" size={36} color="#c792f5" alignSelf="center"></MaterialIcons>
                    </TouchableOpacity>
                    </View>
                    </View>
                ):(
                    <View style={styles.statsContainer}>
                        <View style={styles.statsBox}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>483</Text>
                            <Text style={[styles.text, styles.subText]}>Likes</Text>
                        </View>
                        <View style={[styles.statsBox, { borderColor: "#e1ece7", borderLeftWidth: 0.5, borderRightWidth: 0.5 }]}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>4.5</Text>
                            <Text style={[styles.text, styles.subText]}>Ratings</Text>
                        </View>
                        <View style={styles.statsBox}>
                            <TouchableOpacity onPress={() => {props.navigation.navigate("Settings",{fname: userObj[0].fname, phoneNumber: userObj[0].phoneNumber,password: userObj[0].password,latitude:userObj[0].latitude,longitude:userObj[0].longitude,geohash:userObj[0].geohash,avatar:userObj[0].avatar })}}>
                                <MaterialIcons name="phone" size={36} color="#c792f5" alignSelf="center"></MaterialIcons>
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            </View>
            <View style={{ marginTop: 5 }}>
                <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{padding:10,paddingRight:20}}>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Drink')}>
                            <Text style={GlobalStyles.actionViewText}>{prices.Drink}c</Text>
                            <FontAwesome name="glass" color="#fff" size={30}></FontAwesome>
                            <Text style={GlobalStyles.actionViewText}>Drink</Text>
                            {profileOwner ? (
                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                            </TouchableOpacity>
                    </LinearGradient>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Massage')}>
                            <Text style={GlobalStyles.actionViewText}>{prices.Massage}c</Text>
                            <FontAwesome name="bathtub" color="#fff" size={30}></FontAwesome>
                            <Text style={GlobalStyles.actionViewText}>Massage</Text>
                            {profileOwner ? (
                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                        </TouchableOpacity>
                    </LinearGradient>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Flirting')}>
                            <Text style={GlobalStyles.actionViewText}>{prices.Flirting}c</Text>
                            <FontAwesome name="comments" color="#fff" size={30}></FontAwesome>
                            <Text style={GlobalStyles.actionViewText}>Flirting</Text>
                            {profileOwner ? (
                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                        </TouchableOpacity>
                    </LinearGradient>
                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Booking')}>
                            <Text style={GlobalStyles.actionViewText}>{prices.Booking}c</Text>
                            <FontAwesome name="heart" color="#fff" size={25}></FontAwesome>
                            <Text style={GlobalStyles.actionViewText}>Special</Text>
                            <Text style={GlobalStyles.actionViewText}>Booking</Text>
                            {profileOwner ? (
                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                        </TouchableOpacity>
                    </LinearGradient>
                </ScrollView>
            </View>
            <View style={{ marginTop: 15,padding:5,borderTopWidth:1,borderTopColor:'#f9f4f7' }}>
                <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                {profileOwner ? (
                    <LinearGradient colors={["#f2f7f7","#f7f5f2", "#c792f5"]} style={{borderRadius:10,}}>
                    <View style={[styles.statsContainer],{width:50,flex:1,alignContent:'center',alignItems:'center'}}>
                        <TouchableOpacity onPress={()=>{setModalVisible(true);setModalAttr({toOpen:'FILE BROWSER',headerText:'SELECT FROM',values:''})}} >
                            <MaterialIcons name="add-circle" size={36} color="#c792f5" alignSelf="center"></MaterialIcons>
                        </TouchableOpacity>
                        <TouchableOpacity style={{marginTop:10,}}>
                            <MaterialIcons name="edit" size={36} color="#92e6f5" alignSelf="center"></MaterialIcons>
                        </TouchableOpacity>
                        <TouchableOpacity style={{marginTop:10,}}>
                            <MaterialIcons name="cancel" size={36} color="tomato" alignSelf="center"></MaterialIcons>
                        </TouchableOpacity>
                    </View>
                    </LinearGradient>
                ):null}
                {photosArray!=null ? (
                    photosArray.map((item, i) => (
                        <TouchableOpacity key={i} onPress={()=>{setPhotoBrowserVisible(true)}}>
                            <Animatable.View style={styles.mediaImageContainer} animation="slideInRight" duration={1000} useNativeDriver={true}>
                                <Animatable.Image animation="slideInDown" useNativeDriver={true} source={{uri: item.url!=""?item.url:'https://picsum.photos/400/400'}} style={styles.image} resizeMode="cover"></Animatable.Image>
                            </Animatable.View>
                        </TouchableOpacity>
                    ))
                ):null}
                </ScrollView>
            </View>
            <Modal visible={photoBrowserVisible} transparent={true}>
                <ImageViewer imageUrls={photosArray} enableSwipeDown={true} onSwipeDown={()=>setPhotoBrowserVisible(false)} onSwipeDown={()=>setPhotoBrowserVisible(false)} />
            </Modal>
            <View style={{ padding:5 }}>
                <LinearGradient colors={["#e2f2f5", "#e4d3f3"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:10,}}>
                    <View style={styles.recentItem}>
                        <View style={styles.activityIndicator}>
                            <FontAwesome name="user-circle" color="#c792f5" size={24}></FontAwesome>
                        </View>
                        <View style={{ flex:3,backgroundColor:'#fff',borderRadius:10, }}>
                            <View style={{padding:10,backgroundColor:'#f9f4f7',flex:1,flexDirection:'row'}}>
                                <Text style={[styles.text, { color: "#41444B",flex:3, fontWeight: "bold",fontSize:14,fontFamily:'sans-serif-medium',color:'#757575' }]}>ABOUT</Text>
                                {profileOwner?(
                                    <TouchableOpacity onPress={()=>editProfile("ABOUT")}>
                                        <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                    </TouchableOpacity>
                                ):null}
                            </View>
                            <View style={{padding:10}}>
                                <Text style={[styles.text, { color: "#41444B", fontWeight: "300" }]}>{aboutUser.about}</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>
            </View>
            <View>
                <List>
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon>
                        <Left><FontAwesome name="child" size={30} color="#c792f5" alignSelf="center"></FontAwesome></Left>
                        <Body>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}> AGE</Text>
                        </Body>
                        <Right>
                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{ageCalculator(aboutUser.birthDay).toFixed(0)}  </Text>
                            {profileOwner?(
                                <TouchableOpacity onPress={()=>editProfile("AGE")}>
                                    <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                </TouchableOpacity>
                            ):null}
                        </Right>
                    </ListItem>
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon>
                        <Left><FontAwesome name="mars" size={30} color="#c792f5" alignSelf="center"></FontAwesome></Left>
                        <Body>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>GENDER</Text>
                        </Body>
                        <Right>
                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{aboutUser.gender}  </Text>
                            {profileOwner?(
                                <TouchableOpacity onPress={()=>editProfile("GENDER")}>
                                    <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                </TouchableOpacity>
                            ):null}
                        </Right>
                    </ListItem>
                </List>
            </View>
            <View style={{ padding:5,marginTop:15 }}>
                <LinearGradient colors={["#e2f2f5", "#e4d3f3"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:10,}}>
                    <View style={styles.recentItem}>
                        <View style={styles.activityIndicator}>
                            <FontAwesome name="id-card" color="#c792f5" size={18}></FontAwesome>
                        </View>
                        <View style={{ flex:3,backgroundColor:'#fff',borderRadius:10, }}>
                            <View style={{padding:10,backgroundColor:'#f9f4f7',flex:1,flexDirection:'row'}}>
                                <Text style={[styles.text, { color: "#41444B",flex:3, fontWeight: "bold",fontSize:14,fontFamily:'sans-serif-medium',color:'#757575' }]}>ID VERIFICATION PHOTO</Text>
                                {profileOwner?(
                                    <TouchableOpacity onPress={()=>editProfile("ID VERIFICATION PHOTO")}>
                                        <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                    </TouchableOpacity>
                                ):null}
                            </View>
                            <View style={{padding:10}}>
                                <Text style={[styles.text, { color: "#41444B", fontWeight: "300" }]}>ID</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>
            </View>
            <View style={{ padding:5 }}>
                <LinearGradient colors={["#e2f2f5", "#e4d3f3"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:10,}}>
                    <View style={styles.recentItem}>
                        <View style={styles.activityIndicator}>
                            <MaterialIcons name="photo-camera" color="#c792f5" size={24}></MaterialIcons>
                        </View>
                        <View style={{ flex:3,backgroundColor:'#fff',borderRadius:10, }}>
                            <View style={{padding:10,backgroundColor:'#f9f4f7',flex:1,flexDirection:'row'}}>
                                <Text style={[styles.text, { color: "#41444B",flex:3, fontWeight: "bold",fontSize:14,fontFamily:'sans-serif-medium',color:'#757575' }]}>SELFIE VERIFICATION PHOTO</Text>
                                {profileOwner?(
                                    <TouchableOpacity onPress={()=>editProfile("SELFIE VERIFICATION PHOTO")}>
                                        <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                    </TouchableOpacity>
                                ):null}
                            </View>
                            <View style={{padding:10}}>
                                <Text style={[styles.text, { color: "#41444B", fontWeight: "300" }]}>SELFIE</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>
            </View>
            <View style={{ padding:5 }}>
                <LinearGradient colors={["#e2f2f5", "#e4d3f3"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:10,}}>
                    <View style={styles.recentItem}>
                        <View style={styles.activityIndicator}>
                            <FontAwesome name="facebook" color="#c792f5" size={24}></FontAwesome>
                        </View>
                        <View style={{ flex:3,backgroundColor:'#fff',borderRadius:10, }}>
                            <View style={{padding:10,backgroundColor:'#f9f4f7',flex:1,flexDirection:'row'}}>
                                <Text style={[styles.text, { color: "#41444B",flex:3, fontWeight: "bold",fontSize:14,fontFamily:'sans-serif-medium',color:'#757575' }]}>FACEBOOK LINK</Text>
                                {profileOwner?(
                                    <TouchableOpacity onPress={()=>editProfile("FACEBOOK LINK")}>
                                        <FontAwesome name="edit" color="green" size={24}></FontAwesome>
                                    </TouchableOpacity>
                                ):null}
                            </View>
                            <View style={{padding:10,justifyContent:'center',alignItems:'center',alignContent:'center',flex:1}}>
                                <Button title="VISIT LINK"></Button>
                            </View>
                        </View>
                    </View>
                </LinearGradient>
            </View>
            <ModalScreen isVisible={modalVisible} closeModal={closeModal} callback={callback} modalAttr={modalAttr}/>
        </Animatable.View>
    )
}
function  getUserBalance(user,cb) {
    db.collection("users").where("phoneNumber", "==", user).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data[0].balance);
    });
}
const Foreground = props =>{
    const [modalVisible, setModalVisible] = useState(false);
    const [modalAttr, setModalAttr] = useState({toOpen:'FILE BROWSER',headerText:'SELECT FROM',values:''});
    const [users,startCoords,confirmDialog] = useUsers();
    function closeModal() {
        setModalVisible(false);
    }
    const requestObject = props.requestObject;
    async function callback(file) {
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = userToken+".png";
        const storageRef = storage.ref().child('avatars/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your avatar, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            props.setAvatar(file);
            if(userObj.length>0){
                storageRef.getDownloadURL().then(downloadURL => {
                    db.collection("users").doc(userToken).set({fname: userObj[0].fname, phoneNumber: userObj[0].phoneNumber,password: userObj[0].password,latitude:userObj[0].latitude,longitude:userObj[0].longitude,geohash:userObj[0].geohash,avatar:downloadURL }).then(function() {
                        showToast("Your avatar has been updated!");
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error writing document: ", error);
                    });
                })
            }else{
                showToast("Could not update your avatar, Please try again later!")
            }
        });
    }
    const selectedRequestMenu = (option)=>{
        if(option===1){
            confirmDialog(requestObject.requestType.toUpperCase()+" REQUEST",userObj[0].fname+" would like to meet with you for the reason mentioned above. The proposed reward for this meeting is "+requestObject.fee+"c. What do you think?","INTERESTED","NOT NOW",(cb)=>{
                if(cb){
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                    db.collection("requests").doc(requestObj.connectionId).update({status:'INTERESTED'}).then(function() {
                        showToast("Great! Now you can call each other for arrangements if any!");
                        props.setRequestObject({...props.requestObject,status:'INTERESTED'});
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error removing document: ", error);
                    });
                }
            })
        }else if(option===2){
            if(requestObject.sender==viewerToken){
                confirmDialog("CANCEL YOUR REQUEST","Are you sure you want to cancel your "+requestObject.requestType+" request? A cancellation fee of 25% may apply. Press Terminate to proceed","Terminate","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }else{
                confirmDialog("REJECT REQUEST","Are you sure you want to decline this "+requestObject.requestType+" request? Press Decline to reject","Decline","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }
        }else if(option===5){
            if(requestObject.sender==viewerToken){
                confirmDialog("CONFIRM ARRIVAL","Do you confirm that "+userObj[0].fname+" has arrived and you are within few metres apart?."+requestObject.fee+"c will be deducted from your account by pressing the confirm button","I CONFIRM","No",(cb)=>{
                    if(cb){
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                        const transactionId = viewerToken+Date.now();
                        getUserBalance(viewerToken, (viewerBal)=>{
                            getUserBalance(userToken, (userBal)=>{
                                const viewerNewBal = viewerBal - requestObject.fee;
                                const userNewBal = userBal + requestObject.fee;
                                db.collection("users").doc(viewerToken).update({balance:viewerNewBal}).then(function() {
                                    db.collection("users").doc(userToken).update({balance:userNewBal}).then(function() {
                                        db.collection("requests").doc(requestObject.connectionId).delete().then(function() {
                                            db.collection("transactions").doc(transactionId).set({sender:viewerToken,receiver:userToken,amount:requestObject.fee,transactionId:transactionId,date:Date.now(),transactionType:requestObject.requestType,fname:userObj[0].fname,avatar:userObj[0].avatar}).then(function() {
                                                showToast("Congrats guys! Happy meetup. Stay Safe!");
                                                props.setRequestObject(null);
                                                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                            }).catch(function(error) {});
                                        }).catch(function(error) {});
                                    }).catch(function(error) {});
                                }).catch(function(error) {});
                            });
                        })
                    }
                })
            }else{
                confirmDialog("REQUEST ARRIVAL CONFIRMATION","Notify "+userObj[0].fname+" to approve your arrival","Notify","Cancel",(cb)=>{
                    if(cb){
                        alert("A notification has been sent to "+userObj[0].fname+", Your arrival confirmation will be approved");
                    }
                })
            }
        }
    }
    const terminateConnection = () =>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Terminating '+requestObject.requestType+' request, Please wait...'})
        db.collection("requests").doc(requestObject.connectionId).delete().then(function() {
            showToast("This request has been successfully terminated");
            props.setRequestObject(null);
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {
            console.error("Error removing document: ", error);
        });
    }
    return(
        <View style={{flex:1}}>
            <View style={{flex:3}}></View>
            <Animatable.View style={{flex:0.7}} animation="slideInLeft" duration={1000} useNativeDriver={true}>
            <Grid>
                <Col style={{height: 200, }}></Col>
                <Col style={{height: 200 }}></Col>
                <Col style={styles.addPhotoContainer}>
                    {profileOwner ? (
                        <TouchableOpacity onPress={()=>{setModalVisible(true)}}>
                            <Ionicons name="ios-camera" size={50} color="#009387" alignSelf="center"></Ionicons>
                        </TouchableOpacity>
                    ):(
                        <View>
                            {[requestObject].map((item, i) =>  {
                                if(item==null){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <Ionicons name="ios-heart" size={50} color="tomato" alignSelf="center"></Ionicons>
                                        </TouchableOpacity>
                                    )
                                }else if(item.status=="PENDING"){
                                    if(item.sender==viewerToken){
                                        return(
                                            <TouchableOpacity key={i} onPress={()=>{selectedRequestMenu(2)}}>
                                                <FontAwesome name="times-circle" size={50} color="tomato" alignSelf="center"></FontAwesome>
                                            </TouchableOpacity>
                                        )
                                    }else{
                                        return(
                                            <TouchableOpacity key={i} onPress={()=>{}}>
                                                <Menu onSelect={value => {selectedRequestMenu(value)}}>
                                                <MenuTrigger>
                                                    <FontAwesome name="ellipsis-v" size={50} color="#92e6f5" alignSelf="center"></FontAwesome>
                                                </MenuTrigger>
                                                <MenuOptions>
                                                    <MenuOption value={1} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                        <View style={{flex:1}}>
                                                            <FontAwesome name="heart" size={20} color="tomato" alignSelf="center"></FontAwesome>
                                                        </View>
                                                        <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>ACCEPT REQUEST</Text></View>
                                                    </MenuOption>
                                                    <MenuOption value={2} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                        <View style={{flex:1}}>
                                                            <MaterialIcons name="cancel" size={23} color="red" alignSelf="center"></MaterialIcons>
                                                        </View>
                                                        <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>REJECT REQUEST</Text></View>
                                                    </MenuOption>
                                                </MenuOptions>
                                                </Menu>
                                            </TouchableOpacity>
                                        )
                                    }
                                }else if(item.status=="INTERESTED"){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <Menu onSelect={value => {selectedRequestMenu(value)}}>
                                            <MenuTrigger>
                                                <FontAwesome name="ellipsis-v" size={50} color="#92e6f5" alignSelf="center"></FontAwesome>
                                            </MenuTrigger>
                                            <MenuOptions>
                                                <MenuOption value={3} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <MaterialIcons name="phone" size={23} color="green" alignSelf="center"></MaterialIcons>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>MAKE A CALL</Text></View>
                                                </MenuOption>
                                                <MenuOption value={2} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <MaterialIcons name="cancel" size={23} color="red" alignSelf="center"></MaterialIcons>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>TERMINATE REQUEST</Text></View>
                                                </MenuOption>
                                                <MenuOption value={5} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <FontAwesome name="check-circle" size={23} color="green" alignSelf="center"></FontAwesome>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>CONFIRM ARRIVAL</Text></View>
                                                </MenuOption>
                                            </MenuOptions>
                                            </Menu>
                                        </TouchableOpacity>
                                    )
                                }else if(item.status=="CONNECTED"){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <FontAwesome name="phone" size={50} color="green" alignSelf="center"></FontAwesome>
                                        </TouchableOpacity>
                                    )
                                }
                            })}
                        </View>
                        
                    )}
                </Col>
            </Grid>
            </Animatable.View>
            <ModalScreen isVisible={modalVisible}  closeModal={closeModal} callback={callback} modalAttr={modalAttr}/>
        </View>
    )
}
export default ProfileScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 11,
        color: "#fff",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        backgroundColor:'#e7d8d8',borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 150,
        height: 150,
        borderRadius: 10,
        overflow: "hidden",
        marginHorizontal: 10,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16,
        padding:10,
    },
    activityIndicator: {
        marginLeft:-10,
        padding:5,
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    }
});

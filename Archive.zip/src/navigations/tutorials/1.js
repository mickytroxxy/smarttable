import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button } from 'react-native';

export default function App() {
  return (
    /*<View style={styles.container}>
      <Text>hello Mickyjjj</Text>
      <StatusBar style="auto" />
    </View>*/
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
const Stack = createStackNavigator();
const HomeScreen =({navigation})=>{
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Home Screen</Text>
      <Button title="Go to Details" onPress={()=>navigation.navigate("Details")} />
    </View>
  );
}
const DetailsScreen =({navigation})=>{
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Details Screen</Text>
      <Button title="Go to Details again" onPress={()=>navigation.push("Details")} />
      <Button title="Go to Home" onPress={()=>navigation.navigate("Home")} />
      <Button title="Go Back" onPress={()=>navigation.goBack()} />
      <Button title="Go First screen" onPress={()=>navigation.popToTop()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
//import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import { StyleSheet, Platform, Text, View, SafeAreaView, Image, ScrollView, Modal, Alert,Button, Dimensions , TouchableOpacity} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
//import Icon from 'react-native-vector-icons/Ionicons';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Animated,{Easing} from 'react-native-reanimated';
import ActionSheet from './ActionSheet';
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import { db,storage } from '../screens/service';
import { AuthContext } from "../components/context";
import { Col, Row, Grid } from 'react-native-easy-grid';
import { useIsFocused } from '@react-navigation/native';
const Stack = createStackNavigator();
const ProfileScreen = ({route,navigation}) =>{
    const { avatar } = route.params;
    React.useEffect(() => {
        
    }, []);
    return(
        <ParallaxScroll
            headerHeight={50}
            isHeaderFixed={false}
            parallaxHeight={250}
            fadeOutParallaxBackground={true}
            renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue} avatar={avatar}/>}
            renderParallaxForeground={({ animatedValue }) => <Foreground/>}
            parallaxBackgroundScrollSpeed={5}
            useNativeDriver={true}
            parallaxForegroundScrollSpeed={2.5}
            >
            <ParallaxBody navigation={navigation}/>
            
        </ParallaxScroll>
    )
};
const Background = props =>{
    alert('5')
    return(
        <View style={GlobalStyles.ProfileHeader}>
            <Image source={{uri: props.avatar!=""?props.avatar:'https://picsum.photos/400/400'}} style={GlobalStyles.profilepic} resizeMode="stretch"></Image>
        </View>
    )
}
const ParallaxBody = props =>{
    return(
        <View style={GlobalStyles.ProfileFooter}>
           
        </View>
    )
}
const Foreground = props =>{
    return(
        <View style={{flex:1}}>
            
        </View>
    )
}
export default ProfileScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,
        borderColor:'#009387',borderWidth:1,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 25,
        borderColor: '#AEB5BC',
        borderRadius:5,
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        borderWidth:1,
        padding:5,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    }
});

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React, { useEffect, useState,useContext } from "react";
import { StyleSheet, Platform, Text, View, SafeAreaView, Image, ScrollView, Modal, Alert,Button, Dimensions , TouchableOpacity,TextInput} from "react-native";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import{ MaterialIcons,Ionicons,Feather} from "react-native-vector-icons";
import { UserContext } from '../../../components/context'
import { Container,Picker, Header, Content, Item, Input,Textarea, Form, Card, CardItem,Body,ListItem,Right,Left,DatePicker } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';
const ModalScreen = props =>{
    const {fontFamilyObj} = useContext(UserContext);
    const carObj = props.modalStatus.result;
    const stages = ["STRIPPING STAGE","PANEL BEATING STAGE","PAINT PREP STAGE","PAINTING STAGE","ASSEMBLY STAGE","MECHANICAL STAGE","DIAGNOSTICS STAGE","POLISHING STAGE","CLEANING STAGE"]
    const [stageClicked,setStageClicked]=useState(false);
    const [comment,setComment]=useState("");
    React.useEffect(()=>{
        //loadFontsAsync();
    },[])
    if(props.modalStatus.target=="key-picker"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.modalStatus.isVisible} onRequestClose={() => {props.closeModal(null)}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>TAP TO SELECT ONE</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        {
                            carObj&&carObj.map((item, i) =>  {
                                return (
                                    <ListItem key={i} noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon onPress={() => {props.closeModal(item)}}>
                                        <Left>
                                            <Feather name="disc" color="#5586cc" size={24}></Feather>
                                        </Left>
                                        <Body>
                                        <Text style={{color:'#2a2828',fontFamily:fontFamilyObj.customLight}}>{item.Key_Ref}</Text>
                                        </Body>
                                    </ListItem>
                                );
                            })
                        }
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalStatus.target=="stage-picker"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.modalStatus.isVisible} onRequestClose={() => {props.closeModal(null)}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>TAP TO SELECT STAGE</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        {
                            stages.map((item, i) =>  {
                                return (
                                    <ListItem key={i} noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon onPress={() => {props.closeModal({action:"wip",value:item})}}>
                                        <Left>
                                            <Feather name="disc" color="#5586cc" size={24}></Feather>
                                        </Left>
                                        <Body>
                                            <Text style={{color:'#2a2828',fontFamily:fontFamilyObj.customLight}}>{item}</Text>
                                        </Body>
                                    </ListItem>
                                );
                            })
                        }
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalStatus.target=="add-comment"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.modalStatus.isVisible} onRequestClose={() => {props.closeModal(null)}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>ADD A COMMENT</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Grid style={styles.searchInputHolder}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Ionicons name="chatbubble-outline" color="#5586cc" size={18} style={{alignSelf:"center"}}></Ionicons>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="Enter your comment..." onChangeText={(val)=>setComment(val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <View style={{flexDirection:'row',alignItems:'center',alignContent:'center',flex:1,justifyContent:'center'}}>
                            <TouchableOpacity onPress={()=>{props.closeModal()}} style={{margin:30}}>
                                <FontAwesome name="times-circle" size={50} color="tomato" alignSelf="center"></FontAwesome>
                            </TouchableOpacity>  
                            <TouchableOpacity style={{margin:30}} onPress={()=>{props.closeModal({action:"comment",value:comment})}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>  
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else{
        <Modal animationType="slide" transparent={true} visible={false} onRequestClose={() => {props.closeModal(null)}}></Modal>
    }
}
export default ModalScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    serviceDes:{
        borderRadius:10,
        backgroundColor:'#fcf2ef'
    },
    newLabel: {
        color: "#757575",
        fontWeight: "bold",
        fontSize:16,
        marginTop:6,
      },
    preference: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        paddingHorizontal: 16,
    },
    centeredView:{
        minHeight:'60%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 11,
        color: "#fff",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        backgroundColor:'#5586cc',borderTopLeftRadius: 30, borderTopRightRadius: 30,
        elevation: 5,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    textInput: {
        flex: 1,
        marginTop: Platform.OS === 'ios' ? 0 : -2,
        paddingLeft: 10,
        color: '#05375a',
        borderRadius:10,
        borderWidth:0.7,
        borderColor:'#cdcac9'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5'
    },
});
import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MapView from 'react-native-maps';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
import { AuthContext } from '../components/context'
const Stack = createStackNavigator();
const Login = ({navigation}) =>{
    const { signOut } = React.useContext(AuthContext);
    return(
        <View>
            <TouchableOpacity onPress={()=>{signOut()}}>
                <Text style={GlobalStyles.welcome}>LOGOUT</Text>
            </TouchableOpacity>
        </View>
    )
};

export default Login;

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MapView from 'react-native-maps';
import { GlobalStyles } from '../styles/Global';
import  Maps  from './Map';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
const MapScreen = ({navigation}) =>{
    return(
        <SafeAreaView forceInset={{top:'always'}}>
            <Maps />
        </SafeAreaView>
    )
};
export default MapScreen;

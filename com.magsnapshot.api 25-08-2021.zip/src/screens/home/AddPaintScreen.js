import { createStackNavigator } from '@react-navigation/stack';
import React, {useState,useContext } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView, Platform,TouchableOpacity,Text,TextInput} from "react-native";
import {MaterialIcons,FontAwesome,Feather,Ionicons } from "@expo/vector-icons";
import { Picker} from 'native-base';
import { UserContext } from '../../../components/context';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { socket } from '../../../components/socket'
import { set } from 'react-native-reanimated';
const RootStack = createStackNavigator();
let headerName;
const AddPaintScreen = ({route,navigation}) =>{
    const { header } = route.params;
    headerName=header;
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="AddPaintScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"ADD PAINT SCREEN",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const [isLoading,setIsLoading]=React.useState(false);
    const {fontFamilyObj,showToast,searchResults,setSearchResults,confirmDialog,imageUrl,setImageUrl,getNetworkStatus} = useContext(UserContext);
    const [stockDetails,setStockDetails]=React.useState({
        description:'',amount:'',quantity:'',supplier:'',size:'',branch:'SELECT BRANCH',url:''
    });
    const handleNewStockDetails=(field,val)=>{
        if(field=='description'){
            setStockDetails({...stockDetails,description:val});
        }else if(field=='amount'){
            setStockDetails({...stockDetails,amount:val});
        }else if(field=='quantity'){
            setStockDetails({...stockDetails,quantity:val});
        }else if(field=='size'){
            setStockDetails({...stockDetails,size:val});
        }else if(field=='branch'){
            setStockDetails({...stockDetails,branch:val});
        }else if(field=='supplier'){
            setStockDetails({...stockDetails,supplier:val});
        }
    }
    const validateStockDetails=()=>{
        if(stockDetails.branch!="SELECT BRANCH" && stockDetails.quantity!="" && stockDetails.amount!="" && stockDetails.supplier.length>2){
            if(stockDetails.url){
                uploadFile(stockDetails.url,(response,filePath)=>{
                    response==200?saveStockData(filePath):showToast("Could not upload photo")
                })
            }else{
                saveStockData("")
            }
            function saveStockData(filePath){
                getNetworkStatus((socket,url)=>{
                    socket.emit("saveStock",stockDetails.description,stockDetails.amount,stockDetails.quantity,stockDetails.supplier,stockDetails.size,stockDetails.branch,filePath,(cb)=>{
                        if(cb){
                            showToast("You have successfully added new paint");
                        }else{
                            showToast("There was an error while trying to add new paint!");
                        }
                    });
                })
            }
        }else{
            showToast("Error, You must carefully fill in all fields!");
        }
    }
    const uploadFile =(uri,cb)=>{
        getNetworkStatus(async(socket,url)=>{
            const apiUrl = url+"/upload";
            const name = uri.substr(uri.lastIndexOf('/') + 1);
            const filePath = "../Ordering_system/stock_icon/paint"+Math.floor(Math.random()*899999+100000) +".jpg";
            const formData = new FormData();
            formData.append('fileUrl', {
            uri,
            name,
            type: `image/jpg`,
            });
            formData.append('filePath', filePath);
            const options = {
            method: 'POST',
            body: formData,
            headers: {
                Accept: 'application/json',
                'Content-Type': 'multipart/form-data',
            },
            };
            const response = await fetch(apiUrl, options);
            cb(response.status,filePath);
        })
    }
    React.useEffect(()=>{
        if(searchResults){
            setClientDetails({...clientDetails,regNo:searchResults.regNo,make:searchResults.description});
            setSearchResults(null)
        }
        if(imageUrl){
            setStockDetails({...stockDetails,url:imageUrl});
            setImageUrl(null)   
        }
    },[searchResults,imageUrl])
    return(
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{marginTop:50,padding:10}}>
                    <TouchableOpacity style={{flexDirection:'row'}}>
                        <Text style={{fontFamily:fontFamilyObj.customBold,marginTop:8}}>CAREFULLY FILL IN </Text>
                        <FontAwesome name="check-circle" size={36} color="#5586cc"></FontAwesome>
                    </TouchableOpacity>
                </View>
                <View style={{margin:5,backgroundColor:'#e8e9f5',padding:5,borderRadius:10}}>
                    <View style={{padding:5,backgroundColor:'#fff',borderRadius:10}}>
                        <Grid style={styles.searchInputHolder}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="list" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="PAINT DESCRIPTION" onChangeText={(val)=>handleNewStockDetails('description',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="plus-circle" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="PAINT AMOUNT" onChangeText={(val)=>handleNewStockDetails('amount',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="trello" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="PAINT QUANTITY" onChangeText={(val)=>handleNewStockDetails('quantity',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="user" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="SUPPLIER NAME" onChangeText={(val)=>handleNewStockDetails('supplier',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="user" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="PAINT SIZE" onChangeText={(val)=>handleNewStockDetails('size',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Ionicons name="chevron-down-circle-outline" color="#5586cc" size={20} style={{alignSelf:"center"}}></Ionicons>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Picker selectedValue={stockDetails.branch} style={{color:'#757575',fontSize:13,fontFamily:fontFamilyObj.customLight }} onValueChange={(itemValue, itemIndex) => handleNewStockDetails("branch",itemValue)}>
                                    <Picker.Item label="SELECT BRANCH" value="SELECT BRANCH"/>
                                    <Picker.Item label="MAG SELBY" value="MAG SELBY"/>
                                    <Picker.Item label="MAG LONGMEADOW" value="MAG LONGMEADOW"/>
                                    <Picker.Item label="MAG THE GLEN CUSTOMS" value="MAG THE GLEN CUSTOMS"/>
                                    <Picker.Item label="MAG THE GLEN EASTCLIFF" value="MAG THE GLEN EASTCLIFF"/>
                                </Picker>
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="upload-cloud" color="#5586cc" size={20} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TouchableOpacity onPress={()=>navigation.navigate("CameraScreen",{options:{category:"STOCK IMAGE",subCategory:"STOCK IMAGE"}})}>
                                    <Text style={{fontFamily:fontFamilyObj.customLight}}>SELECT IMAGE</Text>
                                </TouchableOpacity>
                            </Col>
                        </Grid>
                    </View>
                </View>
                <View style={{marginTop:30,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                    {!isLoading?(
                        <TouchableOpacity onPress={validateStockDetails} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                            <FontAwesome size={75} color="green" name="check-circle"></FontAwesome>
                        </TouchableOpacity>
                    ):(
                        <ActivityIndicator size="large" color="#757575"></ActivityIndicator>
                    )}
                </View>
            </ScrollView>
        </View>
    )
};
export default AddPaintScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#fff'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5'
    }
});

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
//import MapView from 'react-native-maps';
import {MapView, Permissions} from 'expo';
import Icon from 'react-native-vector-icons/Ionicons'
import HomeScreen from './src/screens/Login';
import Registration from './src/screens/Registration';
import Home from './src/screens/Home';
import { GlobalStyles } from './src/styles/Global';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';

const HomeStack = createStackNavigator();
const RegisterStack = createStackNavigator();
const Drawer = createDrawerNavigator();

const HomeStackScreen = ({navigation})=>(
  <HomeStack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
    <HomeStack.Screen name="WELCOME" component={HomeScreen} options={{title:'CURRENT LOCATION',
            headerRight: () =>(<Icon.Button name="ios-menu" size={25} backgroundColor="#009387" onPress={()=>navigation.toggleDrawer()}></Icon.Button>)
            }}/>
  </HomeStack.Navigator>
)
const RegisterStackScreen = ({navigation})=>(
  <RegisterStack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
    <RegisterStack.Screen name="Register" component={Registration} />
  </RegisterStack.Navigator>
)
export default function App() {
  /*return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
        <Stack.Screen name="WELCOME" component={HomeScreen} />
        <Stack.Screen name="REGISTER" component={Registration} />
        <Stack.Screen name="HOME" component={Home} />
      </Stack.Navigator>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Notifications" component={NotificationsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );*/
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeStackScreen} />
        <Drawer.Screen name="Register" component={RegisterStackScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
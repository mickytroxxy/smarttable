import React, { useState } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
const SpinnerScreen = props =>{
    const [visible,setVisible] = useState(true)
    return(
        <View style={styles.container}>
            <Spinner visible={visible} textContent={props.message} textStyle={styles.spinnerTextStyle}/>
        </View>
    )
};
export default SpinnerScreen;
const styles = StyleSheet.create({
  spinnerTextStyle: {
    color: '#FFF'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5
  }
});
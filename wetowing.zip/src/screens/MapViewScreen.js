import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { ToastAndroid,StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions,FlatList, ActivityIndicator,Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker } from "react-native-maps";
import {Location,Permissions} from 'expo';
import { LinearGradient } from 'expo-linear-gradient';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import { AuthContext } from "../components/context";
import { StatusBar } from "expo-status-bar";
import { socket } from "../screens/Socket";
import { ListItem, Avatar, Input } from "react-native-elements";
import { ScrollView } from "react-native-gesture-handler";
import Feather from "react-native-vector-icons/Feather";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { db } from '../screens/service'
const Stack = createStackNavigator();
const MapViewScreen = ({navigation}) =>{
  return(
    <Stack.Navigator screenOptions={{headerStyle: {elevation: 0,shadowOpacity: 0,backgroundColor: "#009387",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
      <Stack.Screen name="MapViewScreen" component={PageContent} options={{ title: "YOUR LOCATION" }} options={{title: "YOUR LOCATION", headerLeft: () => (<Icon.Button name="ios-camera" size={25} backgroundColor="#009387"></Icon.Button>),headerRight: () => (<Icon.Button name="ios-menu"size={25}backgroundColor="#009387"onPress={() => {navigation.toggleDrawer();}}></Icon.Button>)}}/>
    </Stack.Navigator>
  )
};
function PageContent({ navigation }) {
  const { signOut, getUserToken } = React.useContext(AuthContext);
  const [location, setLocation] = React.useState({
    currentLongitude: 0,
    currentLatitude: 0,
    latitudeDelta: 10,
    longitudeDelta: 10
  });
  const [isLoading, setIsLoading] = React.useState({
    isLoadingStatus: false,
    message: '',
  });
  const [userToken, setUserToken] = React.useState(null);
  React.useEffect(() => {
    navigator.geolocation.getCurrentPosition(position => {
      setLocation({...location,currentLongitude: position.coords.longitude,currentLatitude: position.coords.latitude});
    },error => alert(error.message),{ 
      enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    );
    getUserToken(function (userToken) {
      setUserToken(userToken);
    });
  }, [navigation]);
  const sendMyLocation = () =>{
    confirmDialog("SEND MY LOCATION","Please confirm this action by pressing confirm button and our towing drivers will be with you soon!","Confirm","Cancel",(cb)=>{
      if(cb){
        setIsLoading({ ...isLoading,isLoadingStatus:true,message:'Sending your location, Please wait...'});
        db.collection("locationlogs").doc(userToken).set({user: userToken, latitude: location.currentLatitude, longitude: location.currentLongitude })
        .then(function() {
          setIsLoading({ ...isLoading,isLoadingStatus:false,message:''});
          showToast("Location sent!")
        })
        .catch(function(error) {
            console.error("Error writing document: ", error);
        });
      }
    })
  };
  const showToast = (message)=>{
    ToastAndroid.show(message, ToastAndroid.SHORT); 
  }
  if(!isLoading.isLoadingStatus){
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <TouchableOpacity style={GlobalStyles.sendToFront} onPress={()=>{sendMyLocation()}}>
          <LinearGradient colors={['#08d4c4', '#01ab9d']} style={GlobalStyles.requestBtn}>
              <Text style={GlobalStyles.requestTxt}>REQUEST</Text>
          </LinearGradient>
        </TouchableOpacity> 
        <MapView
        style={styles.mapStyle}
        region={{
          latitude: location.currentLatitude,
          longitude: location.currentLongitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01
        }} showsCompass={true} rotateEnabled={false} showsUserLocation={true}
        >
        <Marker
          backgroundColor="tomato"
          coordinate={{
          latitude: location.currentLatitude,
          longitude: location.currentLongitude
          }}
        />
        </MapView>
        <StatusBar style="light" />
      </View>
    );
  }else{
    return (
      <View
        style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
      >
    <ActivityIndicator size="large" color="green"></ActivityIndicator>
        <Text>{isLoading.message}</Text>
      </View>
    );
  }
}
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
  Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
}
export default MapViewScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
  }
});
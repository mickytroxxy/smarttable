import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React,{useContext,useState} from 'react';
import { createStackNavigator } from '@react-navigation/stack';
//import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Platform, Text, View, SafeAreaView, TextInput, TouchableOpacity, Linking, Dimensions, ToastAndroid } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {MaterialIcons,FontAwesome,Feather,AntDesign,Ionicons,FontAwesome5} from 'react-native-vector-icons';
import * as Animatable from 'react-native-animatable';
import { UserContext } from '../../../components/context'
import * as Font from "expo-font";
import { socket } from '../../../components/socket'
import { Col, Row, Grid } from 'react-native-easy-grid';
import ModalScreen from './Modal';

const CarActionsScreen = ({navigation}) =>{
    const {fontFamilyObj,bookingsArray,lastIndex,carObj,showToast,userState,confirmDialog,signOutFn} = useContext(UserContext);
    const [modalStatus, setModalStatus] = useState({isVisible:false,result:null,target:"stage-picker"});
    const fontFamily = fontFamilyObj;
    const userId = userState.userDetails.userId;
    const activeKeyRef = carObj.Key_Ref;
    const [phoneNumber,setPhoneNumber]=useState(null);
    const openGallery =(category)=>{
        let options = {};
        if(category=="BOOKING PHOTOS"){
            options={category:category,subCategory:bookingsArray[lastIndex]};
        }else if(category=="WORK IN PROGRESS"){
            setModalStatus({...modalStatus,isVisible:true,target:"stage-picker"});
            return;
        }else if(category=="ADD NOTES"){
            setModalStatus({...modalStatus,isVisible:true,target:'add-comment'});
            return;
        }else if(category=="SECURITY"){
            navigation.navigate("SecurityScreen")
            return;
        }else if(category=="SCAN"){
            navigation.navigate("PDFScannerScreen",{options:{activeKeyRef:carObj.Key_Ref}})
            return;
        }else{
            options={category:category,subCategory:category};
        }
        showCurrentGallery(options);
    }
    const showCurrentGallery =(options)=>{
        navigation.navigate("BookingPhotos",{options:options})
    }
    function closeModal(response) {
        setModalStatus({...modalStatus,isVisible:false});
        if(response){
            if(response.action=="wip"){
                showCurrentGallery({category:"WORK IN PROGRESS",subCategory:response.value});
            }else if(response.action=="comment"){
                const notes=response.value;
                if(notes.length>0){
                    socket.emit('saveNotes',notes,activeKeyRef,userId,(cb)=>{
                        if(cb){
                            showToast("Notes saved!")
                        }else{
                            showToast('There was an error while trying to save notes!')
                        }
                    })
                }else{
                    showToast("Please add something to proceed!");
                }
            }
        }
    }
    const contactCustomer=(action)=>{
        if(phoneNumber){
            if(action=="whatsapp"){
                Linking.openURL('whatsapp://send?text=Hello '+carObj.Fisrt_Name+',&phone='+phoneNumber)
            }else if(action=="phone"){
                let phone = phoneNumber;
                if (Platform.OS !== 'android') {
                    phone = `telprompt:${phone}`;
                }else{
                    phone = `tel:${phone}`;
                }
                Linking.canOpenURL(phone).then(supported => {
                    if (!supported) {
                        showToast('Phone number is not available');
                    }else{
                        return Linking.openURL(phone);
                    }
                }).catch(err => console.log(err));
            }else{
                Linking.openURL('sms:'+phoneNumber+'?body=Hello '+carObj.Fisrt_Name);
            }
        }
    }
    const signOut=()=>{
        confirmDialog("CONFIRM LOGOUT","You are about to log out, Press the logout option to proceed","LOGOUT","CANCEL",(cb)=>{
            if(cb){
                signOutFn();
            }
        })
    }
    React.useEffect(()=>{
        setPhoneNumber(phoneNoValidation(carObj.Cell_number,"27"))
    },[])
    return(
        <View style={styles.container}>
            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.carDetails}>
                <View style={{padding:30,flexDirection:'row'}}>
                    <TouchableOpacity style={{flex:1}} onPress={()=>navigation.goBack()}>
                        <FontAwesome name="arrow-circle-o-left" color="#fff" size={36}></FontAwesome>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={signOut} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                        <Feather name="log-out" color="tomato" size={30}></Feather>
                    </TouchableOpacity>
                </View>
                <View style={{marginLeft:30,marginRight:30,backgroundColor:'#f1f7fa',height:50,borderRadius:20,padding:10,justifyContent:'center'}}>
                    <Grid style={{height:50,justifyContent:'center'}}>
                        <Col size={0.15}><MaterialIcons name="car-repair" color="#5586cc" size={36}></MaterialIcons></Col>
                        <Col style={{justifyContent:'center'}}><Text style={{alignContent:'center',fontSize:16,color:'#5586cc',justifyContent:'center',alignItems:'center',fontFamily:fontFamily.customBold}}>{carObj.Key_Ref} ({carObj.Reg_No})</Text></Col>
                    </Grid>
                </View>
                <View style={{marginLeft:50,marginRight:50,height:50,marginTop:30,justifyContent:'center'}}>
                    <Grid style={{height:50,justifyContent:'center'}}>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <TouchableOpacity onPress={()=>contactCustomer("phone")}>
                                <FontAwesome name="phone" size={36} color="#5586cc"></FontAwesome>
                            </TouchableOpacity>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <TouchableOpacity onPress={()=>contactCustomer("whatsapp")}>
                                <FontAwesome name="whatsapp" size={36} color="#1a535f"></FontAwesome>
                            </TouchableOpacity>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <TouchableOpacity onPress={()=>contactCustomer("sms")}>
                                <Ionicons name="ios-chatbubble-ellipses-outline" size={36} color="#5586cc"></Ionicons>
                            </TouchableOpacity>
                        </Col>     
                    </Grid>
                </View>
            </LinearGradient>
            
            <View style={styles.performAction}>
                <View style={{marginTop:20}}>
                    <Text style={{justifyContent:'center',fontSize:18,padding:5,marginTop:10,color:'#757575',alignItems:'center',alignContent:'center',fontFamily:fontFamily.customBold}}>
                        What would you like to do?
                    </Text>
                </View>
                <View style={{height:220}}>
                    <Grid style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("BOOKING PHOTOS")}>
                                    <FontAwesome name="ticket" size={48} color="#5586cc"></FontAwesome>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>BOOKING PHOTOS</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("WORK IN PROGRESS")}>
                                    <MaterialIcons size={48} name="trending-up" color="#5586cc"></MaterialIcons>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>W.I.P PHOTOS</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("ACCIDENT")}>
                                    <FontAwesome5 name="car-crash" size={48} color="#5586cc"></FontAwesome5>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>ACCIDENT PHOTOS</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("ADDITIONAL")}>
                                    <MaterialIcons name="add-a-photo" size={48} color="#5586cc"></MaterialIcons>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>ADDITIONAL PHOTOS</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                    </Grid>
                    <Grid style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("SECURITY")}>
                                    <Feather name="shield" size={48} color="#5586cc"></Feather>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>SECURITY CHECKLIST</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("FINAL STAGE")}>
                                    <MaterialIcons size={48} name="check-circle" color="#5586cc"></MaterialIcons>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>FINAL STAGE</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("SCAN")}>
                                    <Ionicons name="scan" size={48} color="#5586cc"></Ionicons>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>DOCUMENT SCAN</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                        <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                            <LinearGradient  colors={["#9a9bb6","#e9e6f1","#9a9bb6"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.cardBtn}>
                                <TouchableOpacity style={{alignContent:'center',alignItems:'center'}} onPress={()=>openGallery("ADD NOTES")}>
                                    <Ionicons name="chatbubbles-outline" size={48} color="#5586cc"></Ionicons>
                                    <Text style={{fontFamily:fontFamily.customLight,color:'#5586cc',fontSize:10,paddingLeft:5}}>ADD NOTES</Text>
                                </TouchableOpacity>
                            </LinearGradient>
                        </Col>
                    </Grid>
                </View>
            </View>
            <ModalScreen modalStatus={modalStatus} closeModal={closeModal}/>
        </View>
    )
};
function phoneNoValidation(phone,countryCode){
    var phoneNumber = phone.replace(/ /g, '');
    if ((phoneNumber.length < 16) && (phoneNumber.length > 7)) {
      if(phoneNumber[0]=="0" && phoneNumber[1]!="0"){
        phoneNumber = phoneNumber.slice(1,phoneNumber.length)
      }else if(phoneNumber[0]!="0"){
        phoneNumber = phoneNumber;
      }
      if(countryCode!=""){
        if(countryCode[0]=="+"){
          countryCode=countryCode.slice(1,countryCode.length)
        }else{
          if(countryCode[0]=="0" && countryCode[1]=="0"){
            countryCode=countryCode.slice(2,countryCode.length)
          }
        }
        return countryCode+phoneNumber;
      }else{
        return null;
      }
    }else{
      return null;
    }
}
export default CarActionsScreen;
const styles = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignContent:'center',
        flex:1,
        alignItems:'center',
        backgroundColor:'#e8e9f5'
    },
    carDetails:{
        width:'98%',
        alignSelf:'center',
        backgroundColor:'#fff',
        borderRadius:20,
        marginTop:35,
        height:250
    },
    performAction:{
        width:'98%',
        alignSelf:'center',
        flex:1,
    },
    cardBtn:{
        justifyContent:'center',
        alignItems:'center',
        alignContent:'center',
        height:100,
        width:'94%',
        borderRadius:20
    }
});
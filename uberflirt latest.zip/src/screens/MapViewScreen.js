import useUsers from './usersHook';
import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { GlobalStyles } from '../styles/Global';
import { ToastAndroid,StatusBar,StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions,FlatList, ActivityIndicator,Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import MapView, { Marker } from "react-native-maps";
import {Location,Permissions} from 'expo';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import { AuthContext } from "../components/context";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import geohash from "ngeohash";
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import { Container, Item, Input, Header, Content, ListItem, Left, Body, Right, Switch } from 'native-base';
const RootStack = createDrawerNavigator();
let myObject;
let outNav;
let users,usersArray=null,searchedUsers=null,startCoords,confirmDialog,globalUserToken,searchedLocation=false,getUsersByLocation;
import axios from 'axios';
const MapViewScreen = ({navigation}) =>{
  outNav = navigation;
  return(
    <RootStack.Navigator screenOptions={{headerStyle: {elevation: 0,shadowOpacity: 0,backgroundColor: "#009387",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
      <RootStack.Screen name="MapViewScreen" component={PageContent} options={{title: "YOUR LOCATION", headerLeft: () => (<Icon.Button name="ios-camera" size={25} backgroundColor="#009387"></Icon.Button>),headerRight: () => (
      <Icon.Button name="ios-menu"size={25}backgroundColor="#009387"onPress={() => {navigation.openDrawer();}}></Icon.Button>
      )}}/>
    </RootStack.Navigator>
  )
};
function PageContent({ navigation }) {
  const [usersNew,startCoordsNew,confirmDialogNew,testTokenNew,showToast,getUsersByLocationNew] = useUsers();
  users=usersNew;startCoords=startCoordsNew;confirmDialog=confirmDialogNew;globalUserToken=testTokenNew;getUsersByLocation=getUsersByLocationNew;
  const [parallaxH,setParallaxH]= useState(300);
  const [usersLocation, setUsersLocation] = React.useState([{latitude: 0,longitude: 0,latitudeDelta: 10,longitudeDelta: 10, phoneNumber:''}]);
  const [location, setLocation] = React.useState({currentLongitude: 0,currentLatitude: 0,latitudeDelta: 10,longitudeDelta: 10});
  React.useEffect(() => {
    if(startCoords){
      setLocation({...location,currentLongitude: startCoords.longitude,currentLatitude: startCoords.latitude});
      setUsersLocation(users);
      const myIndex = users.map(function(e) { return e.phoneNumber; }).indexOf(globalUserToken)
      myObject = users[myIndex]
    }
  }, [startCoords,users]);
  return(
    <ParallaxScroll
      headerHeight={50}
      isHeaderFixed={false}
      parallaxHeight={parallaxH}
      fadeOutParallaxBackground={true}
      renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue}/>}
      renderParallaxForeground={({ animatedValue }) => <Foreground navigation={navigation} usersLocation={usersLocation} location={location}/>}
      parallaxBackgroundScrollSpeed={5}
      useNativeDriver={true}
      parallaxForegroundScrollSpeed={2.5}
      >
      <ParallaxBody navigation={navigation} setParallaxH={setParallaxH}/>
    </ParallaxScroll>
  )
}
const Background = props =>{
    return(
        <View style={GlobalStyles.ProfileHeader}>
            
        </View>
    )
}
const Foreground = props =>{
  let location = props.location;
  let usersLocation = props.usersLocation;
  if(searchedLocation){
    location = searchedLocation;
  }else{
    location = location;
  }
  return(
    <View style={GlobalStyles.ProfileHeader}>
        <View style={GlobalStyles.floatBtnsView}>
          <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={()=>{outNav.openDrawer()}}>
            <MaterialIcons name="menu" size={25} color="teal" alignSelf="center"></MaterialIcons>
          </TouchableOpacity>
          <TouchableOpacity style={GlobalStyles.floatBtnsViewInner} onPress={() => {if(users.length>0){props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:myObject})}}}>
            <MaterialIcons name="account-circle" size={30} color="green" alignSelf="center"></MaterialIcons>
          </TouchableOpacity>
          <TouchableOpacity style={GlobalStyles.floatBtnsViewInner}>
            <MaterialIcons name="group-work" size={30} color="orange" alignSelf="center"></MaterialIcons>
          </TouchableOpacity>
        </View>
        <MapView 
          style={styles.mapStyle}
          type region={{
            latitude: location.currentLatitude,
            longitude: location.currentLongitude,
            latitudeDelta: 0.3,
            longitudeDelta: 0.3
          }} showsCompass={true} rotateEnabled={false} showsUserLocation={false}
          >
          <Marker backgroundColor="pink" coordinate={{ latitude: location.currentLatitude, longitude: location.currentLongitude }}/>
          {usersLocation.map((item, i) =>  {
            if(item.phoneNumber!=globalUserToken){
              return (
                <Marker key={i}
                  backgroundColor="pink"
                  coordinate={{
                  latitude: item.latitude,
                  longitude: item.longitude
                  }}
                  onPress={() => props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:item})}
                >
                  <FontAwesome name="heart" color="tomato" size={12}></FontAwesome>
                </Marker>
              );
            }
          })}
        </MapView>
    </View>
  )
}
const ParallaxBody = props =>{
  const [predictions,setPredictions]=useState({
    predictionsArray:null,
    showPredictions:false,
  });
  const startPlaceSearch = (key_word) =>{
    if(key_word.length>2){
      axios
      .request({
        method: 'post',
        url: `https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyDjFgObNakHOgKAQyyBCQZSrmIH-26Ny4U&input=${key_word}`,
      })
      .then((response) => {
        setPredictions({...predictions, predictionsArray:response.data.predictions,showPredictions:true});
      })
      .catch((e) => {
        alert(e.response);
      });
    }else{
      setPredictions({...predictions, predictionsArray:null,showPredictions:false})
    }
  }
  const displaySearchedLocation = (place_id)=>{
    axios.request({
      method: 'post',
      url: `https://maps.googleapis.com/maps/api/place/details/json?placeid=${place_id}&key=AIzaSyDjFgObNakHOgKAQyyBCQZSrmIH-26Ny4U`,
    }).then((response) => {
      searchedLocation = {currentLatitude:response.data.result.geometry.location.lat,currentLongitude:response.data.result.geometry.location.lng};
      getUsersByLocation(searchedLocation.currentLatitude,searchedLocation.currentLongitude,function(usersSearched){
        searchedUsers = usersSearched;
        hideSearchView();
      })
    }).catch((e) => {
      alert(e);
    });
  }
  if(searchedLocation){
    var nearByUsers = searchedUsers;
  }else{
    var nearByUsers = users;
  }
  const hideSearchView = ()=>{
    props.setParallaxH(300);
    setPredictions({...predictions, predictionsArray:null,showPredictions:false})
  }
  if(nearByUsers!=null){
    return(
      <Animatable.View style={GlobalStyles.MapFooter} animation="fadeInUpBig" duration={1000} useNativeDriver={true}>
          <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
            <TouchableOpacity onPress={()=>hideSearchView()} style={{flex:1,flexDirection:'row'}}>
            <FontAwesome name="ellipsis-h" color="#c792f5" size={24}></FontAwesome>
            </TouchableOpacity>
          </View>
          <View style={GlobalStyles.mapFooterHeader}>
          <Text style={{fontFamily:'sans-serif-thin',fontSize:13,color:'#353434'}}>Nice to see you!</Text>
          <Text style={{fontFamily:'sans-serif-condensed',fontSize:22,color:'#05375a',fontWeight:'bold',marginTop:10,}}>Where Could Be Your Crush?</Text>
          </View>
          <Item noBorder rounded style={GlobalStyles.searchInputText}>
              <FontAwesome name="search" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
              <Input placeholder='Give us a location' style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14}} onFocus={()=>props.setParallaxH(0)} onChangeText={(val)=>startPlaceSearch(val)} />
            </Item>
            {!predictions.showPredictions ? (
              <View style={{marginTop:15,}}>
                  {
                    nearByUsers.length>0?
                    nearByUsers.map((user, i) =>  {
                      if(user.phoneNumber!=globalUserToken){
                        return (
                          <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} key={i} icon onPress={() => props.navigation.navigate("ProfileScreen",{myToken: globalUserToken,userObject:user})}>
                            <Left><Image source={{uri: user.avatar!=""?user.avatar:'https://picsum.photos/400/400'}} style={GlobalStyles.listAvatar} ></Image></Left>
                            <Body>
                              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>{user.fname}</Text>
                            </Body>
                            <Right>
                              <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{getDistance(startCoords.latitude, startCoords.longitude, user.latitude, user.longitude).toFixed(2)}km</Text>
                            </Right>
                          </ListItem>
                        );
                      }
                    }):
                    (
                      [{key:1}].map((user, i) =>  {
                        return (
                          <View style={{flex:1,alignContent:'center',alignItems:'center'}} key={i}>
                             <Text style={{fontFamily:'sans-serif-condensed',fontSize:18,color:'#05375a',fontWeight:'bold',marginTop:10,}}>We couldn't find anyone around!</Text>
                          </View>
                        );
                      })
                    )
                  }
              </View>
            ):(
              <View style={{marginTop:15,}}>
                {predictions.predictionsArray.map((item, i) =>  {
                  return (
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} key={i} icon onPress={() => displaySearchedLocation(item.place_id)}>
                      <Left><MaterialIcons name="add-location" size={30} color="#c792f5" alignSelf="center"></MaterialIcons></Left>
                      <Body>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>{item.description}</Text>
                      </Body>
                    </ListItem>
                  );
                })}
            </View>
            )}
      </Animatable.View>
    )
  }else{
    return(
      <Animatable.View style={GlobalStyles.MapFooter} animation="fadeInUpBig" duration={1000} useNativeDriver={true}>
          <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
            <TouchableOpacity onPress={()=>hideSearchView()} style={{flex:1,flexDirection:'row'}}>
            <FontAwesome name="ellipsis-h" color="#c792f5" size={24}></FontAwesome>
            </TouchableOpacity>
          </View>
          <View style={GlobalStyles.mapFooterHeader}>
          <Text style={{fontFamily:'sans-serif-thin',fontSize:13,color:'#353434'}}>Give Us A moment</Text>
          <Text style={{fontFamily:'sans-serif-condensed',fontSize:22,color:'#05375a',fontWeight:'bold',marginTop:10,}}>Searching for your crush...</Text>
          </View>
          <ActivityIndicator size="large" color="#0000ff" style={{marginTop:50}}/>
      </Animatable.View>
    )
  } 
}
function getDistance(lat1, lon1, lat2, lon2) {
  var R = 6371; 
  var dLat = toRad(lat2-lat1);
  var dLon = toRad(lon2-lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c;
  return d;
}
function toRad(Value){
  return Value * Math.PI / 180;
}
export default MapViewScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
  }
});
<h1 align="center">
  <img src="/assets/logo.png" width="150">
<br>
<br>
Facebook Clone React Native
</h1>

<p align="center">Recreating Facebook Clone React Native with styled components</p>
<p align="center">Watch on <a href="https://www.youtube.com/watch?v=yLnRIeaLeBY">Youtube</a></p>

<div align="center">
   <a href="https://www.youtube.com/watch?v=yLnRIeaLeBY">
   <img align="center" src="/assets/app.gif" width="230px">
   </a>

</div>

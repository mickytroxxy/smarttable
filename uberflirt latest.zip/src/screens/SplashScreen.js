import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
const Stack = createStackNavigator();

const SplashScreen = ({navigation}) =>{
    return(
        <View style={GlobalStyles.container}>
            <View style={GlobalStyles.header}>
                <Animatable.Image animation="bounceIn" duration={1500} useNativeDriver={true} source={require('../../assets/icon.png')} style={GlobalStyles.logo} resizeMode="stretch"/>
            </View>
            <Animatable.View animation="fadeInUpBig" useNativeDriver={true} style={GlobalStyles.footer}>
                <Text style={GlobalStyles.title}>They Are All Craving To Be With You!</Text>
                <Text style={GlobalStyles.text}> Find Out Who Now</Text>
                <View style={GlobalStyles.button}>
                    <TouchableOpacity onPress={()=>navigation.navigate('SignInScreen')}>
                        <LinearGradient colors={['#08d4c4', '#fa8460']} style={GlobalStyles.signIn}>
                            <Text style={GlobalStyles.textSign}>Get Started</Text>
                            <MaterialIcons name='navigate-next' color='#fff' size={20}></MaterialIcons>
                        </LinearGradient>
                    </TouchableOpacity> 
                </View>
            </Animatable.View>
        </View>
    )
};
export default SplashScreen;

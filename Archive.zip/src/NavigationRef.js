import { NavigationActions } from 'react-navigation';
//import { StyleSheet, Text, View, SafeAreaView, Button } from 'react-native';
let navigator;
export const setNavigator = nav =>{
    navigator = nav;
}
export const navigate = (routeName,params) =>{
    navigator.dispatch(
        NavigationActions.navigate({
            routeName,
            params
        })
    );
}
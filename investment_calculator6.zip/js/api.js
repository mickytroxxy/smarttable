const api = [
  {
    type: 'Fixed Deposit',
    periodNRate: [{period:3,rate:8},{period:6,rate:10.5},{period:12,rate:12},{period:24,rate:14.3},{period:36,rate:25},{period:48,rate:45}],
  },
  {
    type: 'Notice Deposit',
    periodNRate: [{period:3,rate:11},{period:6,rate:8.5},{period:12,rate:17},{period:24,rate:1.3},{period:36,rate:29},{period:48,rate:56}],
  },
  {
    type: 'Access Deposit',
    periodNRate: [{period:3,rate:5},{period:6,rate:8.5},{period:12,rate:16},{period:24,rate:90.3},{period:36,rate:28},{period:48,rate:400}],
  },
  {
    type: 'Tax Free',
    periodNRate: [{period:3,rate:4},{period:6,rate:7},{period:12,rate:10},{period:24,rate:12.3},{period:36,rate:15},{period:48,rate:25}],
  },
]
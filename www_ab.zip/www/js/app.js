var $ = Dom7;
var app = new Framework7({
  name: 'africanBank', // App name
  theme: 'auto', // Automatic theme detection
  el: '#app', // App root element
  // App store just like redux
  store: store,
  // App routes
  routes: routes,
  on: {
    init: ()=> {
      deviceIsReady();
    },
  }
});
let investmentAmount = 500;
const months = [3,6,12,24,36,48];
const api = [
  {
    type: 'Fixed Deposit',
    periodNRate: [{period:3,rate:8},{period:6,rate:10.5},{period:12,rate:12},{period:24,rate:14.3},{period:36,rate:25},{period:48,rate:45}],
  },
  {
    type: 'Notice Deposit',
    periodNRate: [{period:3,rate:11},{period:6,rate:8.5},{period:12,rate:17},{period:24,rate:1.3},{period:36,rate:29},{period:48,rate:56}],
  },
  {
    type: 'Access Deposit',
    periodNRate: [{period:3,rate:5},{period:6,rate:8.5},{period:12,rate:16},{period:24,rate:90.3},{period:36,rate:28},{period:48,rate:400}],
  },
  {
    type: 'Tax Free',
    periodNRate: [{period:3,rate:4},{period:6,rate:7},{period:12,rate:10},{period:24,rate:12.3},{period:36,rate:15},{period:48,rate:25}],
  },
]
function deviceIsReady() {
  listMonths();
  setTimeout(() => {
    createChart(calculateDataSetFromApi(api));
  }, 1000);
}
function listMonths() {
  for (let i = 3; i < 13; i++) {
    $(".months-select").append("<option value="+i+">"+i+"</option>");
  }
}
const createChart=(datasets)=>{
  app.areaChart.create({
    el: '.area-chart-simple',
    tooltip: true,
    axis: true,
    axisLabels: months,
    toggleDatasets: true,
    //lineChart: true,
    datasets: datasets,
    formatTooltipTotal:()=>{
      return '';
    }
  });
}
const calculateDataSetFromApi=(api)=>{
  const dataSetObject = [];
  api.map((obj)=>{
    let values = []
    months.map((period)=>{
      obj.periodNRate.map((periodNRateObj)=>{
        period==periodNRateObj.period&&values.push(((periodNRateObj.rate/100) * investmentAmount) + investmentAmount)
      })
    });
    if(obj.type.includes('Fixed')){
      dataSetObject.push({label: 'Fixed Deposit',color: '#000',values: values});
    }else if(obj.type.includes('Notice')){
      dataSetObject.push({label: 'Notice Deposit',color: '#f07ef7',values: values});
    }else if(obj.type.includes('Access')){
      dataSetObject.push({label: 'Access Deposit',color: '#7ef7df',values: values});
    }else if(obj.type.includes('Tax')){
      dataSetObject.push({label: 'Tax Free',color: 'orange',values: values});
    }
  })
  return dataSetObject;
}
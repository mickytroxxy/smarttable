const $$ = Dom7;
const app = new Framework7({modalTitle: '',material: true,pushState: true});
const mainView = app.addView('.view-main', {dynamicNavbar: true,domCache: true});
const periods = ["3 MONTHS","6 MONTHS","12 MONTHS","24 MONTHS","36 MONTHS","48 MONTHS"];
let chart;
$(document).ready(()=>appIsReady());

const appIsReady=()=>{
    /*var chart = Highcharts.chart('container', {
        chart: {
            type: 'areaspline'
        },
        title: {
            //text: 'Stacked column chart'
        },
        xAxis: {
            categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Total fruit consumption'
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'blue'
                },
            }
        },
        legend: {
            align: 'right',
            x: 0,
            verticalAlign: 'top',
            y: 0,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            borderWidth: 1,
            shadow: false
        },
        tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: true,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            }
        },
        series: [{
            name: 'John',
            data: [5, 3, 4, 7, 2]
        }, {
            name: 'Jane',
            data: [2, 2, 3, 2, 1]
        }, {
            name: 'Joe',
            data: [3, 4, 4, 2, 5]
        }]
    });
    chart.xAxis[0].labelGroup.element.childNodes.forEach(function(label){
        label.style.cursor = "pointer";
      label.onclick = function(){
          alert('You clicked on '+this.textContent);
      }
    });


    var chart = Highcharts.chart('container', {
        title: {
            text: ''
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        yAxis:{
            visible:false,
        },
        chart: {
            type: 'areaspline',
            events: {
                load: function() {
                  var axis = this.xAxis[0] 
                  var ticks = axis.ticks
                  var points = this.series[0].points
                  var tooltip = this.tooltip
                  points.forEach(function(point, i) {
                    if (ticks[i]) {
                      var label = ticks[i].label.element
                      label.onclick = function() {
                        tooltip.getPosition(null, null, point) 
                        tooltip.refresh(point)
                      }
                    }
                    
                  })
                }
              }
        },
        xAxis: {
            categories: periods,
            labels: {
                style: {
                    color: 'red',
                    backgroundColor: 'black',
                }
            },
        },
        series: [{
            name: 'John',
            data: [5, 3, 4, 7, 2],
            marker: {
                enabled: false
            },
        }, {
            name: 'Jane',
            data: [2, 2, 3, 2, 1],
            marker: {
                enabled: false
            },
        }, {
            name: 'Joe',
            data: [3, 4, 4, 2, 5],
            marker: {
                enabled: false
            },
        }]
    });*/
    
    

    chart = Highcharts.chart('container', {
        chart: {
            type: 'areaspline',
            events: {
                load: function() {
                  var axis = this.xAxis[0] 
                  var ticks = axis.ticks
                  var points = this.series[0].points
                  var tooltip = this.tooltip
                  points.forEach(function(point, i) {
                    if (ticks[i]) {
                      var label = ticks[i].label.element
                      label.onclick = function() {
                        tooltip.getPosition(null, null, point) 
                        tooltip.refresh(point)
                      }
                    }
                    
                  });
                },
            }
        },
        title: {
            text: ''
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        yAxis:{
            visible:false,
        },
        legend: {
            align: 'center',
            x: 0,
            verticalAlign: 'top',
            y: 0,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            shadow: false,
            useHTML: true,
            itemDistance: 50,
            symbolPadding: 0,
            symbolWidth: 0,
            symbolHeight: 0,
            squareSymbol: false,
            labelFormatter: function () {
                return getSymbol(this.name)+'<div style="text-align: center;">' + this.name+'</div><div style="text-align: center;">' + checkName(this.name) +'</div>';
            },
            x: 0,
            //labelFormat: "<div class='span-legend-item'>{name}</div><div class='span-legend-item'>Deposit</div>"
        },
        xAxis: {
            categories:periods,
            min:0.5,
            max:5.5,
            tickInterval:1,
            maxPadding:0,
            endOnTick:false,
            startOnTick:false,
            /*plotLines: [{ // mark the weekend
                color: 'red',
                width: 2,
                value: 5,
                dashStyle: 'Solid'
            }],*/
        },
        tooltip: {
            //shared: true,
            valueSuffix: ''
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            },
            series: {
                events: {
                    legendItemClick: function (e) {
                        /*var visibility = this.visible ? 'visible' : 'hidden';
                        if (!confirm('The series is currently ' +
                                     visibility + '. Do you want to change that?')) {
                            return false;
                        }*/
                        const clickedIndex = this.index;
                        chart.series.forEach((s)=> {
                            s.setState('inactive');
                            s.update({ opacity: 0.3 });
                        });
                        chart.series[clickedIndex].update({ opacity: 1 });
                        //return false;
                    }
                },
                states: {
                    inactive: {
                        opacity: 1
                    },
                    hover: {
                        brightness: 0   
                    }
                }
            }
        },
        series: [{
            name: 'Fixed',
            data: [3, 4, 3, 5, 4, 10, 12],
            marker: {
                enabled: false
            },
            color: '#000',
        }, {
            name: 'Notice',
            data: [5, 9, 10, 3, 7, 9, 30],
            marker: {
                enabled: false
            },
            opacity: 0.3,
            color:'#f07ef7',
        }, {
            name: 'Access',
            data: [1, 3, 4, 3, 3, 5, 4],
            marker: {
                enabled: false
            },
            opacity: 0.3,
            color:'#7ef7df'
        }, {
            name: 'Tax',
            data: [16, 23, 14, 31, 37, 5, 40],
            marker: {
                enabled: false
            },
            opacity: 0.3,
            color:'orange',
        }]
    });
}
const setInactive=()=>{
    chart.series[0].setState('inactive');
}
function checkName(legendName){
    return legendName=='Tax'?'Free':'Deposit';
}
const getSymbol=(legendName)=>{
    let color;
    if(legendName=='Fixed'){
        color='#000';
    }else if(legendName=='Access'){
        color='#7ef7df';
    }else if(legendName=='Notice'){
        color='#f07ef7';
    }else if(legendName=='Tax'){
        color='orange';
    }
    return "<div class='investment_indicator' style='background-color: "+color+"'></div>";
}
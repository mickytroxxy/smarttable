import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useState } from "react";
import { StyleSheet, Platform, Text, View, SafeAreaView, Image, ScrollView, Modal, Alert,Button, Dimensions , TouchableOpacity,TextInput} from "react-native";
import * as ImagePicker from 'expo-image-picker';
//import { Permissions } from 'expo';
import * as Permissions from 'expo-permissions';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Ionicons from "react-native-vector-icons/Ionicons";
import { Container,Picker, Header, Content, Item, Input,Textarea, Form, Card, CardItem,Body,ListItem,Right,DatePicker } from 'native-base';
import { GlobalStyles } from '../styles/Global';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Col, Row, Grid } from 'react-native-easy-grid';
import * as Font from 'expo-font';
import moment from 'moment';
import {
    TouchableRipple,
    Switch
} from 'react-native-paper';
const askPermissionsAsync = async () => {
    const { status: camera } = await Permissions.askAsync(Permissions.CAMERA);
    const { status: cameraRoll } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
    if (camera && cameraRoll !== "granted") {
      alert("camera roll not  granted");
    }else{
        return true;
    }
};
const ModalScreen = props =>{
    const [fee,setFee] = useState(null);
    const [feeDesc,setFeeDes] = useState(null);
    const [amount,setAmount] = useState(null);
    const [fbUser,setFbUser] = useState("https://www.facebook.com/yourfacebookusername");
    const [isDriverRequested,setIsDriverRequested]=useState(false);
    const [transferArray,setTransAmount]=useState({amount:0,user:''});
    const [withdrawalObj,setWithdrawalObj]=useState({accountNumber:'',accountHolder:'',accountType:'',bankName:'',amount:''});
    const [paymentMethod,setPaymentMethod] = useState("CREDITS");
    const browsePhoto = async (sourceType) => {
        props.closeModal();
        if(sourceType=="Gallery"){
            let result = await ImagePicker.launchImageLibraryAsync({
                allowsEditing: true,
                aspect: [4, 4],
                quality: 0.7,
            });
            if (!result.cancelled) {
                imageSuccess(result.uri);
            }
        }else{
            props.navigation.navigate("CameraScreen",);
        }
        function imageSuccess (file){
            if(props.modalAttr.toOpen=="FILE BROWSER"){
                props.callback(file,'FILE');
            }else{
                props.callback(file,'ID PHOTO');
            }
        }
    };
    const selfiePhoto = async () =>{
        props.closeModal();
        if(askPermissionsAsync){
            try{
                let result = await ImagePicker.launchCameraAsync({
                    allowsEditing: true,
                    aspect: [4, 4],
                    quality: 0.5,
                });
                if (!result.cancelled) {
                    props.callback(result.uri,'SELFIE');
                }
            }catch (error) {
                alert(error);
            }
        }
    }
    const setSelectedValue =(gender)=>{
        props.closeModal();
        props.callback(gender,'GENDER');
    }
    const [date, setDate] = useState(new Date(Date.now()));
    const [time, setTime] = useState(new Date(Date.now()));
    const [hours, setHours] = useState(1);
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);

    const onChange = (event, selectedDate) => {
        const currentDate = selectedDate || date;
        setShow(Platform.OS === 'ios');
        if(mode=='date'){
            setDate(currentDate);
        }else{
            setTime(currentDate);
        }
    };
    const dateHandler = (event, selectedDate)=>{
        const currentDate = selectedDate || date;
        setShow(Platform.OS === 'ios');
        props.closeModal();
        setDate(currentDate);
        let birthDay = moment(selectedDate).format('L');
        props.callback(birthDay,'BIRTHDAY');
    }
    const showMode = (currentMode) => {
        setShow(true);
        setMode(currentMode);
    };

    const showDatepicker = () => {
        showMode('date');
    };

    const showTimepicker = () => {
        showMode('time');
    };
    const [fontsLoaded,setFontsLoaded]=useState(false);
    let customFonts = {
        'MontserratAlternates-Light': require('..//../fonts/MontserratAlternates-Light.otf'),
    };
    const loadFontsAsync = async ()=> {
        await Font.loadAsync(customFonts);
        setFontsLoaded(true);
    }
    let fontFamily = 'sans-serif-thin';
    if(fontsLoaded){
        fontFamily = 'MontserratAlternates-Light';
    }
    React.useEffect(()=>{
        loadFontsAsync();
    },[])
    if((props.modalAttr.toOpen=="FILE BROWSER") || (props.modalAttr.toOpen=="ID VERIFICATION PHOTO")){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <View style={styles.button}>
                        <TouchableOpacity onPress={()=>{browsePhoto('Gallery')}}>
                            <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.signIn}>
                                <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>GET FROM GALLERY</Text>
                            </LinearGradient>
                        </TouchableOpacity> 
                        <TouchableOpacity onPress={()=>{browsePhoto('Camera')}}>
                            <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.signIn}>
                                <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>GET FROM CAMERA</Text>
                            </LinearGradient>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={()=>{props.closeModal()}}>
                            <FontAwesome name="times-circle" size={50} color="tomato" alignSelf="center"></FontAwesome>
                        </TouchableOpacity>  
                    </View>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="UPDATE FEE MODAL"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="usd" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        keyboardType="numeric" placeholder={props.modalAttr.headerText.split(" ")[1].toUpperCase() + " FEE IS "+props.modalAttr.values[0]} onChangeText={(val)=>setFee(val)}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <Form>
                            <Textarea rowSpan={5} bordered placeholder="State your skills for this service..." style={{borderRadius:10,height:80,}}onChangeText={(val)=>setFeeDes(val)}/>
                        </Form>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback([fee,props.modalAttr.headerText.split(" ")[1],feeDesc],'FEE');props.closeModal()}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="BUY CREDITS"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',marginBottom:10}}>How many credits?</Text>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="usd" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="Buy at least 100 credits for R100" keyboardType="numeric" onChangeText={(val)=>setAmount(val)}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(amount,'PAYMENT');props.closeModal()}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="REPAY CREDITS"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>MAKE A MINIMUM PAYMENT OF R {props.modalAttr.values}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',marginBottom:10}}>Your account is in debt, please make a minimum payment of R {props.modalAttr.values} to continue receiving requests.</Text>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="usd" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder='How many credits would you like?' keyboardType="numeric" onChangeText={(val)=>setAmount(val)}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(amount,'PAYMENT');props.closeModal()}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="TRANSFER CREDITS"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>TRANSFER YOUR CREDITS</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="usd" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="HOW MANY CREDITS ?" keyboardType="numeric" onChangeText={(val)=>setTransAmount({...transferArray,amount:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="phone" color="#c792f5" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="USER PHONE NUMBER" keyboardType="phone-pad" onChangeText={(val)=>setTransAmount({...transferArray,user:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(transferArray,'TRANSFER CREDITS');props.closeModal()}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="WITHDRAW CREDITS"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>WITHDRAW YOUR CREDITS</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <FontAwesome name="phone" color="#8e81b4" size={18} style={{alignSelf:"center"}}></FontAwesome>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="HOW MANY CREDITS ?" keyboardType="numeric" onChangeText={(val)=>setWithdrawalObj({...withdrawalObj,amount:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <MaterialIcons name="account-balance" color="#8e81b4" size={18} style={{alignSelf:"center"}}></MaterialIcons>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="Bank Name" onChangeText={(val)=>setWithdrawalObj({...withdrawalObj,bankName:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <MaterialIcons name="credit-card" color="#8e81b4" size={18} style={{alignSelf:"center"}}></MaterialIcons>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="Account Number" keyboardType="numeric" onChangeText={(val)=>setWithdrawalObj({...withdrawalObj,accountNumber:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <MaterialIcons name="account-circle" color="#8e81b4" size={18} style={{alignSelf:"center"}}></MaterialIcons>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="Account holder name" onChangeText={(val)=>setWithdrawalObj({...withdrawalObj,accountHolder:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={{marginTop:10,height:40}}>
                            <Grid style={GlobalStyles.searchInputHolder}>
                                <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <MaterialIcons name="layers" color="#8e81b4" size={18} style={{alignSelf:"center"}}></MaterialIcons>
                                </Col>
                                <Col style={{justifyContent:'center'}}>
                                    <TextInput
                                        placeholder="Account Type" onChangeText={(val)=>setWithdrawalObj({...withdrawalObj,accountType:val})}
                                        style={{borderColor:'#fff',fontFamily:'sans-serif-thin',fontWeight:'bold',fontSize:14,color:'#757575'}}
                                    />
                                </Col>
                            </Grid>
                        </View>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(withdrawalObj,'WITHDRAW CREDITS');props.closeModal()}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="SEND A REQUEST"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6',fontFamily:fontFamily}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{padding:5,marginTop:10,}}>
                        <View style={styles.serviceDes}>
                            <View style={{padding:5}}>
                                <Text style={{borderBottomWidth:0.7,borderColor:'#d0cfd3',paddingBottom:5,color:'#2a2828',fontFamily:fontFamily}}>
                                    {props.modalAttr.values[1]}
                                </Text>
                                {/**<ListItem noBorder>
                                    <Body>
                                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold',textTransform:'uppercase',fontSize:12,}}>Request An Uber Driver</Text>
                                    </Body>
                                    <Right>
                                        <TouchableRipple onPress={() => { setIsDriverRequested(!isDriverRequested) }}>
                                            <View style={styles.preference}>
                                                <View pointerEvents="none">
                                                    <Switch value={isDriverRequested} />
                                                </View>
                                            </View>
                                        </TouchableRipple>
                                    </Right>
                                </ListItem> */}
                                <View style={{minHeight:100,marginTop:15}}>
                                    <Grid>
                                        <Col size={0.5} style={{flexDirection:'row'}}>
                                            <MaterialIcons name="date-range" color="green" size={18} style={{marginTop:5}}></MaterialIcons>
                                            <Text style={{padding:5,alignContent:'center',alignItems:'center',justifyContent:'center',color:'#2a2828',fontFamily:fontFamily,fontSize:13}}>DATE</Text>
                                        </Col>
                                        <Col size={0.5}>
                                            <TouchableOpacity onPress={showDatepicker} style={{padding:5,borderColor:'#cdcac9',borderWidth:0.5,borderRadius:10,alignContent:'center',alignItems:'center',justifyContent:'center',fontFamily:fontFamily}}>
                                                <Text style={{fontFamily:fontFamily}}>{moment(date).format('L')}</Text>
                                            </TouchableOpacity>
                                        </Col>
                                    </Grid>
                                    <Grid style={{marginTop:10}}>
                                        <Col size={0.5} style={{flexDirection:'row'}}>
                                            <Ionicons name="md-timer" color="green" size={18} style={{marginTop:5}}></Ionicons>
                                            <Text style={{padding:5,alignContent:'center',alignItems:'center',justifyContent:'center',color:'#2a2828',fontFamily:fontFamily,fontSize:13}}>TIME</Text>
                                        </Col>
                                        <Col size={0.5}>
                                            <TouchableOpacity onPress={showTimepicker} style={{padding:5,borderColor:'#cdcac9',borderWidth:0.5,borderRadius:10,fontFamily:fontFamily,alignContent:'center',alignItems:'center',justifyContent:'center'}}>
                                                <Text style={{fontFamily:fontFamily}}>{moment(time).format('HH:mm')}</Text>
                                            </TouchableOpacity>
                                        </Col>
                                    </Grid>
                                    <Grid style={{marginTop:10}}>
                                        <Col size={0.7} style={{flexDirection:'row'}}>
                                            <Ionicons name="md-trending-up" color="green" size={18} style={{marginTop:5}}></Ionicons>
                                            <Text style={{padding:5,alignContent:'center',alignItems:'center',justifyContent:'center',color:'#2a2828',fontFamily:fontFamily,fontSize:13}}>HOW MANY HOURS</Text>
                                        </Col>
                                        <Col size={0.3}>
                                            <TextInput style={[styles.textInput,{fontFamily:fontFamily}]} value={hours.toString()} autoCapitalize='none' onChangeText={(val)=>setHours(val)} keyboardType="numeric"></TextInput>
                                        </Col>
                                    </Grid>
                                </View>
                                <View>
                                    {show && (
                                        <DateTimePicker
                                        testID="dateTimePicker"
                                        value={date}
                                        mode={mode}
                                        is24Hour={true}
                                        display="default"
                                        onChange={onChange}
                                        />
                                    )}
                                </View>
                            </View>
                        </View>
                        <Grid style={{marginTop:10,backgroundColor:'#fcf2ef',borderRadius:10,padding:5}}>
                            <Col size={0.5} style={{flexDirection:'row'}}>
                                <MaterialIcons name="credit-card" color="#449906" size={18} style={{marginTop:5}}></MaterialIcons>
                                <Text style={{padding:5,alignContent:'center',alignItems:'center',justifyContent:'center',color:'#2a2828',fontFamily:fontFamily,fontSize:13}}>PAYMENT METHOD</Text>
                            </Col>
                            <Col size={0.5}>
                                <Picker selectedValue={paymentMethod} style={{ height: 20,color:'#757575',fontSize:13,fontFamily:fontFamily }} onValueChange={(itemValue, itemIndex) => setPaymentMethod(itemValue)}>
                                <Picker.Item label="CREDITS" value="CREDITS"/>
                                <Picker.Item label="CASH" value="CASH"/>
                            </Picker>
                            </Col>
                        </Grid>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:10,}}>
                            <TouchableOpacity onPress={()=>{props.callback([props.modalAttr.values[0],props.modalAttr.headerText.split(" ")[1],isDriverRequested,date,time,hours,paymentMethod],'REQUESTSENDING');props.closeModal();setIsDriverRequested(false)}}>
                                <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                            </TouchableOpacity>
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="ABOUT"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Form>
                            <Textarea rowSpan={5} bordered placeholder="Please tell us about yourself..." style={{borderRadius:10,height:80,}}onChangeText={(val)=>setFeeDes(val)}/>
                        </Form>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(feeDesc,'ABOUT');props.closeModal()}}>
                                <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.signIn,{width:'auto',padding:10}]}>
                                    <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="AGE"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT DATE OF BIRTH</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.signIn,{width:'auto',padding:10}]}>
                            <TouchableOpacity onPress={showDatepicker}><Text style={{color:'#fff',fontFamily:'Roboto',fontWeight:'bold',fontSize:16}}>{moment(date).format('L')}</Text></TouchableOpacity>
                        </LinearGradient>
                    </Content>
                </View>
                <View>
                    {show && (
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={date}
                            mode={mode}
                            is24Hour={true}
                            display="default"
                            onChange={dateHandler}
                        />
                    )}
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="GENDER"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT YOUR GENDER</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:'auto',padding:10}]}>
                            <Picker selectedValue="SELECT" style={{ height: 50, width: 150,color:'#fff',fontWeight:'bold',fontFamily:'Roboto' }}
                                onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
                            >
                                <Picker.Item label="SELECT" value="SELECT"/>
                                <Picker.Item label="MALE" value="MALE"/>
                                <Picker.Item label="FEMALE" value="FEMALE" />
                            </Picker>
                        </LinearGradient>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="FACEBOOK LINK"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT YOUR GENDER</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Item rounded style={GlobalStyles.searchInputText}>
                            <FontAwesome name="facebook" color="#8e81b4" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            <Input placeholder="Type or paste facebook link" value={fbUser} onChangeText={(val)=>setFbUser(val)} />
                        </Item>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(fbUser,'FACEBOOK');props.closeModal()}}>
                                <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.signIn,{width:250}]}>
                                    <FontAwesome name="check-circle" color="green" size={50}></FontAwesome>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="SELFIE VERIFICATION PHOTO"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>USE FRONT CAMERA ONLY</Text>
                        </View>
                    </View>
                    <View style={styles.button}>
                        <TouchableOpacity onPress={()=>{selfiePhoto()}}>
                            <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={styles.signIn}>
                                <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>CAPTURE SELFIE</Text>
                            </LinearGradient>
                        </TouchableOpacity> 
                        <TouchableOpacity onPress={()=>{props.closeModal()}}>
                        <Text style={[styles.textSign],{color:"tomato",fontWeight:"bold",fontSize:20}}>Cancel</Text>
                        </TouchableOpacity>  
                    </View>
                </View>
            </Modal>
        )
    }
}
export default ModalScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    serviceDes:{
        borderRadius:10,
        backgroundColor:'#fcf2ef'
    },
    newLabel: {
        color: "#757575",
        fontWeight: "bold",
        fontSize:16,
        marginTop:6,
      },
    preference: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        paddingHorizontal: 16,
    },
    centeredView:{
        minHeight:'60%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 11,
        color: "#fff",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        backgroundColor:'#e7d8d8',borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    textInput: {
        flex: 1,
        marginTop: Platform.OS === 'ios' ? 0 : -2,
        paddingLeft: 10,
        color: '#05375a',
        borderRadius:10,
        borderWidth:0.7,
        borderColor:'#cdcac9'
    },
});
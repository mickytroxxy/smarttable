import React, { useEffect, useState } from "react";
import { db } from '../screens/service';
import geohash from "ngeohash";
import {Alert,ToastAndroid } from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";
const getGeohashRange = (latitude,longitude,distance) => {
  const lat = 0.0144927536231884; // degrees latitude per mile
  const lon = 0.0181818181818182; // degrees longitude per mile

  const lowerLat = latitude - lat * distance;
  const lowerLon = longitude - lon * distance;

  const upperLat = latitude + lat * distance;
  const upperLon = longitude + lon * distance;

  const lower = geohash.encode(lowerLat, lowerLon);
  const upper = geohash.encode(upperLat, upperLon);
  return {
    lower,
    upper
  };
};
const useUsers = () => {
  const [users, usersSet] = React.useState([]);
  const [startCoords, setsTartCoords] = React.useState(null);
  const [userToken,setUserToken]=useState();
  const getUserToken = async(cb)=>{
    try {
      setUserToken(await AsyncStorage.getItem("userToken"));
    } catch (e) {
      showToast(e);
    }
  }
  React.useEffect(() => {
    async function fetchUsers() {
      navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        setsTartCoords({latitude:latitude,longitude:longitude});
        getUserToken();
        const range = getGeohashRange(latitude, longitude, 50);
        db.collection("users").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).get().then(querySnapshot => {
          const data = querySnapshot.docs.map(doc => doc.data());
          usersSet(data);
        });
      },error => {
        //alert(error.message)
        const latitude = -26.188810;
        const longitude = 28.047689;
        setsTartCoords({latitude:latitude,longitude:longitude});
        getUserToken();
        const range = getGeohashRange(latitude, longitude, 50);
        db.collection("users").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).get().then(querySnapshot => {
          const data = querySnapshot.docs.map(doc => doc.data());
          usersSet(data);
        });
      },{ 
        enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
      );
    }
    fetchUsers();
  }, []);
  return [users,startCoords,confirmDialog,userToken,showToast,getUsersByLocation];
};
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
  Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
}
function getUsersByLocation(latitude,longitude,cb){
  const range = getGeohashRange(latitude, longitude, 50);
  db.collection("users").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).get().then(querySnapshot => {
    const data = querySnapshot.docs.map(doc => doc.data());
    cb(data);
  });
}
const showToast = (message)=>{
  ToastAndroid.show(message, ToastAndroid.SHORT); 
}
export default useUsers;

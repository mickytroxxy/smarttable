import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import SplashScreen from './SplashScreen';
import SignInScreen from  './SignInScreen';
import SignUpScreen from './SignUpScreen';

const RootStack = createStackNavigator();
const RootStackScreen = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "#009387",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        >
          <RootStack.Screen
            name="SplashScreen"
            component={SplashScreen}
            options={{ title: "AIS TOWING" }}
          />
          <RootStack.Screen
            name="SignInScreen"
            component={SignInScreen}
            options={{ title: "", headerLeft:"" }}
          />
          <RootStack.Screen
            name="SignUpScreen"
            component={SignUpScreen}
            options={{ title: "CREATE ACCOUNT" }}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default RootStackScreen;
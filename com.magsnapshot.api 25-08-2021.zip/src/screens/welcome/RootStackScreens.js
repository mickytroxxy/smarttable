import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity,Image } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import LoginScreen from  './Login';
import RegisterScreen from './Register';
import Icon from 'react-native-vector-icons/Ionicons'
//const RootStack = createStackNavigator();
const RootStack = createDrawerNavigator();
const RootStackScreens = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "none",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        >
          <RootStack.Screen
            name="LoginScreen"
            component={LoginScreen}
            options={{
              //headerLeft: () => (<View style={{paddingLeft:10}}><Image source={require("../../../assets/ubertext.png")} style={{height:50,width:120}} resizeMode="center"></Image></View>),
              title:"",
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <RootStack.Screen
            name="RegisterScreen"
            component={RegisterScreen}
            options={{
              title: 'CREATE ACCOUNT',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default RootStackScreens;
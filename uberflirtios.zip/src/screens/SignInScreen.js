import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Platform, Text, View, SafeAreaView, TextInput, TouchableOpacity, Image, Dimensions, ToastAndroid } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable'; //061 746 2677 dayalagovender@gmail.com
import { AuthContext } from '../components/context'
import { db } from '../screens/service'
import SpinnerScreen from '../screens/SpinnerScreen'
import * as Font from "expo-font";
import { Ionicons } from "@expo/vector-icons";
const Stack = createStackNavigator();

const SignInScreen = ({navigation}) =>{
    const [data,setData]=React.useState({
        email: '',password:'',check_textInputChange:false,secureTextEntry:true
    })
    const [loading,setIsLoading]=React.useState({
        isLoading:false, text:''
    })
    const { setUserTokenFn } = React.useContext(AuthContext);
    const textInputChange = (val)=>{
        if(val.length!=0){
            setData({
                ...data,
                email:val,
                check_textInputChange:true
            })
        }else{
            setData({
                ...data,
                email:val,
                check_textInputChange:false
            })
        }
    }
    const handlePasswordChange = (val)=>{
        setData({
            ...data,
            password:val
        })
    }
    const updateSecureTextEntry = ()=>{
        setData({
            ...data,
            secureTextEntry: !data.secureTextEntry,
        })
    }
    const Login = (phoneNumber,password)=>{
        setIsLoading({...loading,isLoading: true,text:'Authenticating you, Please wait...'})
        db.collection("users")
        .where("phoneNumber", "==", phoneNumber).where("password", "==", password)
        .get()
        .then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            setIsLoading({...loading,isLoading: false,text:'Authenticating you, Please wait...'})
            if(data.length>0){
                setUserTokenFn(phoneNumber);
            }else{
                showToast("Incorrect credentials combination!")
            }
        });
    }
    const showToast = (message)=>{
        ToastAndroid.show(message, ToastAndroid.SHORT); 
    }
    return(
        <View style={GlobalStyles.container}>
            <View style={styles.header}>
                <Text style={styles.text_header}>Get Started!</Text>
            </View>
            <Animatable.View animation="fadeInUpBig" useNativeDriver={true} style={styles.footer}>
                <Text style={styles.text_footer}>Phone Number</Text>
                <View style={styles.action}>
                    <Feather name="phone" color="#009387" size={20}></Feather>
                    <TextInput style={styles.textInput} placeholder="Phone number" autoCapitalize='none' onChangeText={(val)=>textInputChange(val)} keyboardType="phone-pad"></TextInput>
                    {data.check_textInputChange? <Animatable.View animation="bounceIn"><Feather name="check-circle" color="green" size={20}></Feather></Animatable.View> : null}
                </View>
                <Text style={[styles.text_footer],{marginTop:35,color: '#05375a',fontSize: 18}}>Password</Text>
                <View style={styles.action}>
                    <Feather name="lock" color="#009387" size={20}></Feather>
                    <TextInput style={styles.textInput} placeholder="Your Password" autoCapitalize='none' secureTextEntry={data.secureTextEntry?true:false} onChangeText={(val)=>handlePasswordChange(val)}></TextInput>
                    <TouchableOpacity onPress={()=>updateSecureTextEntry()}>
                        {data.secureTextEntry? <Feather name="eye-off" color="grey" size={20}></Feather>:<Feather name="eye" color="grey" size={20}></Feather>}
                    </TouchableOpacity>
                </View>
                <View style={styles.button}>
                    <TouchableOpacity onPress={()=>{Login(data.email,data.password)}}>
                        <LinearGradient colors={['#08d4c4', '#01ab9d']} style={styles.signIn}>
                            <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>Sign In</Text>
                        </LinearGradient>
                    </TouchableOpacity> 
                    <TouchableOpacity onPress={()=>navigation.navigate('SignUpScreen')} style={[styles.signIn],{borderColor:'#009387',borderWidth:1,marginTop:15,borderRadius:10,width: Dimensions.get("screen").width - 20,height: 50,justifyContent: 'center',alignItems: 'center',borderRadius: 10,}}>
                        <Text style={styles.textSign}>Sign Up</Text>
                    </TouchableOpacity> 
                </View>
            </Animatable.View>
            {loading.isLoading?(
                <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
            ):null}
        </View>
    )
};
export default SignInScreen;
const styles = StyleSheet.create({
    container: {
      flex: 1, 
      backgroundColor: '#009387'
    },
    scrollView: {
    backgroundColor: "gray",
    marginHorizontal: 20
  },
  text: {
    fontSize: 42
  },
    header: {
        flex: 1,
        justifyContent: 'flex-end',
        paddingHorizontal: 20,
        paddingBottom: 50
    },
    footer: {
        flex: 3.2,
        backgroundColor: '#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 2.84,
          elevation: 5,
    },
    text_header: {
        color: '#009387',
        fontWeight: 'bold',
        fontSize: 30
    },
    text_footer: {
        color: '#05375a',
        fontSize: 18
    },
    action: {
        flexDirection: 'row',
        marginTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#f2f2f2',
        paddingBottom: 5
    },
    actionError: {
        flexDirection: 'row',
        marginTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#FF0000',
        paddingBottom: 5
    },
    textInput: {
        flex: 1,
        marginTop: Platform.OS === 'ios' ? 0 : -2,
        paddingLeft: 10,
        color: '#05375a',
    },
    errorMsg: {
        color: '#FF0000',
        fontSize: 14,
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 20,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10
    },
    signUp: {
        width: Dimensions.get("screen").width - 20,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    }
  });
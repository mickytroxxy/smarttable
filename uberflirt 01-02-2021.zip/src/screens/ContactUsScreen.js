import 'react-native-gesture-handler';
import {TouchableOpacity} from 'react-native-gesture-handler'
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import React, {useState } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView,Linking} from "react-native";
import { db } from '../screens/service';
import { FontAwesome, MaterialIcons } from "@expo/vector-icons";
import Feather from "react-native-vector-icons/Feather";
import {Content, List, ListItem, Left, Body, Right, Thumbnail, Text } from 'native-base';
const RootStack = createStackNavigator();
import * as Font from 'expo-font';
let userToken = null;
const ContactUsScreen = ({route,navigation}) =>{
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="ContactUsScreen" component={PageContent} options={{
            headerLeft: () => (
                <MaterialIcons.Button backgroundColor="#fff" name="keyboard-backspace" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></MaterialIcons.Button>
            ), 
            title:"CONTACT SUPPORT TEAM",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const [contacts,setContacts]=useState(null);
    const [fontsLoaded,setFontsLoaded]=useState(false);
    let customFonts = {
        'MontserratAlternates-Light': require('..//../fonts/MontserratAlternates-Light.otf'),
    };
    const loadFontsAsync = async ()=> {
        await Font.loadAsync(customFonts);
        setFontsLoaded(true);
    }
    let fontFamily = 'sans-serif-thin';
    if(fontsLoaded){
        fontFamily = 'MontserratAlternates-Light';
    }
    React.useEffect(()=>{
        const getRequests = async ()=>{
            await db.collection("contacts").get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                setContacts(data);
            });
        }
        loadFontsAsync();
        getRequests();
    },[]);
    const goToWhatsApp = (user)=>{
        Linking.openURL('whatsapp://send?text=hello there, I need help&phone='+user)
    }
    if(!contacts){
        return(
            <View style={{justifyContent:'center',alignContent:'center',flex:1,alignItems:'center'}}>
                <ActivityIndicator size="large" color="teal"></ActivityIndicator>
            </View>
        )
    }else{
        return(
            <ScrollView showsVerticalScrollIndicator={false} style={{backgroundColor:"#fff",marginTop:10}}>
                <List>
                    {   
                        contacts.map((item, i) =>  {
                            return(
                                <TouchableOpacity key={i} onPress={()=>{goToWhatsApp(item.user)}}>
                                    <ListItem avatar noBorder style={{borderBottomWidth:0.6,borderBottomColor:'#f0ece7'}}>
                                        <Left>
                                            <Feather name="user" size={36} color="teal"></Feather>
                                        </Left>
                                        <Body>
                                            <Text style={{fontFamily:fontFamily}}>{item.fname}</Text>
                                        </Body>
                                        <Right>
                                            <FontAwesome name="whatsapp" size={36} color="green"></FontAwesome>
                                        </Right>
                                    </ListItem>
                                </TouchableOpacity>
                            )
                        })
                    }
                </List>
            </ScrollView>
        )
    }      
};
export default ContactUsScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,
        borderColor:'#009387',borderWidth:1,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 25,
        borderColor: '#AEB5BC',
        borderRadius:5,
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        borderWidth:1,
        padding:5,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        //backgroundColor:'#92e6f5',
        borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
});

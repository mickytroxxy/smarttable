import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useState } from "react";
import { StyleSheet, Platform, Text, View, SafeAreaView, Image, ScrollView, Modal, Alert,Button, Dimensions , TouchableOpacity} from "react-native";
import * as ImagePicker from 'expo-image-picker';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { Container,Picker, Header, Content, Item, Input,Textarea, Form, Card, CardItem,Body,ListItem,Right,DatePicker } from 'native-base';
import { GlobalStyles } from '../styles/Global';
import moment from 'moment';
import {
    TouchableRipple,
    Switch
} from 'react-native-paper';
const ModalScreen = props =>{
    const [fee,setFee] = useState(null);
    const [feeDesc,setFeeDes] = useState(null);
    const [amount,setAmount] = useState(null);
    const [isDriverRequested,setIsDriverRequested]=useState(false);
    const browsePhoto = async (sourceType) => {
        props.closeModal();
        if(sourceType=="Gallery"){
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All,
                allowsEditing: true,
                aspect: [4, 4],
                quality: 0.5,
            });
            if (!result.cancelled) {
                imageSuccess(result.uri);
            }
        }else{
            let result = await ImagePicker.launchCameraAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All,
                allowsEditing: true,
                aspect: [4, 4],
                quality: 0.5,
            });
            if (!result.cancelled) {
                imageSuccess(result.uri);
            }
        }
        function imageSuccess (file){
            props.callback(file,'FILE');
        }
    };
    const dateHandler = (newDate)=>{
        props.closeModal();
        let birthDay = moment(newDate).format('L');
        props.callback(birthDay,'BIRTHDAY');
    }
    const setSelectedValue =(gender)=>{
        props.closeModal();
        props.callback(gender,'GENDER');
    }
    if(props.modalAttr.toOpen=="FILE BROWSER"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <View style={styles.button}>
                        <TouchableOpacity onPress={()=>{browsePhoto('Gallery')}}>
                            <LinearGradient colors={['#08d4c4', '#01ab9d']} style={styles.signIn}>
                                <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>GET FROM GALLERY</Text>
                            </LinearGradient>
                        </TouchableOpacity> 
                        <TouchableOpacity onPress={()=>{browsePhoto('Camera')}}>
                            <LinearGradient colors={['#08d4c4', '#01ab9d']} style={styles.signIn}>
                                <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>GET FROM CAMERA</Text>
                            </LinearGradient>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={()=>{props.closeModal()}}>
                        <Text style={[styles.textSign],{color:"tomato",fontWeight:"bold",fontSize:20}}>Cancel</Text>
                        </TouchableOpacity>  
                    </View>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="UPDATE FEE MODAL"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Item rounded style={GlobalStyles.searchInputText}>
                            <FontAwesome name="usd" color="#8e81b4" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            <Input placeholder={props.modalAttr.headerText.split(" ")[1].toUpperCase() + " FEE IS "+props.modalAttr.values[0]} onChangeText={(val)=>setFee(val)} />
                        </Item>
                        <Form>
                            <Textarea rowSpan={5} bordered placeholder="State your skills for this service..." style={{borderRadius:10,height:80,}}onChangeText={(val)=>setFeeDes(val)}/>
                        </Form>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback([fee,props.modalAttr.headerText.split(" ")[1],feeDesc],'FEE');props.closeModal()}}>
                                <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:120}]}>
                                    <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>UPDATE</Text>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="BUY CREDITS"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Item rounded style={GlobalStyles.searchInputText}>
                            <FontAwesome name="usd" color="#8e81b4" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            <Input placeholder="Buy at least 100 credits for 120" onChangeText={(val)=>setAmount(val)} />
                        </Item>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(amount,'PAYMENT');props.closeModal()}}>
                                <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:250}]}>
                                    <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>BUY CREDITS</Text>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="SEND A REQUEST"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{padding:5,marginTop:10,}}>
                        <View style={styles.serviceDes}>
                            <View style={{backgroundColor:"#eae9ee",height:36,alignContent:'center',alignItems:'center',borderTopLeftRadius:10,borderTopRightRadius:10,}}>
                                <Text style={styles.newLabel}>SERVICE DESCRIPTION</Text>
                            </View>
                            <View style={{padding:5}}>
                                <Text style={{borderBottomWidth:0.7,borderColor:'#d0cfd3',paddingBottom:5,color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>
                                    {props.modalAttr.values[1]}
                                </Text>
                                <ListItem noBorder>
                                    <Body>
                                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold',textTransform:'uppercase',fontSize:12,}}>Request uberFlirt Driver</Text>
                                    </Body>
                                    <Right>
                                        <TouchableRipple onPress={() => { setIsDriverRequested(!isDriverRequested) }}>
                                            <View style={styles.preference}>
                                                <View pointerEvents="none">
                                                    <Switch value={isDriverRequested} />
                                                </View>
                                            </View>
                                        </TouchableRipple>
                                    </Right>
                                </ListItem>
                            </View>
                        </View>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:10,}}>
                            <TouchableOpacity onPress={()=>{props.callback([props.modalAttr.values[0],props.modalAttr.headerText.split(" ")[1],isDriverRequested],'REQUESTSENDING');props.closeModal();setIsDriverRequested(false)}}>
                                <FontAwesome name="check-circle" color="#009387" size={50}></FontAwesome>
                            </TouchableOpacity>
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="ABOUT"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>{props.modalAttr.headerText}</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Form>
                            <Textarea rowSpan={5} bordered placeholder="Please tell us about yourself..." style={{borderRadius:10,height:80,}}onChangeText={(val)=>setFeeDes(val)}/>
                        </Form>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(feeDesc,'ABOUT');props.closeModal()}}>
                                <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:'auto',padding:10}]}>
                                    <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>UPDATE YOUR ABOUT</Text>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="AGE"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                        <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT DATE OF BIRTH</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:'auto',padding:10}]}>
                        <DatePicker
                            defaultDate={new Date(2000, 1, 1)}
                            minimumDate={new Date(1950, 1, 1)}
                            maximumDate={new Date(2003, 1, 1)}
                            locale={"en"}
                            modalTransparent={false}
                            animationType={"fade"}
                            androidMode={"default"}
                            placeHolderText="SELECT DATE"
                            textStyle={{ color: "#fff",fontSize:16,fontWeight:'bold',fontFamily:'Roboto' }}
                            placeHolderTextStyle={{ color: "#fff" }}
                            onDateChange={(date)=>dateHandler(date)}
                            disabled={false}
                        >
                            
                        </DatePicker>
                        </LinearGradient>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="GENDER"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT YOUR GENDER</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:'auto',padding:10}]}>
                            <Picker selectedValue="SELECT" style={{ height: 50, width: 150,color:'#fff',fontWeight:'bold',fontFamily:'Roboto' }}
                                onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
                            >
                                <Picker.Item label="SELECT" value="SELECT"/>
                                <Picker.Item label="MALE" value="MALE"/>
                                <Picker.Item label="FEMALE" value="FEMALE" />
                            </Picker>
                        </LinearGradient>
                    </Content>
                </View>
            </Modal>
        )
    }else if(props.modalAttr.toOpen=="FACEBOOK LINK"){
        return(
            <Modal animationType="slide" transparent={true} visible={props.isVisible} onRequestClose={() => {props.closeModal()}}>
                <View style={styles.centeredView}>
                    <View style={styles.ProfileFooterHeader}>
                        <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                            <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                        </View>
                        <View style={styles.statsContainer}>
                            <Text style={{textTransform:'uppercase',fontSize:15,fontWeight:'bold',color:'#f0faf6'}}>SELECT YOUR GENDER</Text>
                        </View>
                    </View>
                    <Content style={{marginTop:5,padding:10}}>
                        <Item rounded style={GlobalStyles.searchInputText}>
                            <FontAwesome name="facebook" color="#8e81b4" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            <Input placeholder="Type or paste facebook link" onChangeText={(val)=>setAmount(val)} />
                        </Item>
                        <View style={[styles.button,{marginTop:20}]}>
                            <TouchableOpacity onPress={()=>{props.callback(amount,'FACEBOOK');props.closeModal()}}>
                                <LinearGradient colors={['#08d4c4', '#01ab9d']} style={[styles.signIn,{width:250}]}>
                                    <Text style={[styles.textSign],{color:"#fff",fontWeight:"bold",fontSize:20}}>UPDATE FACEBOOK LINK</Text>
                                </LinearGradient>
                            </TouchableOpacity>   
                        </View>
                    </Content>
                </View>
            </Modal>
        )
    }
}
export default ModalScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    serviceDes:{
        borderRadius:10,
        borderWidth:0.5,
        borderColor:'#c8cbca'
    },
    newLabel: {
        color: "#009387",
        fontWeight: "bold",
        fontSize:16,
        marginTop:5,
      },
    preference: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        paddingHorizontal: 16,
    },
    centeredView:{
        minHeight:'60%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 100, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,

    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 11,
        color: "#fff",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        backgroundColor:'#e7d8d8',borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 200,
        height: 200,
        borderRadius: 12,
        overflow: "hidden",
        marginHorizontal: 10,
        shadowColor: "#000",
          shadowOffset: {
            width: 6,
            height: 2,
          },
          shadowOpacity: 1,
          shadowRadius: 8.84,

          elevation: 5,
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },
    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    }
});
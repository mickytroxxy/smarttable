import useUsers from './usersHook';
import 'react-native-gesture-handler';
import {TouchableOpacity} from 'react-native-gesture-handler'
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { ScrollView,StatusBar,StyleSheet, Text, View, SafeAreaView,Modal,TouchableHighlight,TouchableWithoutFeedback, TextInput, Image, Dimensions,FlatList, ActivityIndicator,Alert,ImageBackground } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'
import * as Animatable from 'react-native-animatable';
import React, { useEffect, useState } from "react";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Feather from "react-native-vector-icons/Feather";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { Container, Header, Content, Card, CardItem, Thumbnail, Button, Left, Body, Right } from 'native-base';
import { LinearGradient } from 'expo-linear-gradient';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { db } from '../screens/service';
import geohash from "ngeohash";
import ImageViewer from 'react-native-image-zoom-viewer';
const RootStack = createStackNavigator();
let myObject;
let outNav;
let users,usersArray=null,searchedUsers=null,startCoords,confirmDialog,globalUserToken,searchedLocation=false,getUsersByLocation;
import axios from 'axios';
import { analytics } from 'firebase';
let userToken;
const PostScreen = ({route,navigation}) =>{
    const { myToken } = route.params;
    userToken=myToken;
    const openMediaFiles = (mediaObj)=>{
        navigation.navigate("CameraScreen",{mediaObj:mediaObj})
    }
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="MapViewScreen" component={PageContent} options={{
            headerTitle: () => (
                <Image source={require("../../assets/ubershow.png")} style={{height:50,width:120}} resizeMode="center"></Image>
            ), 
            headerLeft: () => (
                <Feather.Button name="camera" color="#757575" size={30} style={{backgroundColor:'#fff'}} onPress={()=>{openMediaFiles({type:'instaPhoto',cameraType:'any',fileType:'image',isSelfie:false,userToken:userToken})}}></Feather.Button>
            ),
            headerRight: () => (
                <Feather.Button name="send" color="#757575" size={30} style={{backgroundColor:'#fff'}}></Feather.Button>
            ),
            headerTitleAlign:'center',
        }}/>
        </RootStack.Navigator>
    )
};
function PageContent({ navigation }) {
    const [users,startCoords,confirmDialog,testToken,showToast,getUsersByLocation,updateMyLocation] = useUsers();
    const [postHeight,setPostHeight]=useState(0);
    const [postsArray,setPostArray]=useState({
        postsObj:null,isLoading:true
    })
    const getDimensions = (layout)=>{
        const {x, y, width, height} = layout;
        setPostHeight(width)
    }
    const [photoViewer, setPhotoViewer] = useState({photoBrowserVisible:false,imageUrls:[{uri:''}]});
    const likeAction =  (id,currentLikes)=>{
        db.collection("postResults").where("liked", "==", id).where("liker", "==", userToken).get().then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            const documentId = userToken+"_"+id;
            if (data.length>0) {
                db.collection("postResults").doc(documentId).delete().then(function() {
                    db.collection("instaPhotos").doc(id).update({likes:(currentLikes-1)}).then(function() {
                        showToast("You removed your like from this post!");
                    }).catch(function(error) {});
                }).catch(function(error) {});
            }else{
                db.collection("postResults").doc(documentId).set({liker:userToken,liked:id}).then(function() {
                    db.collection("instaPhotos").doc(id).update({likes:(currentLikes+1)}).then(function() {
                        showToast("You liked this post!");
                    }).catch(function(error) {});
                }).catch(function(error) {});
            }
        });
    }
    const showPhotoBrowser = (uri)=>{
        setPhotoViewer({...photoViewer,photoBrowserVisible:true,imageUrls:[{url:uri}]})
    }
    React.useEffect(()=>{
        navigator.geolocation.getCurrentPosition(position => {
            const { latitude, longitude } = position.coords;
            const range = getGeohashRange(latitude, longitude, 250);
            db.collection("instaPhotos").where("geohash", ">=", range.lower).where("geohash", "<=", range.upper).limit(50).onSnapshot(function(snapshot) {
                const data = snapshot.docs.map(doc => doc.data());
                if (users.length>0) {
                    setPostArray({...postsArray,isLoading:false,postsObj:data})
                }
            });
        },error => alert(error.message),{ 
            enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
        );
    },[users])
    const isLoading = postsArray.isLoading;
    const postsObj = postsArray.postsObj;
    if(!isLoading){
        return(
            <View style={{backgroundColor:'#fff',flex:1}}>
                <View style={{height:120}}>
                    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{padding:10,paddingRight:20,height:postHeight}}>
                        <Animatable.View animation="slideInDown" duration={1000} useNativeDriver={true} style={{height:100,alignContent:'center',alignItems:'center',justifyContent:'center',}}>
                            <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.storyOuterShell]}>
                                <TouchableOpacity style={styles.storyInnerShell}>
                                    <MaterialIcons name="add-location" color="green" size={30} style={{backgroundColor:'#fff'}}></MaterialIcons>    
                                </TouchableOpacity>
                            </LinearGradient>
                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center',marginRight:10,fontSize:13}}>ADJUST</Text>
                        </Animatable.View>
                        {users!=null&&users.map((user, i) =>  {
                        return (
                            <Animatable.View animation="slideInRight" duration={1000} useNativeDriver={true} style={{height:100,alignContent:'center',alignItems:'center',justifyContent:'center',}} key={i}>
                                <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.storyOuterShell]}>
                                    <TouchableOpacity style={styles.storyInnerShell} onPress={() => navigation.navigate("ProfileScreen",{myToken: userToken,userObject:user})}>
                                        <Image source={{uri: user.avatar!=""?user.avatar:'https://picsum.photos/400/400'}} style={styles.listAvatar} ></Image>    
                                    </TouchableOpacity>
                                </LinearGradient>
                                <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center',marginRight:10,fontSize:13}}>{getDistance(startCoords.latitude, startCoords.longitude, user.latitude, user.longitude).toFixed(2)}km</Text>
                            </Animatable.View>
                        );
                        })}
                    </ScrollView>
                </View>
                <View style={{flex:1}}>
                    <Animatable.View animation="bounceIn" duration={1000} useNativeDriver={true} style={{paddingBottom:5}}>
                        <View style={styles.postFilter}>
                            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
                                <Text style={{alignItems:'center',alignContent:'center',justifyContent:'center',color:'#2a2828',fontFamily:'sans-serif-thin'}}>PHOTOS</Text>
                            </View>
                            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
                                <Text style={{alignItems:'center',alignContent:'center',justifyContent:'center',color:'teal',fontFamily:'sans-serif-medium'}}>ALL</Text>
                            </View>
                            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
                                <Text style={{alignItems:'center',alignContent:'center',justifyContent:'center',color:'#2a2828',fontFamily:'sans-serif-thin'}}>VIDEOS</Text>
                            </View>
                        </View>
                    </Animatable.View>
                    <ScrollView style={{padding:0,margin:0}} showsVerticalScrollIndicator={false}
                        //pagingEnabled // Enable paging
                        //decelerationRate={0} // Disable deceleration
                        //snapToAlignment='center'
                        //automaticallyAdjustInsets={true}
                        //snapToInterval={postHeight}
                        //disableIntervalMomentum={ true }
                    >
                    {postsObj!=null&&postsObj.map((item, i) =>  {
                        const userIndex = users.map(function(e) { return e.phoneNumber; }).indexOf(item.phoneNumber);
                        return (
                            <Card key={i} noShadow style={{borderColor:'#fff',elevation:1,shadowRadius:1,shadowOpacity:1.0,}}>
                                <Animatable.View animation="slideInUp" duration={1000} useNativeDriver={true}>
                                    <CardItem style={{padding:0}}>
                                        <Left>
                                            <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.storyOuterShell1]}>
                                                <Thumbnail source={{uri: users[userIndex].avatar!=""?users[userIndex].avatar:'https://picsum.photos/400/400'}} style={{width:44,height:44}} />
                                            </LinearGradient>
                                            <Body>
                                                <Text style={{color:'#464645',fontSize:13}}>{users[userIndex].fname.split(" ").join("_")}</Text>
                                            </Body>
                                        </Left>
                                        <Right>
                                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center',fontSize:13}}> {getDistance(startCoords.latitude, startCoords.longitude, item.latitude, item.longitude).toFixed(2)}km</Text>
                                        </Right>
                                        </CardItem>
                                        <CardItem cardBody onLayout={(event) => { getDimensions(event.nativeEvent.layout) }}>
                                            <TouchableWithoutFeedback onPress={()=>{showPhotoBrowser(item.url)}} style={{width:postHeight,height:350}}>
                                                <Animatable.Image animation="zoomInDown" duration={2500} useNativeDriver={true} style={{width:postHeight,height:300,borderRadius:10,borderColor:'#f8e6d9',borderWidth:0.5}} source={{uri: item.url!=""?item.url:'https://picsum.photos/400/400'}}></Animatable.Image>
                                            </TouchableWithoutFeedback>
                                        </CardItem>
                                        <CardItem>
                                            <Left>
                                                <Button transparent onPress={()=>{likeAction(item.documentId,item.likes)}}>
                                                <FontAwesome name="thumbs-o-up" size={30} style={{marginTop:10}} color="#757575"></FontAwesome> 
                                                <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center',marginTop:10,fontSize:13}}>  {item.likes}</Text>
                                                </Button>
                                            </Left>
                                            <Body style={{alignContent:'center',alignItems:'center',justifyContent:'center',}}>
                                                <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.profilePagebtn]}>
                                                    <TouchableOpacity onPress={() => navigation.navigate("ProfileScreen",{myToken: userToken,userObject:users[userIndex]})}>
                                                        <FontAwesome name="heart" size={30} color="#fff"></FontAwesome> 
                                                    </TouchableOpacity>
                                                </LinearGradient>
                                            </Body>
                                            <Right>
                                                {users[userIndex].availability=="FREE"?(
                                                    <Button transparent onPress={()=>{showToast("User is Available for booking")}} ><FontAwesome name="check-circle" size={34} style={{marginTop:10}} color="green"></FontAwesome></Button>
                                                ):(
                                                    <Button transparent onPress={()=>{showToast("User is NOT Available for booking")}}><MaterialIcons name="do-not-disturb" size={34} style={{marginTop:10}} color="orange"></MaterialIcons></Button>
                                                )} 
                                            </Right>
                                        </CardItem>
                                </Animatable.View>
                            </Card>
                        );
                    })}
                </ScrollView>
                </View>
                <Modal visible={photoViewer.photoBrowserVisible} transparent={true}>
                    <ImageViewer imageUrls={photoViewer.imageUrls} enableSwipeDown={true} onSwipeDown={()=>setPhotoViewer({...photoViewer,photoBrowserVisible:false})} />
                </Modal>
            </View>
        )
    }else{
        return(
            <View style={{justifyContent:'center',alignContent:'center',flex:1,alignItems:'center'}}>
                <ActivityIndicator size="large" color="teal"></ActivityIndicator>
            </View>
        )
    }
}
function getDistance(lat1, lon1, lat2, lon2) {
  var R = 6371; 
  var dLat = toRad(lat2-lat1);
  var dLon = toRad(lon2-lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c;
  return d;
}
function toRad(Value){
  return Value * Math.PI / 180;
}
const getGeohashRange = (latitude,longitude,distance) => {
  const lat = 0.0144927536231884; // degrees latitude per mile
  const lon = 0.0181818181818182; // degrees longitude per mile
  const lowerLat = latitude - lat * distance;
  const lowerLon = longitude - lon * distance;
  const upperLat = latitude + lat * distance;
  const upperLon = longitude + lon * distance;
  const lower = geohash.encode(lowerLat, lowerLon);
  const upper = geohash.encode(upperLat, upperLon);
  return {
    lower,
    upper
  };
};
export default PostScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  storyOuterShell:{
    width:65,
    height:65,
    borderRadius:100,
    alignContent:'center',alignItems:'center',justifyContent:'center',
    marginRight:10,
  },
  storyOuterShell1:{
    padding:1.5,
    borderRadius:100,
    alignContent:'center',alignItems:'center',justifyContent:'center',
    marginRight:10,
  },
  storyInnerShell:{
    alignContent:'center',alignItems:'center',justifyContent:'center',
    backgroundColor:'#fff',
    height:60,width:60,borderRadius:100,
  },
  listAvatar:{
    width:55,height:55,
    borderRadius:100,
    borderColor:'#e8e7e5',
    borderWidth:0.5,
  },
  profilePagebtn:{
    alignItems:'center',
    shadowColor:'#000',
    elevation:2,
    shadowRadius:5,
    shadowOpacity:1.0,
    height:60,width:60,borderRadius:100,
    alignContent:'center',alignItems:'center',justifyContent:'center',
  },
  postFilter:{
    height:40,
    borderRadius:20,
    backgroundColor:'#f8f3fa',
    width:'98%',marginLeft:'1%',
    justifyContent:'center',
    flexDirection:'row'
  },
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    width: '100%', height: '100%',
  },
});
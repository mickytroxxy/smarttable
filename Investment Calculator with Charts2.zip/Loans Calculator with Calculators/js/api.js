const api = [
  {
    type: 'Fixed Deposit',
    periodNRate: [{period:3,monthlyRate:4.41,anualRate:4.50},{period:6,monthlyRate:4.89,anualRate:5.00},{period:12,monthlyRate:5.61,anualRate:5.75},{period:24,monthlyRate:6.51,anualRate:6.70},{period:36,monthlyRate:6.93,anualRate:7.15},{period:60,monthlyRate:8.14,anualRate:8.45}],
  },
  {
    type: 'Notice Deposit',
    periodNRate: [{period:7,monthlyRate:3.93,anualRate:4.00},{period:32,monthlyRate:4.17,anualRate:4.25},{period:90,monthlyRate:4.41,anualRate:4.50}],
  },
  {
    type: 'Access Deposit',
    periodNRate: [{period:3,monthlyRate:0,anualRate:0},{period:6,monthlyRate:0,anualRate:0},{period:12,monthlyRate:0,anualRate:0},{period:24,monthlyRate:4.80,anualRate:0},{period:36,monthlyRate:0,anualRate:0},{period:60,monthlyRate:0,anualRate:0}],
  },
  {
    type: 'Tax Free',
    periodNRate: [{period:1,monthlyRate:5.70,anualRate:5.85}]
  },
]
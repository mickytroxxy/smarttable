import React, { useEffect, useState, createContext } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
export const UseContext = createContext();
export const AuthContext =props=>{
    const myFun = () =>{
        alert("WOW")
    }
    return(
        <UseContext.Provider value={myFun}>
            {props.children}
        </UseContext.Provider>
    )
}
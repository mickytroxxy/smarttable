import { createStackNavigator } from '@react-navigation/stack';
import React, {useState,useContext } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView, Platform,TouchableOpacity,Text,TextInput} from "react-native";
import {MaterialIcons,FontAwesome,Feather,Ionicons } from "@expo/vector-icons";
import { UserContext } from '../../../components/context';
import ModalScreen from './Modal';
const RootStack = createStackNavigator();

const QualityControlScreen = ({route,navigation}) =>{
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="AddItemScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"QUALITY CONTROL",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
                //fontFamily:fontFamilyObj.fontBold;
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const [isLoading,setIsLoading]=React.useState(false);
    const [finalComment,setFinalComment] = React.useState("")
    const {fontFamilyObj,showToast,confirmDialog,imageUrl,setImageUrl,getNetworkStatus,carObj,userState} = useContext(UserContext);
    const [modalStatus, setModalStatus] = useState({isVisible:false,result:null,target:"add-comment"});
    const [elements,setElements] = React.useState([
        {type:'INTERIOR CHECKS',element:'Radio',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Heater / air-con',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Headlights',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Indicators',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Wipers',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Washer nozzle',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Window Mechanisms',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Door Lock Mechanisms',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Upholstery',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Carpets and mats',status:true,comment:''},
        {type:'INTERIOR CHECKS',element:'Seats',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Body Paint Work',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Body Panel Gaps',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Body Panel Alignment',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Sign Writing',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Glass Scratches',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'No Plates',status:true,comment:''},
        {type:'EXTERIOR CHECKS',element:'Tyres & Rims',status:true,comment:''},
        {type:'ELECTRICAL',element:'Headlights',status:true,comment:''},
        {type:'ELECTRICAL',element:'Fog Lights',status:true,comment:''},
        {type:'ELECTRICAL',element:'Indicators',status:true,comment:''},
        {type:'ELECTRICAL',element:'Reverse Lights',status:true,comment:''},
        {type:'ELECTRICAL',element:'Brake Lights',status:true,comment:''},
        {type:'ELECTRICAL',element:'No Plate Lights',status:true,comment:''},
        {type:'ELECTRICAL',element:'Dashboard Lights',status:true,comment:''},
        
    ]);
    const itemLength = elements.length - 1;
    const [elementIndex,setElementIndex] = React.useState(0);
    const currentElement = elements[elementIndex];
    const actionTaken = status =>{
        if(!status){
            setModalStatus({...modalStatus,isVisible:true});
        }else{
            nextElement();   
        }
    }
    const nextElement = () => setElementIndex(elementIndex + 1)
    const finalActionTaken = finalStatus =>{
        const Key_Ref = carObj.Key_Ref;
        const userId = userState.userDetails.userId;
        const data = JSON.stringify(elements);
        confirmDialog("SUBMIT FINAL RESULT","Please note, this may not be altered, Press Confirm to proceed","confirm","Cancel",(cb)=>{
            getNetworkStatus((socket,url)=>{
                socket.emit("qualityControl",Key_Ref,userId,data,finalStatus,finalComment,(result)=>{
                    if(result){
                        showToast("Quality control updated successfully!")
                    }
                });
            });
        })
    }
    function closeModal(response) {
        setModalStatus({...modalStatus,isVisible:false});
        if(response){
            const comment = response.value;
            setElements(elements.map(item => item.element === currentElement.element ? {...item,comment} : item));
            navigation.navigate("CameraScreen",{options:{category:"QUALITY CONTROL",subCategory:currentElement.element},counter:0,comment})
        }
    }
    React.useEffect(()=>{
        if(imageUrl){
            const newList = elements.map(item => item.element === currentElement.element ? {...item,imageUrl} : item);
            setElements(newList);
            setImageUrl(null);
            nextElement(newList);
        }
    },[imageUrl])
    return(
        <View style={styles.container}>
            {(elementIndex === itemLength) ?(
                <View style={{alignItems:'center'}}>
                    <Text style={{fontFamily:fontFamilyObj.customBold,fontSize:24,color:'#757575'}}>FINAL RESULT</Text>
                    <Text style={{fontFamily:fontFamilyObj.customBold,fontSize:18,color:'#000',textAlign:'center'}}>Please press the checkbox icon for pass and cancel icon for fail</Text>
                    <View style={styles.searchInputHolder}>
                        <TextInput
                            placeholder="Enter your comment..." onChangeText={(val)=>setFinalComment(val)}
                            style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575',width:'90%'}}
                        />
                    </View>
                    <View style={{flexDirection:'row',marginTop:50}}>
                        <TouchableOpacity onPress={()=>{finalActionTaken(false)}} style={{margin:30}}>
                            <FontAwesome name="times-circle" size={100} color="tomato" alignSelf="center"></FontAwesome>
                        </TouchableOpacity>  
                        <TouchableOpacity style={{margin:30}} onPress={()=>{finalActionTaken(true)}}>
                            <FontAwesome name="check-circle" color="green" size={100}></FontAwesome>
                        </TouchableOpacity>
                    </View>
                </View>
            ):(
                <View style={{alignItems:'center'}}>
                    <Text style={{fontFamily:fontFamilyObj.customBold,fontSize:24,color:'#757575'}}>{currentElement.type}</Text>
                    <Text style={{fontFamily:fontFamilyObj.customBold,fontSize:18,color:'#000'}}>{currentElement.element}</Text>
                    <View style={{flexDirection:'row',marginTop:100}}>
                        <TouchableOpacity onPress={()=>{actionTaken(false)}} style={{margin:30}}>
                            <FontAwesome name="times-circle" size={100} color="tomato" alignSelf="center"></FontAwesome>
                        </TouchableOpacity>  
                        <TouchableOpacity style={{margin:30}} onPress={()=>{actionTaken(true)}}>
                            <FontAwesome name="check-circle" color="green" size={100}></FontAwesome>
                        </TouchableOpacity>
                    </View>
                </View>
            )}
            <ModalScreen modalStatus={modalStatus} closeModal={closeModal}/>
        </View>
    )
};
export default QualityControlScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#fff',
        justifyContent:"center",
        alignContent:'center',
        alignItems:'center'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5',
        width:300,paddingLeft:10,
        marginTop:50
    },
});

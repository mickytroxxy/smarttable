import {createStackNavigator} from 'react-navigation-stack';
import {createAppNavigator} from 'react-navigation';

const stackNavigatorOptions ={
    headerShow:false
}
const appNavigator =({
    Login:{screen:Login},
    Register:{screen:Register},
})

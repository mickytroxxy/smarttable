import React, { useState } from 'react';
import { Platform, StyleSheet, Text, View,Dimensions, Image } from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';

const SpinnerScreen = props =>{
    const [spinnerVisible,setSpinnerVisible]= useState(props.isLoading);
    return(
        <View style={styles.container}>
            <Spinner
            customIndicator = {(<View style={styles.spinnerContainer}>
                <View style={styles.indicator}>
                <Image source={require("../../assets/spinner.gif")} style={styles.image} resizeMode="cover"></Image>
                </View>
                <View style={styles.text}><Text>{props.text}</Text></View>
            </View>)}
            visible={spinnerVisible}
            />
        </View>
    )
};
export default SpinnerScreen;
const {width} = Dimensions.get("screen");
const styles = StyleSheet.create({
    spinnerTextStyle: {
      color: '#FFF',
      fontWeight:'700',
      fontSize:18,
    },
    indicator:{
       flex:1, 
       justifyContent: 'center',
      alignItems: 'center',
    },
    text:{
        flex:3, 
        justifyContent: 'center',
      alignItems: 'center',
      color:'#2a2828',
      fontFamily:'sans-serif-thin',
      fontWeight:'700'
    },
    spinnerContainer:{
       backgroundColor:'#fff',
       width:(width-60),
       height:80,
       borderRadius:7,
       padding:10,
       shadowColor: "#B0B0B0",
          shadowOffset: {
            width: 2,
            height: 2,
          },
          shadowOpacity: 4.5,
          shadowRadius: 3.84,
          elevation: 5,
          flexDirection:'row',
    },
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF'
    },
    welcome: {
      fontSize: 20,
      textAlign: 'center',
      margin: 10
    },
    instructions: {
      textAlign: 'center',
      color: '#333333',
      marginBottom: 5
    },
    image:{
      width:40,
      height:40,
    }
  });
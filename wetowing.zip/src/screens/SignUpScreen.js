import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import { StyleSheet, Platform, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity, Image, Dimensions, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable'; //061 746 2677 dayalagovender@gmail.com
import { AuthContext } from "../components/context";
import { db } from '../screens/service'
const SignUpScreen = ({navigation}) =>{
    const [data,setData]=React.useState({
        fname: '',password:'',check_textInputChange:false,secureTextEntry:true,confirm_password:'',phone_number:'',check_phoneInputChange:false
    })
    const { setUserTokenFn } = React.useContext(AuthContext);
    const textInputChange = (val,valType)=>{
        if(val.length!=0){
            if(valType=="fullName"){
                setData({ ...data, fname: val, check_textInputChange: true });
            }else if(valType=="password"){
                setData({...data, password:val})
            }else if (valType=="phoneNumber") {
                setData({...data, phone_number:val, check_phoneInputChange:true})
            }
        }else{
            if(valType=="fullName"){
                setData({ ...data, fname: val, check_textInputChange: false });
            }else if(valType=="password"){
                setData({...data, password:val})
            }else if (valType=="phoneNumber") {
                setData({...data, phone_number:val, check_phoneInputChange:false})
            }
        }
    }
    const updateSecureTextEntry = ()=>{
        setData({
            ...data,
            secureTextEntry: !data.secureTextEntry,
        })
    }
    const saveUser = (fname, phoneNumber, password)=>{
      if (fname.length > 5 && phoneNumber.length > 8) {
        if (password.length > 5) {
          db.collection("users").doc(phoneNumber).set({fname: fname, phoneNumber: phoneNumber,password: password })
          .then(function() {
              setUserTokenFn(phoneNumber)
          })
          .catch(function(error) {
              console.error("Error writing document: ", error);
          });
        } else {
          showToast("Password field should be at least 6 characters long!");
        }
      } else {
        showToast("Invalid Full Name or Invalid phone number!");
      }
    }
    const showToast = (message)=>{
        ToastAndroid.show(message, ToastAndroid.SHORT); 
    }
    return (
      <ScrollView style={GlobalStyles.container}>
        <View animation="fadeInUpBig" style={styles.footer}>
          <Text style={styles.newLabel}>FULL NAME</Text>
          <View style={styles.action}>
            <FontAwesome name="user-o" color="#009387" size={20}></FontAwesome>
            <TextInput
              style={styles.textInput}
              placeholder="FULL NAME"
              autoCapitalize="none"
              onChangeText={val => textInputChange(val, "fullName")}
            ></TextInput>
            {data.check_textInputChange ? (
              <Animatable.View animation="bounceIn">
                <Feather name="check-circle" color="green" size={20}></Feather>
              </Animatable.View>
            ) : null}
          </View>

          <Text style={styles.newLabel}>PHONE NUMBER</Text>
          <View style={styles.action}>
            <Feather name="phone" color="#009387" size={20}></Feather>
            <TextInput
              style={styles.textInput}
              placeholder="Phone number"
              autoCapitalize="none"
              keyboardType={"phone-pad"}
              onChangeText={val => textInputChange(val, "phoneNumber")}
            ></TextInput>
            {data.check_phoneInputChange ? (
              <Animatable.View animation="bounceIn">
                <Feather name="check-circle" color="green" size={20}></Feather>
              </Animatable.View>
            ) : null}
          </View>

          <Text style={styles.newLabel}>PASSWORD</Text>
          <View style={styles.action}>
            <Feather name="lock" color="#009387" size={20}></Feather>
            <TextInput
              style={styles.textInput}
              placeholder="Your Password"
              autoCapitalize="none"
              secureTextEntry={data.secureTextEntry ? true : false}
              onChangeText={val => textInputChange(val, "password")}
            ></TextInput>
            <TouchableOpacity onPress={() => updateSecureTextEntry()}>
              {data.secureTextEntry ? (
                <Feather name="eye-off" color="grey" size={20}></Feather>
              ) : (
                <Feather name="eye" color="grey" size={20}></Feather>
              )}
            </TouchableOpacity>
          </View>
          <View style={styles.button}>
            <TouchableOpacity
              onPress={() => {
                saveUser(data.fname, data.phone_number, data.password);
              }}
            >
              <LinearGradient
                colors={["#08d4c4", "#01ab9d"]}
                style={styles.signIn}
              >
                <Text
                  style={
                    ([styles.textSign],
                    { color: "#fff", fontWeight: "bold", fontSize: 20 })
                  }
                >
                  Sign Up
                </Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={
                ([styles.signIn],
                {
                  borderColor: "#009387",
                  borderWidth: 1,
                  marginTop: 15,
                  borderRadius: 10,
                  width: Dimensions.get("screen").width - 20,
                  height: 50,
                  justifyContent: "center",
                  alignItems: "center",
                  borderRadius: 10
                })
              }
            >
              <Text style={styles.textSign}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    );
};
export default SignUpScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#009387"
  },
  header: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 50
  },
  footer: {
    flex: 3,
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
    marginLeft: 5,
    marginRight: 5
  },
  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 30
  },
  text_footer: {
    color: "#05375a",
    fontSize: 18
  },
  action: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f2f2f2",
    paddingBottom: 5
  },
  actionError: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#FF0000",
    paddingBottom: 5
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : -12,
    paddingLeft: 10,
    color: "#05375a"
  },
  errorMsg: {
    color: "#FF0000",
    fontSize: 14
  },
  button: {
    alignItems: "center",
    marginTop: 50
  },
  signIn: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  signUp: {
    width: Dimensions.get("screen").width - 20,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold"
  },
  newLabel: {
    marginTop: 25,
    color: "#009387",
    fontWeight: "bold"
  }
});
import React from 'react';
import EntryScreen from "./src/screens/Entry";
import { UserProvider } from './components/context';
import { StatusBar } from 'expo-status-bar';
export default function App() {
  return (
    <UserProvider>
      <EntryScreen></EntryScreen>
      <StatusBar style="auto" />
    </UserProvider>
  );
}
//C:\Users\lennovo m93\Desktop\apps\react-native-cli\com.magsnapshot.api\android\app\build\generated\not_namespaced_r_class_sources\debug\r\androidx
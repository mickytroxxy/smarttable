import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity,Image } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import SplashScreen from './SplashScreen';
import SignInScreen from  './SignInScreen';
import SignUpScreen from './SignUpScreen';
import Icon from 'react-native-vector-icons/Ionicons'
const RootStack = createStackNavigator();
const RootStackScreen = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "none",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        >
          <RootStack.Screen
            name="SplashScreen"
            component={SplashScreen}
            options={{
              headerLeft: () => (<View style={{paddingLeft:10}}><Image source={require("../../assets/ubertext.png")} style={{height:50,width:120}} resizeMode="center"></Image></View>),
              title:"",
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <RootStack.Screen
            name="SignInScreen"
            component={SignInScreen}
            options={{ title: "", headerLeft:"" }}
          />
          <RootStack.Screen
            name="SignUpScreen"
            component={SignUpScreen}
            options={{
              title: 'CREATE ACCOUNT',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default RootStackScreen;
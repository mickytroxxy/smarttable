import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/Ionicons'
import HomeScreen from './src/screens/Login';
import Registration from './src/screens/Registration';
import RootStackScreen from './src/screens/RootStackScreen';
import Home from './src/screens/Home';
import MainTabScreen from './src/screens/MainTabScreen';
import {AuthContext} from './src/components/context';
import { GlobalStyles } from './src/styles/Global';
import { View } from 'react-native-animatable';
import { StyleSheet, Text, ActivityIndicator, Button, TextInput, TouchableOpacity, Image } from 'react-native';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
export default function App() {
  const [isLoading,setIsLoading] = React.useState(true);
  const [userToken,setUserToken] = React.useState(null);
  const initialLoginState = {
    isLoading:true,userName:null,userToken:null,
  }
  const authContext = React.useMemo(()=>({
    signIn:(userName,password)=>{
      if(userName.toUpperCase()=="MICKY" && password=="pass"){
        setUserToken("Troxxy"),
        setIsLoading(false)
      }else{
        alert("Invalid Username");
      }
    },
    signOut:()=>{
      setUserToken(null),setIsLoading(false)
    },
    signUp:()=>{
      setUserToken('qwerty'),setIsLoading(false)
    }
  }),[]);
  useEffect(()=>{
    setTimeout(()=>{
      setIsLoading(false)
    },3000)
  },[])
  if(isLoading){
    return(
      <View style={{flex:1,justifyContent:'center',alignItems:'center'}}><ActivityIndicator size="large"></ActivityIndicator></View>
    );
  }
  return (
    <AuthContext.Provider value={authContext} >
      <NavigationContainer>
      {userToken===null? <RootStackScreen/>: 
        <Drawer.Navigator initialRouteName="Home">
          <Drawer.Screen name="Home" component={MainTabScreen} />
        </Drawer.Navigator>
      }
      </NavigationContainer>
    </AuthContext.Provider>
  );
}
import React from 'react'

import Home from './screen/Home'

const App = () => {
	return <Home />
}

export default App

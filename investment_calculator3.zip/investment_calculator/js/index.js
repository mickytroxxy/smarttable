const $$ = Dom7;
const app = new Framework7({modalTitle: '',material: true,pushState: true});
const mainView = app.addView('.view-main', {dynamicNavbar: true,domCache: true});
const periods = ["3 MONTHS","6 MONTHS","12 MONTHS","24 MONTHS","36 MONTHS","48 MONTHS"];
let chart;
let series=[ {
    name: 'Fixed',
    data: [3, 4, 3, 5, 4, 10, 12],
    marker: {
        enabled: false
    },
    color: '#000',
    defaultColor: '#000',
    opacity: 1,
},{
    name: 'Notice',
    data: [5, 9, 10, 3, 7, 9, 30],
    marker: {
        enabled: false
    },
    opacity: 0.2,
    color:'#f07ef7',
    defaultColor: '#f07ef7',
}, {
    name: 'Access',
    data: [1, 3, 4, 3, 3, 5, 4],
    marker: {
        enabled: false
    },
    opacity: 0.2,
    color:'#7ef7df',
    defaultColor: '#7ef7df',
}, {
    name: 'Tax',
    data: [16, 23, 14, 31, 37, 5, 40],
    marker: {
        enabled: false
    },
    opacity: 0.2,
    color:'#faac75',
    defaultColor: '#faac75',
}]
$(document).ready(()=>appIsReady());

const appIsReady=()=>{
    chart = Highcharts.chart('container', {
        chart: {
            type: 'areaspline',
            events: {
                load: function() {
                  var axis = this.xAxis[0] 
                  var ticks = axis.ticks
                  var points = this.series[0].points
                  var tooltip = this.tooltip
                  points.forEach(function(point, i) {
                    if (ticks[i]) {
                      var label = ticks[i].label.element
                      label.onclick = function() {
                        tooltip.getPosition(null, null, point) 
                        tooltip.refresh(point)
                      }
                    }
                    
                  });
                },
            }
        },
        title: {
            text: ''
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        yAxis:{
            visible:false,
        },
        legend: {
            align: 'center',
            x: 0,
            verticalAlign: 'top',
            y: 0,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            shadow: false,
            useHTML: true,
            itemDistance: 50,
            symbolPadding: 0,
            symbolWidth: 0,
            symbolHeight: 0,
            squareSymbol: false,
            labelFormatter: function () {
                return getSymbol(this.name)+'<div style="text-align: center;">' + this.name+'</div><div style="text-align: center;">' + checkName(this.name) +'</div>';
            },
            x: 0,
        },
        xAxis: {
            categories:periods,
            min:0.5,
            max:5.5,
            tickInterval:1,
            maxPadding:0,
            endOnTick:false,
            startOnTick:false,
        },
        tooltip: {
            valueSuffix: ''
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.3
            },
            series: {
                events: {
                    legendItemClick: function() {
                        console.log(this.userOptions.color)
                        var series      = this.chart.series;
                        $(series).each(function(){
                            this.update({ opacity: 0.2 });
                            this.update({
                                color: '#c1c0bf'
                            })
                        });
                        this.update({ opacity: 1,color:this.defaultColor });
                        return false;
                    }
                },
                showInLegend: true,
                states: {
                    inactive: {
                        opacity: 1
                    },
                    hover: {
                        brightness: 0.3   
                    },
                    select: {
                        enabled: false
                    }
                }
            }
        },
        series: series,
    });
}
const setInactive=()=>{
    chart.series[0].setState('inactive');
}
function checkName(legendName){
    return legendName=='Tax'?'Free':'Deposit';
}
const getSymbol=(legendName)=>{
    let color;
    if(legendName=='Fixed'){
        color='#000';
    }else if(legendName=='Access'){
        color='#7ef7df';
    }else if(legendName=='Notice'){
        color='#f07ef7';
    }else if(legendName=='Tax'){
        color='orange';
    }
    return "<div class='investment_indicator' style='background-color: "+color+"'></div>";
}
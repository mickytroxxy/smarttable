import {TouchableOpacity} from 'react-native-gesture-handler'
import { createStackNavigator } from '@react-navigation/stack';
import { GlobalStyles } from '../styles/Global';
import SpinnerScreen from '../screens/SpinnerScreen';
import React, { useEffect, useState } from "react";
import { StyleSheet,Modal, Platform, Text, View, SafeAreaView, Image, ScrollView, Alert,Button, Dimensions,PermissionsAndroid,Linking} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import ParallaxScroll from '@monterosa/react-native-parallax-scroll';
import { db,storage } from '../screens/service';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { useIsFocused } from '@react-navigation/native';
import FontAwesome from "react-native-vector-icons/FontAwesome";
import useUsers from './usersHook';
import ModalScreen from './Modal';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import ImageViewer from 'react-native-image-zoom-viewer';
import {ListItem, Left, Body, Right,List } from 'native-base';
import moment from 'moment';
import * as Notifications from 'expo-notifications';
import * as Font from 'expo-font';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
  } from 'react-native-popup-menu';  
const Stack = createStackNavigator();
let profileOwner = true;
let userToken = null;
let userObj = null;
let viewerToken = null;
let loopCounter = -1;
let requestObj = null;
let verificationPhotoHolderWidth=0;
let parallaxHeight=0;
let users,startCoords,confirmDialog,globalUserToken,showToast;
const ProfileScreen = ({route,navigation}) =>{
    const {height} = Dimensions.get("screen");
    parallaxHeight = parseInt((0.45 * parseFloat(height)).toFixed(0));
    const isFocused = useIsFocused();
    if(isFocused);
    const [usersNew,startCoordsNew,confirmDialogNew,testTokenNew,showToastNew] = useUsers();
    users=usersNew;startCoords=startCoordsNew;confirmDialog=confirmDialogNew;showToast=showToastNew;
    const [avatar, setAvatar ] = useState("../assets/media2.jpg");
    const [requestObject, setRequestObject] = useState(null);
    const { myToken, userObject } = route.params;
    let friendToken = userObject.phoneNumber;
    const [loading,setIsLoading]=React.useState({
        isLoading:false, text:''
    })
    userObj = [userObject];
    viewerToken = myToken;
    if(myToken==friendToken){
        userToken = myToken;
        profileOwner = true;
    }else{
        userToken = friendToken;
        profileOwner=false;
    }

    const [fontsLoaded,setFontsLoaded]=useState(false);
    let customFonts = {
        'MontserratAlternates-Light': require('..//../fonts/MontserratAlternates-Light.otf'),
    };
    const loadFontsAsync = async ()=> {
        await Font.loadAsync(customFonts);
        setFontsLoaded(true);
    }
    let fontFamily = 'sans-serif-thin';
    if(fontsLoaded){
        fontFamily = 'MontserratAlternates-Light';
    }
    React.useEffect(() => {
        navigation.addListener("focus", async() => {
            setAvatar(userObj[0].avatar);
            getConnectionStatus();
            db.collection("users").doc(userToken).onSnapshot(function(doc) {
                if([doc.data()].length>0){
                    setAvatar(doc.data().avatar);
                }
            });
            if(!profileOwner){
                const updateOption = [true,false];
                if(updateOption[Math.floor(Math.random()*updateOption.length)]){
                    const titleOption = ["SOMEONE IS ON YOUR PROFILE","YOU HAVE A VISITOR", "YOUR PROFILE IS BEING VIEWED","YOU GETTING A LOT OF ATTENTION"];
                    sendPushNotification(userObj[0].notificationToken,titleOption[Math.floor(Math.random()*titleOption.length)],"Someone just visited your profile, click to show you are available",viewerToken);
                }
            }
        });
        loadFontsAsync();
    }, []);
    const getConnectionStatus = ()=>{
        db.collection("requests")
        .where("connectionId", "in", [userToken+viewerToken,viewerToken+userToken])
        .get().then(querySnapshot => {
            const data = querySnapshot.docs.map(doc => doc.data());
            if (data.length>0) {
                requestObj=data[0];
                setRequestObject(data[0])
            }else{
                requestObj = null;
                setRequestObject(null)
            }
        });
    }
    return(
        <ParallaxScroll
            headerHeight={50}
            isHeaderFixed={false}
            parallaxHeight={parallaxHeight}
            fadeOutParallaxBackground={true}
            renderParallaxBackground={({ animatedValue }) => <Background animatedValue={animatedValue} avatar={avatar}/>}
            renderParallaxForeground={({ animatedValue }) => <Foreground navigation={navigation} fontFamily={fontFamily} setIsLoading={[loading,setIsLoading]} setAvatar={setAvatar} requestObject={requestObject} setRequestObject={setRequestObject}/>}
            parallaxBackgroundScrollSpeed={5}
            useNativeDriver={true}
            parallaxForegroundScrollSpeed={2.5}
            showsVerticalScrollIndicator={false}
            >
            <ParallaxBody navigation={navigation} fontFamily={fontFamily} setRequestObject={setRequestObject} requestObject={requestObject} setIsLoading={[loading,setIsLoading]}/>
            {loading.isLoading?(
                <SpinnerScreen isLoading={loading.isLoading} text={loading.text}></SpinnerScreen>
            ):null}
        </ParallaxScroll> 
    )
};
const Background = props =>{
    return(
        <View style={GlobalStyles.ProfileHeader}>
            <Animatable.Image animation="slideInDown" duration={1500} useNativeDriver={true} source={{uri: props.avatar!=""?props.avatar:'https://picsum.photos/400/400'}} style={GlobalStyles.profilepic} resizeMode="stretch"></Animatable.Image>
        </View>
    )
}
const ParallaxBody = props =>{
    const [photosArray, setPhotosArray] = React.useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const [photoBrowserVisible, setPhotoBrowserVisible] = useState(false);
    const [modalAttr, setModalAttr] = useState({toOpen:'FILE BROWSER',headerText:'SELECT FROM',values:''});
    const [rated,setRated]=useState({stars:0,isMe:false});
    const [prices,setPrices]=useState(
        {Drink:0,Massage:0,Flirting:0,Booking:0,Dinner:0,Partner:0,DrinkDesc:'',MassageDesc:'',FlirtingDesc:'',BookingDesc:'',DinnerDesc:'',PartnerDesc:''}
    )
    const [showCount,setShowCount]=useState(0);
    const [aboutUser,setAboutUser]=useState({
        phoneNumber:userToken,
        about:'This user does not have the about info. Please be cautious about this user',
        birthDay:'01/01/2002',
        gender:'UNKNOWN',
        selfiePhoto:'',
        idPhoto:'',
        facebookLink:'https://www.facebook.com/'
    })
    function closeModal() {
        setModalVisible(false);
    }
    const openMediaFiles = (mediaObj)=>{
        props.navigation.navigate("CameraScreen",{mediaObj:mediaObj})
    }
    async function callback(file,status) {
        if(status=="FILE"){
            const response = await fetch(file);
            const blob = await response.blob();
            var metadata = {contentType: 'image/png',};
            const filename = file.substring(file.lastIndexOf('/')+1);
            const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your file, Please wait...'})
            await storageRef.put(blob,metadata).then(function(snapshot) {
                const newArray = photosArray.concat({url:file});
                setPhotosArray(newArray);
                storageRef.getDownloadURL().then(downloadURL => {
                    var uuid = Math.floor(Math.random() * (10000000 - 100000000 + 1)) + 100000000;
                    db.collection("photos").doc(uuid.toString()).set({url:downloadURL,phoneNumber:userToken,documentId:uuid.toString()}).then(function() {
                        showToast("Your photo has been uploaded!");
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error writing document: ", error);
                    });
                })
            });
        }else if(status=="FEE"){
            updateFee(file);
        }else if(status=="REQUESTSENDING"){
            sendRequest(file);
        }else if(status=="ABOUT"){
            updateAbout(file);
        }else if(status=="BIRTHDAY"){
            updateBirthDay(file);
        }else if(status=="GENDER"){
            updateGender(file);
        }else if(status=="FACEBOOK"){
            updateFacebook(file);
        }else if(status=="SELFIE"){
            updateSelfie(file);
        }else if(status=="ID PHOTO"){
            updateIdPhoto(file);
        }
    }
    React.useEffect(() => {
        props.navigation.addListener("focus", async() => {
            db.collection("photos").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                setPhotosArray(data)
            });
            db.collection("prices").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                if(data.length>0){
                    setPrices(data[0]);
                }
            });
            /*db.collection("aboutusers").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                const data = querySnapshot.docs.map(doc => doc.data());
                if(data.length>0){
                    setAboutUser(data[0])
                }
            });*/
            db.collection("aboutusers").doc(userToken).onSnapshot(function(doc) {
                if(doc.data()!=null || doc.data()!=undefined){
                    setAboutUser(doc.data());
                }
            });
            db.collection("stars").where("liked", "==", userToken).get().then(querySnapshot => {
                const total = querySnapshot.docs.map(doc => doc.data());
                db.collection("stars").where("liked", "==", userToken).where("liker", "==", viewerToken).get().then(querySnapshot => {
                    const data = querySnapshot.docs.map(doc => doc.data());
                    if (data.length>0) {
                        setRated({...rated,stars:total.length,isMe:true});
                    }else{
                        setRated({...rated,stars:total.length,isMe:false});
                    }
                });
            });
            if(profileOwner){
                db.collection("aboutusers").where("phoneNumber", "==", userToken).get().then(querySnapshot => {
                    const data = querySnapshot.docs.map(doc => doc.data());
                    if (data.length==0) {
                        db.collection("aboutusers").doc(userToken).set(aboutUser).then(function() {
                            showToast("Please setup your about section!");
                        }).catch(function(error) {});
                    }
                });
                getMeetUpsCount();
            }
        });
    }, []);
    const getMeetUpsCount = async ()=>{
        await db.collection("requests").where("sender", "==", userToken).where("status", "==", "COMPLETED").get().then(querySnapshot => {
            const data1 = querySnapshot.docs.map(doc => doc.data());
            setShowCount(data1.length);
            db.collection("requests").where("receiver", "==", userToken).where("status", "==", "COMPLETED").get().then(querySnapshot => {
                const data2 = querySnapshot.docs.map(doc => doc.data());
                setShowCount(data1.length + data2.length);
            }); 
        });
    }
    const actionTaken =(option)=>{
        if(profileOwner){
            setModalVisible(true);
            setModalAttr({...modalAttr,headerText:"UPDATE "+option+" FEE",toOpen:"UPDATE FEE MODAL",values:[prices[option],prices[option+"Desc"]]})
        }else{
            if(userObj[0].balance>=0){
                if(userObj[0].availability=="FREE"){
                    setModalVisible(true);
                    setModalAttr({...modalAttr,headerText:"THEIR "+option+" FEE IS "+prices[option]+"c",toOpen:"SEND A REQUEST",values:[prices[option],prices[option+"Desc"]]})
                }else{
                    showToast("User is currently busy, Try again later!");
                }
            }else{
                showToast("This account is temporary unavailable!");
            }
        }
    }
    const sendRequest = (returnArray)=>{
        let connectionId;
        const requestType = returnArray[1];

        const date = moment(returnArray[3]).format('L');
        const time = moment(returnArray[4]).format('HH:mm');
        const hours = returnArray[5];
        const paymentMethod = returnArray[6];
        const price = parseFloat(returnArray[0]) * parseFloat(hours);
        if ( requestObj==null ) {
            connectionId = viewerToken+userToken;
        }else{
            connectionId = requestObj.connectionId;
        }
        if(paymentMethod=="CREDITS"){
            var text = "Are you sure you want to be with "+userObj[0].fname+" for "+hours+" hours from "+time+" on "+date+"? Your account will be deducted by "+price+"c just after you confirm the arrival of "+userObj[0].fname;
        }else{
            var text = "Are you sure you want to be with "+userObj[0].fname+" for "+hours+" hours from "+time+" on "+date+"? Please handover / give the sum of R "+parseFloat(price).toFixed(2)+" to "+userObj[0].fname+" after you approve her/his arrival"
        }
        confirmDialog("SEND "+requestType.toUpperCase()+" REQUEST",text,"Confirm","Cancel",(cb)=>{
            if(cb){
                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Placing your request, Please wait...'});
                getUserBalance(viewerToken, (balance)=>{
                    if(paymentMethod=="CREDITS"){
                        if(parseFloat(balance)>=price){
                            db.collection("requests").doc(connectionId).set({sender:viewerToken,fee:(price),receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now(),date:date,time:time,hours:hours,paymentMethod:paymentMethod}).then(function() {
                                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                showToast("Your request has been send for approval");
                                sendPushNotification(userObj[0].notificationToken,"NEW "+requestType+" REQUEST","You have a new request worth "+price+" credits, Click to take action",viewerToken);
                                props.setRequestObject({sender:viewerToken,fee:price,receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now(),date:date,time:time,hours:hours,paymentMethod:paymentMethod})
                            }).catch(function(error) {
                                console.error("Error writing document: ", error);
                            });
                        }else{
                            showToast("You don't have enough credits to place this request. Please TOP UP your account!");
                            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''});
                        }
                    }else{
                        db.collection("requests").doc(connectionId).set({sender:viewerToken,fee:(price),receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now(),date:date,time:time,hours:hours,paymentMethod:paymentMethod}).then(function() {
                            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                            showToast("Your request has been send for approval");
                            sendPushNotification(userObj[0].notificationToken,"NEW "+requestType+" REQUEST","You have a new request worth R "+price+" in cash, Click to take action",viewerToken);
                            props.setRequestObject({sender:viewerToken,fee:price,receiver:userToken,requestType:requestType,isDriverRequested:returnArray[2],status:'PENDING',connectionId:connectionId,requestDate:Date.now(),date:date,time:time,hours:hours,paymentMethod:paymentMethod})
                        }).catch(function(error) {
                            console.error("Error writing document: ", error);
                        });
                    }
                })
            }
        })
    }
    const updateFee = (returnArray)=>{
        let newPrices = null;
        confirmDialog("CONFIRM UPDATE","Are you sure you want to update your "+returnArray[1]+" fee to "+returnArray[0]+'c?',"Confirm","Cancel",(cb)=>{
            if(cb){
                if(returnArray[1]=="Drink"){
                    newPrices = {
                        Drink:returnArray[0],Massage:prices.Massage,Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:returnArray[1],MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc,
                        Dinner:prices.Dinner,Partner:prices.Partner,DinnerDesc:prices.DinnerDesc,PartnerDesc:prices.PartnerDesc
                    };
                }else if(returnArray[1]=="Massage"){
                    newPrices = {
                        Drink:prices.Drink,Massage:returnArray[0],Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:returnArray[1],FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc,
                        Dinner:prices.Dinner,Partner:prices.Partner,DinnerDesc:prices.DinnerDesc,PartnerDesc:prices.PartnerDesc
                    };
                }else if(returnArray[1]=="Flirting"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:returnArray[0],Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:returnArray[1],BookingDesc:prices.BookingDesc,
                        Dinner:prices.Dinner,Partner:prices.Partner,DinnerDesc:prices.DinnerDesc,PartnerDesc:prices.PartnerDesc
                    };
                }else if(returnArray[1]=="Booking"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:prices.Flirting,Booking:returnArray[0],phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:returnArray[1],
                        Dinner:prices.Dinner,Partner:prices.Partner,DinnerDesc:prices.DinnerDesc,PartnerDesc:prices.PartnerDesc
                    };
                }else if(returnArray[1]=="Dinner"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc,
                        Dinner:returnArray[0],Partner:prices.Partner,DinnerDesc:returnArray[1],PartnerDesc:prices.PartnerDesc
                    };
                }else if(returnArray[1]=="Partner"){
                    newPrices = {
                        Drink:prices.Drink,Massage:prices.Massage,Flirting:prices.Flirting,Booking:prices.Booking,phoneNumber:userToken,
                        DrinkDesc:prices.DrinkDesc,MassageDesc:prices.MassageDesc,FlirtingDesc:prices.FlirtingDesc,BookingDesc:prices.BookingDesc,
                        Dinner:prices.Dinner,Partner:returnArray[0],DinnerDesc:prices.DinnerDesc,PartnerDesc:returnArray[1]
                    };
                }
                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your service fee, Please wait...'})
                db.collection("prices").doc(userToken).set(newPrices).then(function() {
                    showToast("Your fee updates where applied!");
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    setPrices(newPrices);
                }).catch(function(error) {
                    console.error("Error writing document: ", error);
                });
            }
        })
    }
    const editProfile = (option) =>{
        setModalVisible(true);
        setModalAttr({toOpen:option,headerText:option,values:''})
    }
    const updateSelfie = async (file) =>{
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = file.substring(file.lastIndexOf('/')+1);
        const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your selfie photo, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            storageRef.getDownloadURL().then(downloadURL => {
                db.collection("aboutusers").doc(userToken).update({selfiePhoto:downloadURL}).then(function() {
                    showToast("Your selfie verification photo has been updated!");
                    setAboutUser({...aboutUser,selfiePhoto:downloadURL});
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                }).catch(function(error) {});
            })
        });
    }
    const updateIdPhoto = async (file) =>{
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = file.substring(file.lastIndexOf('/')+1);
        const storageRef = storage.ref().child('photos/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Uploading your ID photo, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            storageRef.getDownloadURL().then(downloadURL => {
                db.collection("aboutusers").doc(userToken).update({idPhoto:downloadURL}).then(function() {
                    showToast("Your ID verification photo has been updated!");
                    setAboutUser({...aboutUser,idPhoto:downloadURL});
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                }).catch(function(error) {});
            })
        });
    }
    const updateAbout = (about)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your about section, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({about:about}).then(function() {
            showToast("Your about section has been updated!");
            setAboutUser({...aboutUser,about:about});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateBirthDay = (birthDay)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your birth day, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({birthDay:birthDay}).then(function() {
            showToast("Your birth day has been updated!");
            setAboutUser({...aboutUser,birthDay:birthDay});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateGender = (gender)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your gender, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({gender:gender}).then(function() {
            showToast("Your gender has been updated!");
            setAboutUser({...aboutUser,gender:gender});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const updateFacebook = (facebookLink)=>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your facebook link, Please wait...'})
        db.collection("aboutusers").doc(userToken).update({facebookLink:facebookLink}).then(function() {
            showToast("Your facebook link has been updated!");
            setAboutUser({...aboutUser,facebookLink:facebookLink});
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {});
    }
    const ageCalculator = (birthDay) =>{
        var birth = new Date(birthDay);
        var check = new Date();
        var milliDay = 1000 * 60 * 60 * 24;
        var ageInDays = (check - birth) / milliDay;
        var ageInYears =  Math.floor(ageInDays / 365 );
        var age =  ageInDays / 365 ;
        return age;
    }
    const getDimensions = (layout)=>{
        const {x, y, width, height} = layout;
        verificationPhotoHolderWidth = width;
    }
    const giveAStar = ()=>{
        const uuid = viewerToken+userToken;
        if(!rated.isMe){
            db.collection("stars").doc(uuid.toString()).set({liker:viewerToken,liked:userToken,uuid:uuid}).then(function() {
                setRated({...rated,stars:rated.stars+1 ,isMe:true});
                showToast("You gave "+userObj[0].fname+' a star!');
                sendPushNotification(userObj[0].notificationToken,"NEW STAR RECEIVED","You just got a star, Could this be what we think it is?",viewerToken);
            }).catch(function(error) {
                console.error("Error writing document: ", error);
            });
        }else{
            db.collection("stars").doc(uuid).delete().then(function() {
                showToast("You removed your star");
                setRated({...rated,stars:rated.stars-1,isMe:false});
            }).catch(function(error) {});
        }
    }
    const requestObject = props.requestObject;
    const selectedRequestMenu = (option)=>{
        if(option===1){
            if (requestObject.paymentMethod=="CREDITS") {
                var text = userObj[0].fname+" would like to meet with you for "+requestObject.hours+" hours on "+requestObject.date+" from "+requestObject.time+" . The proposed reward for this appointment is "+requestObject.fee+"c. What do you think?";
            }else{
                var text = userObj[0].fname+" would like to meet with you for "+requestObject.hours+" hours on "+requestObject.date+" from "+requestObject.time+" . The proposed reward for this appointment is R "+requestObject.fee+" in cash. What do you think?";
            }
            confirmDialog(requestObject.requestType.toUpperCase()+" REQUEST",text,"INTERESTED","NOT NOW",(cb)=>{
                if(cb){
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                    db.collection("requests").doc(requestObj.connectionId).update({status:'INTERESTED'}).then(function() {
                        showToast("Great! Now you can call each other for arrangements if any!");
                        sendPushNotification(userObj[0].notificationToken,"YOU ALMOST THERE","Your "+requestObject.requestType+" request has been accepted and you can now start preparing for the appointment",viewerToken);
                        props.setRequestObject({...props.requestObject,status:'INTERESTED'});
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error removing document: ", error);
                    });
                }
            })
        }else if(option===2){
            if(requestObject.sender==viewerToken){
                confirmDialog("CANCEL YOUR REQUEST","Are you sure you want to cancel your "+requestObject.requestType+" request? A cancellation fee of 25% may apply. Press Terminate to proceed","Terminate","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }else{
                confirmDialog("REJECT REQUEST","Are you sure you want to decline this "+requestObject.requestType+" request? Press Decline to reject","Decline","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }
        }else if(option===5){
            if(requestObject.sender==viewerToken){
                confirmDialog("CONFIRM ARRIVAL","Do you confirm that "+userObj[0].fname+" has arrived and you are within few metres apart?."+requestObject.fee+"c will be deducted from your account by pressing the confirm button","I CONFIRM","No",(cb)=>{
                    if(cb){
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                        const transactionId = viewerToken+Date.now();
                        getUserBalance(viewerToken, (viewerBal)=>{
                            getUserBalance(userToken, (userBal)=>{
                                if (requestObject.paymentMethod=="CREDITS") {
                                    const viewerNewBal = viewerBal - requestObject.fee;
                                    const userNewBal = userBal + requestObject.fee;
                                    db.collection("users").doc(viewerToken).update({balance:viewerNewBal,availability:'BUSY'}).then(function() {
                                        db.collection("users").doc(userToken).update({balance:userNewBal,availability:'BUSY'}).then(function() {
                                            db.collection("requests").doc(requestObject.connectionId).update({status:'COMPLETED'}).then(function() {
                                                db.collection("transactions").doc(transactionId).set({sender:viewerToken,receiver:userToken,amount:requestObject.fee,transactionId:transactionId,date:Date.now(),transactionType:requestObject.requestType,fname:userObj[0].fname,avatar:userObj[0].avatar}).then(function() {
                                                    showToast("Congrats guys! Happy meetup. Stay Safe!");
                                                    sendPushNotification(userObj[0].notificationToken,"APPOINTMENT CONFIRMED",userObj[0].fname+" has confirmed that you guys are now together!",viewerToken);
                                                    props.setRequestObject(null);
                                                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                                }).catch(function(error) {});
                                            }).catch(function(error) {});
                                        }).catch(function(error) {});
                                    }).catch(function(error) {});
                                }else{
                                    const viewerNewBal = viewerBal - requestObject.fee;
                                    var commission = 0.15 * parseFloat(requestObject.fee);
                                    const userNewBal = userBal - commission;
                                    db.collection("users").doc(userToken).update({balance:userNewBal,availability:'BUSY'}).then(function() {
                                        db.collection("requests").doc(requestObject.connectionId).update({status:'COMPLETED'}).then(function() {
                                            db.collection("transactions").doc(transactionId).set({sender:viewerToken,receiver:userToken,amount:requestObject.fee,transactionId:transactionId,date:Date.now(),transactionType:requestObject.requestType,fname:userObj[0].fname,avatar:userObj[0].avatar}).then(function() {
                                                showToast("Congrats guys! Happy meetup. Stay Safe!");
                                                sendPushNotification(userObj[0].notificationToken,"APPOINTMENT CONFIRMED",userObj[0].fname+" has confirmed that you guys are now together!",viewerToken);
                                                props.setRequestObject(null);
                                                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                            }).catch(function(error) {});
                                        }).catch(function(error) {});
                                    }).catch(function(error) {});
                                }
                            });
                        })
                    }
                })
            }else{
                confirmDialog("REQUEST ARRIVAL CONFIRMATION","Notify "+userObj[0].fname+" to approve your arrival","Notify","Cancel",(cb)=>{
                    if(cb){
                        alert("A notification has been sent to "+userObj[0].fname+", Your arrival confirmation will be approved");
                        getUserProfile(viewerToken,(data)=>{
                            sendPushNotification(userObj[0].notificationToken,"ARRIVAL CONFIRMATION REQUEST",data.fname+" would like you to confirm that he/she is now with you. Click to take action",viewerToken);
                        })
                    }
                })
            }
        }else if(option==6){
            props.navigation.navigate("TrackUserScreen",{userObj: userObj[0],requestObject:requestObject})
        }
    }
    const terminateConnection = () =>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Terminating '+requestObject.requestType+' request, Please wait...'})
        db.collection("requests").doc(requestObject.connectionId).delete().then(function() {
            showToast("This request has been successfully terminated");
            props.setRequestObject(null);
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {
            console.error("Error removing document: ", error);
        });
    }
    return(
        <Animatable.View style={GlobalStyles.ProfileFooter} animation="slideInUp" duration={1000} useNativeDriver={true}>
            <View style={styles.ProfileFooterHeader}>
                <View style={{alignContent:'center',alignItems:'center',marginTop:-10}}>
                    <FontAwesome name="ellipsis-h" color="#fff" size={36}></FontAwesome>
                </View>
                {profileOwner?(
                    <View style={styles.statsContainer}>
                    <View style={styles.statsBox}>
                        <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>{showCount}</Text>
                        <Text style={[styles.text, styles.subText,{fontFamily:props.fontFamily}]}>Meetups</Text>
                    </View>
                    <View style={[styles.statsBox, { borderColor: "#e1ece7", borderLeftWidth: 0.5, borderRightWidth: 0.5 }]}>
                        <TouchableOpacity style={{alignItems:'center',alignContent:'center'}} onPress={() => {props.navigation.navigate("CreditScreen",{userObj: userObj[0]})}}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>{userObj[0].balance}</Text>
                            <Text style={[styles.text, styles.subText,{fontFamily:props.fontFamily}]}>Credits</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.statsBox}>
                    <TouchableOpacity onPress={()=>{openMediaFiles({type:'photo',cameraType:'any',fileType:'image',isSelfie:false,userToken:userToken})}} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                        <MaterialIcons name="add-a-photo" size={24} color="#c792f5" alignSelf="center"></MaterialIcons>
                        <Text style={[styles.text, styles.subText,{fontFamily:props.fontFamily}]}>Photos</Text>
                    </TouchableOpacity>
                    </View>
                    </View>
                ):(
                    <View style={styles.statsContainer}>
                        <View style={styles.statsBox}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>{rated.stars}</Text>
                            <Text style={[styles.text, styles.subText,{color:'orange'},{fontFamily:props.fontFamily}]}>Stars</Text>
                        </View>
                        <View style={[styles.statsBox, { borderColor: "#e1ece7", borderLeftWidth: 0.5, borderRightWidth: 0.5 }]}>
                            <Text style={[styles.text, { fontSize: 18,fontWeight:'bold' }]}>4.5</Text>
                            <Text style={[styles.text, styles.subText,{fontFamily:props.fontFamily}]}>Ratings</Text>
                        </View>
                        <View style={styles.statsBox}>
                            <TouchableOpacity onPress={() => {giveAStar()}}>
                                {rated.isMe?(
                                    <MaterialIcons name="star-border" size={36} color="orange" alignSelf="center"></MaterialIcons>
                                ):(
                                    <MaterialIcons name="star-border" size={36} color="gray" alignSelf="center"></MaterialIcons>
                                )}
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            </View>
            <View style={{ marginTop: 5 }}>
                {[requestObject].map((item, i) =>  {
                    if(((item==null) || (item.status=="COMPLETED")) || ((item.status=="PENDING") && (item.sender==viewerToken))){
                        return(
                            <Animatable.View key={i} animation="slideInLeft" duration={1000} useNativeDriver={true}>
                                <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{padding:10,paddingRight:20}}>
                                    <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Drink')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Drink}c</Text>
                                            <FontAwesome name="glass" color="#fff" size={30}></FontAwesome>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Drink</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                            </TouchableOpacity>
                                    </LinearGradient>
                                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Massage')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Massage}c</Text>
                                            <FontAwesome name="bathtub" color="#fff" size={30}></FontAwesome>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Massage</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                        </TouchableOpacity>
                                    </LinearGradient>
                                    <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Dinner')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Dinner}c</Text>
                                            <MaterialIcons name="restaurant-menu" color="#fff" size={30}></MaterialIcons>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Dinner Or</Text>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Lunch</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                            </TouchableOpacity>
                                    </LinearGradient>
                                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Flirting')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Flirting}c</Text>
                                            <FontAwesome name="comments" color="#fff" size={30}></FontAwesome>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Flirting</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                        </TouchableOpacity>
                                    </LinearGradient>
                                    <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Booking')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Booking}c</Text>
                                            <FontAwesome name="heart" color="#fff" size={25}></FontAwesome>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Special</Text>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>Booking</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                        </TouchableOpacity>
                                    </LinearGradient>
                                    <LinearGradient colors={["#92e6f5","#c792f5"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.actionViewBtn]}>
                                        <TouchableOpacity style={{alignContent:'center',alignItems:'center',justifyContent:'center',flex:1}} onPress={()=>actionTaken('Partner')}>
                                            <Text style={GlobalStyles.actionViewText}>{prices.Partner}c</Text>
                                            <FontAwesome name="handshake-o" color="#fff" size={25}></FontAwesome>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>FAKE</Text>
                                            <Text style={[GlobalStyles.actionViewText,{fontFamily:props.fontFamily}]}>PARTNER</Text>
                                            {profileOwner ? (
                                            <MaterialIcons name="filter-tilt-shift" size={15} color="green" alignSelf="center"></MaterialIcons>
                                            ):(<FontAwesome name="heart" color="tomato" size={15}></FontAwesome>)}
                                        </TouchableOpacity>
                                    </LinearGradient>
                                </ScrollView>
                            </Animatable.View>
                        )
                    }else if(item.status=="PENDING"){
                        if(item.sender==userToken){
                            return(
                                <Animatable.View animation="slideInLeft" duration={1000} useNativeDriver={true}>
                                    <Grid style={{height:80}} key={i}>
                                        <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                            <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                                <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{selectedRequestMenu(1)}}>
                                                    <FontAwesome name="check-circle" size={36} color="green" alignSelf="center"></FontAwesome>
                                                </TouchableOpacity>
                                            </LinearGradient>
                                        </Col>
                                        <Col size={0.50} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                            <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.requestTypeViewHolder]}>
                                                <Text style={GlobalStyles.requestTypeView}>{requestObject.requestType}</Text>
                                            </LinearGradient>
                                        </Col>
                                        <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                            <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                                <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{selectedRequestMenu(2)}}>
                                                    <MaterialIcons name="cancel" size={36} color="red" alignSelf="center"></MaterialIcons>
                                                </TouchableOpacity>
                                            </LinearGradient>
                                        </Col>  
                                    </Grid>
                                </Animatable.View>
                            )
                        }
                    }else if(item.status=="INTERESTED"){
                        return(
                            <Animatable.View animation="slideInLeft" duration={1000} useNativeDriver={true}>
                                <Grid style={{height:80}} key={i}>
                                    <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                        <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                            <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{callNumber(userToken)}}>
                                                <MaterialIcons name="phone" size={36} color="green" alignSelf="center"></MaterialIcons>
                                            </TouchableOpacity>
                                        </LinearGradient>
                                    </Col>
                                    <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                        <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                            <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{selectedRequestMenu(6)}}>
                                                <FontAwesome name="map-marker" size={36} color="orange" style={{marginLeft:3}} alignSelf="center"></FontAwesome>
                                            </TouchableOpacity>
                                        </LinearGradient>
                                    </Col>
                                    <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                        <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                            <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{selectedRequestMenu(5)}}>
                                                <FontAwesome name="check-circle" size={36} color="green" alignSelf="center"></FontAwesome>
                                            </TouchableOpacity>
                                        </LinearGradient>
                                    </Col>
                                    <Col size={0.25} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                        <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[GlobalStyles.interestBtnHolder]}>
                                            <TouchableOpacity style={GlobalStyles.interestBtnAction} onPress={()=>{selectedRequestMenu(2)}}>
                                                <MaterialIcons name="cancel" size={36} color="red" alignSelf="center"></MaterialIcons>
                                            </TouchableOpacity>
                                        </LinearGradient>
                                    </Col>
                                </Grid>
                            </Animatable.View>
                        )
                    }
                })}
            </View>
            {photosArray!=null&&(
                <Animatable.View animation="bounceIn" duration={1000} useNativeDriver={true} style={{padding:5 }}>
                    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                    {photosArray!=null ? (
                        photosArray.map((item, i) => (
                            <TouchableOpacity key={i} onPress={()=>{setPhotoBrowserVisible(true)}}>
                                <View style={styles.mediaImageContainer}>
                                    <Animatable.Image animation="zoomInDown" duration={2000} useNativeDriver={true} source={{uri: item.url!=""?item.url:'https://picsum.photos/400/400'}} style={styles.image} resizeMode="cover"></Animatable.Image>
                                </View>
                            </TouchableOpacity>
                        ))
                    ):null}
                    </ScrollView>
                    {(profileOwner && photosArray.length>0) &&(
                        <LinearGradient colors={["#e44528","#d6a8e7","#f3bf4f"]}start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={[styles.mediaCount]}>
                            <TouchableOpacity onPress={()=>{openMediaFiles({type:'photo',cameraType:'any',fileType:'image',isSelfie:false,userToken:userToken})}}>
                                <MaterialIcons name="add-circle" size={30} color="#fff" alignSelf="center"></MaterialIcons>
                            </TouchableOpacity>
                        </LinearGradient>
                    )}
                </Animatable.View>
            )}
            <Modal visible={photoBrowserVisible} transparent={true}>
                <ImageViewer imageUrls={photosArray} enableSwipeDown={true} onSwipeDown={()=>setPhotoBrowserVisible(false)} onSwipeDown={()=>setPhotoBrowserVisible(false)} />
            </Modal>
            <View style={{ padding:5 }}>
                <LinearGradient colors={["#e2f2f5", "#f9d0c7"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{borderRadius:10,}}>
                    <View style={styles.recentItem}>
                        <View style={styles.activityIndicator}>
                            <FontAwesome name="user-circle" color="#c792f5" size={24}></FontAwesome>
                        </View>
                        <View style={{ flex:3,backgroundColor:'#fff',borderRadius:10, }}>
                            <View style={{padding:10,backgroundColor:'#f9f4f7',flex:1,flexDirection:'row',borderTopLeftRadius:10,borderTopRightRadius:10}}>
                                <Text style={[styles.text, { color: "#41444B",flex:3, fontWeight: "bold",fontSize:14,fontFamily:props.fontFamily,color:'#757575' }]}>ABOUT</Text>
                                {profileOwner?(
                                    <TouchableOpacity onPress={()=>editProfile("ABOUT")}>
                                        <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                                    </TouchableOpacity>
                                ):null}
                            </View>
                            <View style={{padding:10}}>
                                <Text style={[styles.text, { color: "#41444B", fontWeight: "300",fontFamily:props.fontFamily }]}>{aboutUser.about}</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>
            </View>
            <View>
                <List>
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon>
                        <Left><FontAwesome name="child" size={30} color="#c792f5" alignSelf="center"></FontAwesome></Left>
                        <Body>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}> AGE</Text>
                        </Body>
                        <Right>
                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{ageCalculator(aboutUser.birthDay).toFixed(0)}  </Text>
                            {profileOwner?(
                                <TouchableOpacity onPress={()=>editProfile("AGE")}>
                                    <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                                </TouchableOpacity>
                            ):null}
                        </Right>
                    </ListItem>
                    <ListItem noBorder style={{borderColor:'#f2eae9',borderBottomWidth:0.4}} icon>
                        <Left><FontAwesome name="mars" size={30} color="#c792f5" alignSelf="center"></FontAwesome></Left>
                        <Body>
                        <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin',fontWeight:'bold'}}>GENDER</Text>
                        </Body>
                        <Right>
                            <Text style={{color:'#2a2828',fontFamily:'sans-serif-thin'}}>{aboutUser.gender}  </Text>
                            {profileOwner?(
                                <TouchableOpacity onPress={()=>editProfile("GENDER")}>
                                    <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                                </TouchableOpacity>
                            ):null}
                        </Right>
                    </ListItem>
                </List>
            </View>
            <Grid style={{marginTop:25 }}>
                <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                    <View style={{overflow: "hidden",width:75,height:75,borderRadius:100,marginTop:10,backgroundColor:'#f2efee'}}>
                        {aboutUser.idPhoto!=""&&(
                            <Image source={{uri: aboutUser.idPhoto}} style={styles.image} resizeMode="cover"/>
                        )}
                    </View>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>ID VERIFICATION</Text>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>PHOTO</Text>
                    {profileOwner?(
                        <TouchableOpacity onPress={()=>{openMediaFiles({type:'idPhoto',cameraType:'any',fileType:'image',isSelfie:false,userToken:userToken})}}>
                            <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                        </TouchableOpacity>
                    ):null}
                </Col>
                <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                    <TouchableOpacity onPress={()=>{if (!aboutUser.facebookLink.includes("uberflirt")) {
                        props.navigation.navigate("WebBrowser",{baseUrl:aboutUser.facebookLink})
                    }}}>
                        <FontAwesome name="facebook" color="#0e75b4" size={70}></FontAwesome>
                    </TouchableOpacity>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>FACEBOOK</Text>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>LINK</Text>
                    {profileOwner?(
                        <TouchableOpacity onPress={()=>editProfile("FACEBOOK LINK")}>
                            <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                        </TouchableOpacity>
                    ):null}
                </Col>    
                <Col style={{justifyContent:'center',alignItems:'center',alignContent:'center'}}>
                    <View style={{overflow: "hidden",width:75,height:75,borderRadius:100,marginTop:10,backgroundColor:'#f2efee'}}>
                        {aboutUser.selfiePhoto!=""&&(
                            <Image source={{uri: aboutUser.selfiePhoto}} style={styles.image} resizeMode="cover"/>
                        )}
                    </View>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>SELFIE VERIFICATION</Text>
                    <Text style={{ color: "#000",fontSize:10,fontFamily:'sans-serif-thin',alignContent:'center',alignItems:'center' }}>PHOTO</Text>
                    {profileOwner?(
                        <TouchableOpacity onPress={()=>{openMediaFiles({type:'selfiePhoto',cameraType:'any',fileType:'image',isSelfie:true,userToken:userToken})}}>
                            <FontAwesome name="edit" color="#c5c3c8" size={24}></FontAwesome>
                        </TouchableOpacity>
                    ):null}
                </Col>           
            </Grid>
            <ModalScreen isVisible={modalVisible} closeModal={closeModal} callback={callback} modalAttr={modalAttr} navigation={props.navigation}/>
        </Animatable.View>
    )
}
function  getUserBalance(user,cb) {
    db.collection("users").where("phoneNumber", "==", user).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data[0].balance);
    });
}
function  getUserProfile(user,cb) {
    db.collection("users").where("phoneNumber", "==", user).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data[0]);
    });
}
const Foreground = props =>{
    const [modalVisible, setModalVisible] = useState(false);
    const [modalAttr, setModalAttr] = useState({toOpen:'FILE BROWSER',headerText:'SELECT FROM',values:''});
    const [users,startCoords,confirmDialog] = useUsers();
    function closeModal() {
        setModalVisible(false);
    }
    const requestObject = props.requestObject;
    async function callback(file) {
        const response = await fetch(file);
        const blob = await response.blob();
        var metadata = {contentType: 'image/png',};
        const filename = userToken+".png";
        const storageRef = storage.ref().child('avatars/'+userToken+'/'+filename);
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating your avatar, Please wait...'})
        await storageRef.put(blob,metadata).then(function(snapshot) {
            props.setAvatar(file);
            if(userObj.length>0){
                storageRef.getDownloadURL().then(downloadURL => {
                    db.collection("users").doc(userToken).update({avatar:downloadURL}).then(function() {
                        showToast("Your avatar has been updated!");
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error writing document: ", error);
                    });
                })
            }else{
                showToast("Could not update your avatar, Please try again later!")
            }
        });
    }
    const selectedRequestMenu = (option)=>{
        if(option===1){
            if (requestObject.paymentMethod=="CREDITS") {
                var text = userObj[0].fname+" would like to meet with you for "+requestObject.hours+" hours on "+requestObject.date+" from "+requestObject.time+" . The proposed reward for this appointment is "+requestObject.fee+"c. What do you think?";
            }else{
                var text = userObj[0].fname+" would like to meet with you for "+requestObject.hours+" hours on "+requestObject.date+" from "+requestObject.time+" . The proposed reward for this appointment is R "+requestObject.fee+" in cash. What do you think?";
            }
            confirmDialog(requestObject.requestType.toUpperCase()+" REQUEST",text,"INTERESTED","NOT NOW",(cb)=>{
                if(cb){
                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                    db.collection("requests").doc(requestObj.connectionId).update({status:'INTERESTED'}).then(function() {
                        showToast("Great! Now you can call each other for arrangements if any!");
                        sendPushNotification(userObj[0].notificationToken,"YOU ALMOST THERE","Your "+requestObject.requestType+" request has been accepted and you can now start preparing for the appointment",viewerToken);
                        props.setRequestObject({...props.requestObject,status:'INTERESTED'});
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                    }).catch(function(error) {
                        console.error("Error removing document: ", error);
                    });
                }
            })
        }else if(option===2){
            if(requestObject.sender==viewerToken){
                confirmDialog("CANCEL YOUR REQUEST","Are you sure you want to cancel your "+requestObject.requestType+" request? A cancellation fee of 25% may apply. Press Terminate to proceed","Terminate","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }else{
                confirmDialog("REJECT REQUEST","Are you sure you want to decline this "+requestObject.requestType+" request? Press Decline to reject","Decline","No",(cb)=>{
                    if(cb){
                        terminateConnection();
                    }
                })
            }
        }else if(option===5){
            if(requestObject.sender==viewerToken){
                confirmDialog("CONFIRM ARRIVAL","Do you confirm that "+userObj[0].fname+" has arrived and you are within few metres apart?."+requestObject.fee+"c will be deducted from your account by pressing the confirm button","I CONFIRM","No",(cb)=>{
                    if(cb){
                        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Updating request status, Please wait...'})
                        const transactionId = viewerToken+Date.now();
                        getUserBalance(viewerToken, (viewerBal)=>{
                            getUserBalance(userToken, (userBal)=>{
                                if (requestObject.paymentMethod=="CREDITS") {
                                    const viewerNewBal = viewerBal - requestObject.fee;
                                    const userNewBal = userBal + requestObject.fee;
                                    db.collection("users").doc(viewerToken).update({balance:viewerNewBal,availability:'BUSY'}).then(function() {
                                        db.collection("users").doc(userToken).update({balance:userNewBal,availability:'BUSY'}).then(function() {
                                            db.collection("requests").doc(requestObject.connectionId).update({status:'COMPLETED'}).then(function() {
                                                db.collection("transactions").doc(transactionId).set({sender:viewerToken,receiver:userToken,amount:requestObject.fee,transactionId:transactionId,date:Date.now(),transactionType:requestObject.requestType,fname:userObj[0].fname,avatar:userObj[0].avatar}).then(function() {
                                                    showToast("Congrats guys! Happy meetup. Stay Safe!");
                                                    sendPushNotification(userObj[0].notificationToken,"APPOINTMENT CONFIRMED",userObj[0].fname+" has confirmed that you guys are now together!",viewerToken);
                                                    props.setRequestObject(null);
                                                    props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                                }).catch(function(error) {});
                                            }).catch(function(error) {});
                                        }).catch(function(error) {});
                                    }).catch(function(error) {});
                                }else{
                                    const viewerNewBal = viewerBal - requestObject.fee;
                                    var commission = 0.15 * parseFloat(requestObject.fee);
                                    const userNewBal = userBal - commission;
                                    db.collection("users").doc(userToken).update({balance:userNewBal,availability:'BUSY'}).then(function() {
                                        db.collection("requests").doc(requestObject.connectionId).update({status:'COMPLETED'}).then(function() {
                                            db.collection("transactions").doc(transactionId).set({sender:viewerToken,receiver:userToken,amount:requestObject.fee,transactionId:transactionId,date:Date.now(),transactionType:requestObject.requestType,fname:userObj[0].fname,avatar:userObj[0].avatar}).then(function() {
                                                showToast("Congrats guys! Happy meetup. Stay Safe!");
                                                sendPushNotification(userObj[0].notificationToken,"APPOINTMENT CONFIRMED",userObj[0].fname+" has confirmed that you guys are now together!",viewerToken);
                                                props.setRequestObject(null);
                                                props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
                                            }).catch(function(error) {});
                                        }).catch(function(error) {});
                                    }).catch(function(error) {});
                                }
                            });
                        })
                    }
                })
            }else{
                confirmDialog("REQUEST ARRIVAL CONFIRMATION","Notify "+userObj[0].fname+" to approve your arrival","Notify","Cancel",(cb)=>{
                    if(cb){
                        alert("A notification has been sent to "+userObj[0].fname+", Your arrival confirmation will be approved");
                        getUserProfile(viewerToken,(data)=>{
                            sendPushNotification(userObj[0].notificationToken,"ARRIVAL CONFIRMATION REQUEST",data.fname+" would like you to confirm that he/she is now with you. Click to take action",viewerToken);
                        })
                    }
                })
            }
        }else if(option==6){
            props.navigation.navigate("TrackUserScreen",{userObj: userObj[0],requestObject:requestObject})
        }else if (option==3) {
            callNumber(userToken);
        }
    }
    const terminateConnection = () =>{
        props.setIsLoading[1]({...props.setIsLoading[0],isLoading:true,text:'Terminating '+requestObject.requestType+' request, Please wait...'})
        db.collection("requests").doc(requestObject.connectionId).delete().then(function() {
            showToast("This request has been successfully terminated");
            props.setRequestObject(null);
            props.setIsLoading[1]({...props.setIsLoading[0],isLoading:false,text:''})
        }).catch(function(error) {
            console.error("Error removing document: ", error);
        });
    }
    const openMediaFiles = (mediaObj)=>{
        props.navigation.navigate("CameraScreen",{mediaObj:mediaObj})
    }
    return(
        <View style={{flex:1}}>
            <View style={{flex:3}}>
            <View style={{padding:10,flexDirection:'row',flex:3}}>
                <TouchableOpacity style={{padding:5,flex:2}} onPress={()=>{props.navigation.goBack()}}>
                    <FontAwesome name="arrow-circle-left" color="#fff" size={36}></FontAwesome>
                </TouchableOpacity>
                </View>
            </View>
            <Animatable.View style={{flex:1,flexDirection:'row'}} animation="slideInLeft" duration={1000} useNativeDriver={true}>
           
            <Grid>
                <Col style={styles.usernameView} size={2}><Text style={{fontWeight:'bold',color:'#fff',textTransform:'uppercase',fontSize:12,fontFamily:props.fontFamily}}>{userObj[0].fname}</Text></Col>
                <Col size={0.5}></Col>
                <Col style={styles.addPhotoContainer} size={1.5}>
                    {profileOwner ? (
                        <TouchableOpacity onPress={()=>{openMediaFiles({type:'avatar',cameraType:'any',fileType:'image',isSelfie:false,userToken:userToken})}}>
                            <Ionicons name="ios-camera" size={50} color="#92e6f5" alignSelf="center"></Ionicons>
                        </TouchableOpacity>
                    ):(
                        <View>
                            {[requestObject].map((item, i) =>  {
                                if((item==null) || (item.status=="COMPLETED")){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <Ionicons name="ios-heart" size={50} color="tomato" alignSelf="center"></Ionicons>
                                        </TouchableOpacity>
                                    )
                                }else if(item.status=="PENDING"){
                                    if(item.sender==viewerToken){
                                        return(
                                            <TouchableOpacity key={i} onPress={()=>{selectedRequestMenu(2)}}>
                                                <FontAwesome name="times-circle" size={50} color="tomato" alignSelf="center"></FontAwesome>
                                            </TouchableOpacity>
                                        )
                                    }else{
                                        return(
                                            <TouchableOpacity key={i} onPress={()=>{}}>
                                                <Menu onSelect={value => {selectedRequestMenu(value)}}>
                                                <MenuTrigger>
                                                    <FontAwesome name="ellipsis-v" size={50} color="#92e6f5" alignSelf="center"></FontAwesome>
                                                </MenuTrigger>
                                                <MenuOptions>
                                                    <MenuOption value={1} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                        <View style={{flex:1}}>
                                                            <FontAwesome name="heart" size={20} color="tomato" alignSelf="center"></FontAwesome>
                                                        </View>
                                                        <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>ACCEPT REQUEST</Text></View>
                                                    </MenuOption>
                                                    <MenuOption value={2} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                        <View style={{flex:1}}>
                                                            <MaterialIcons name="cancel" size={23} color="red" alignSelf="center"></MaterialIcons>
                                                        </View>
                                                        <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>REJECT REQUEST</Text></View>
                                                    </MenuOption>
                                                </MenuOptions>
                                                </Menu>
                                            </TouchableOpacity>
                                        )
                                    }
                                }else if(item.status=="INTERESTED"){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <Menu onSelect={value => {selectedRequestMenu(value)}}>
                                            <MenuTrigger>
                                                <FontAwesome name="ellipsis-v" size={50} color="#92e6f5" alignSelf="center"></FontAwesome>
                                            </MenuTrigger>
                                            <MenuOptions>
                                                <MenuOption value={3} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <MaterialIcons name="phone" size={23} color="green" alignSelf="center"></MaterialIcons>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>MAKE A CALL</Text></View>
                                                </MenuOption>
                                                <MenuOption value={6} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <FontAwesome name="map-marker" size={25} color="orange" style={{marginLeft:3}} alignSelf="center"></FontAwesome>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>TRACK LOCATION</Text></View>
                                                </MenuOption>
                                                <MenuOption value={2} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <MaterialIcons name="cancel" size={23} color="red" alignSelf="center"></MaterialIcons>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>TERMINATE REQUEST</Text></View>
                                                </MenuOption>
                                                <MenuOption value={5} text='' style={{flex:1,flexDirection:'row',borderBottomWidth:0.4,borderColor:'#bbb4b3'}}>
                                                    <View style={{flex:1}}>
                                                        <FontAwesome name="check-circle" size={23} color="green" alignSelf="center"></FontAwesome>
                                                    </View>
                                                    <View style={{flex:3}}><Text style={{fontFamily:'sans-serif-thin',fontSize:13,fontWeight:'bold',color:'#595757'}}>CONFIRM ARRIVAL</Text></View>
                                                </MenuOption>
                                            </MenuOptions>
                                            </Menu>
                                        </TouchableOpacity>
                                    )
                                }else if(item.status=="CONNECTED"){
                                    return(
                                        <TouchableOpacity key={i} onPress={()=>{}}>
                                            <FontAwesome name="phone" size={50} color="green" alignSelf="center"></FontAwesome>
                                        </TouchableOpacity>
                                    )
                                }
                            })}
                        </View>
                        
                    )}
                </Col>
            </Grid>
            </Animatable.View>
            <ModalScreen isVisible={modalVisible}  closeModal={closeModal} callback={callback} modalAttr={modalAttr} navigation={props.navigation}/>
        </View>
    )
}
const callNumber = phone => {
  let phoneNumber = phone;
  if (Platform.OS !== 'android') {
    phoneNumber = `telprompt:${phone}`;
  }else{
    phoneNumber = `tel:${phone}`;
  }
  Linking.canOpenURL(phoneNumber).then(supported => {
    if (!supported) {
      Alert.alert('Phone number is not available');
    } else {
      return Linking.openURL(phoneNumber);
    }
  }).catch(err => console.log(err));
};
async function sendPushNotification(to,title,body,user) {
  if(to!=null || to!=undefined || to!=""){
    const message = {
        to: to,
        sound: 'default',
        title: title,
        body: body,
        data: { user: user },
    };
    await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
        Accept: 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
    });
  }
}
export default ProfileScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFF"
    },
    centeredView:{
        height: '50%',
        marginTop: 'auto',
        backgroundColor:'#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingHorizontal: 20,
        paddingVertical: 30,
        marginLeft: 5,
        borderColor:"#009387",
        borderWidth:10,
        marginRight: 5
    },
    text: {
        color: "#52575D"
    },
    addPhotoContainer:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 50, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomLeftRadius:700,marginRight:5,
        borderTopRightRadius:700,justifyContent:'center',
    },
    usernameView:{
        backgroundColor: 'rgba(0, 0, 0, 0.5)', height: 50, alignContent:"center", alignItems:"center",
        borderTopLeftRadius:50,borderTopRightRadius:50,borderBottomRightRadius:700,
        justifyContent:'center',marginLeft:5,borderTopLeftRadius:700,
    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 11,
        color: "#fff",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    profileImage: {
        position: 'relative',
        width: 200,
        height: 200,
        overflow: 'hidden',
        borderRadius: 100
    },
    profileImg:{
        width: 200, height: 200, borderRadius: 200/ 2
    },
    dm: {
        backgroundColor: "#009387",
        position: "absolute",
        top: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    active: {
        backgroundColor: "#34FFB9",
        position: "absolute",
        bottom: 28,
        left: 10,
        padding: 4,
        height: 20,
        width: 20,
        borderRadius: 10
    },
    add: {
        backgroundColor: "#009387",
        position: "absolute",
        bottom: 0,
        right: 0,
        width: 60,
        height: 60,
        borderRadius: 30,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 16
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: -5,
        //borderColor: '#AEB5BC',
        //borderRadius:5,
        //borderWidth:1,
        padding:5,
    },
    ProfileFooterHeader:{
        backgroundColor:'#e7d8d8',borderTopLeftRadius: 30, borderTopRightRadius: 30,
        shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.9,
          shadowRadius: 5.84,
          elevation: 10,
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 150,
        height: 150,
        borderRadius: 5,
        overflow: "hidden",
        marginHorizontal: 2,
    },
    verificationPhotoHolder:{
        width: verificationPhotoHolderWidth,
        height: verificationPhotoHolderWidth,
        borderRadius: 10,
        overflow: "hidden",
        marginHorizontal: 10,
    },
    mediaCount: {
        position: "absolute",
        top: "50%",
        marginTop: -30,
        marginLeft: 30,
        width: 50,
        height: 50,
        backgroundColor:'teal',
        padding:10,
        borderRadius:100,
        alignItems: "center",
        justifyContent: "center",
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16,
        padding:10,
    },
    activityIndicator: {
        marginLeft:-10,
        padding:5,
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 60,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginBottom:20,
    },
    textSign: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    actionViewBtn1:{
        flex:1,justifyContent:'center',width:50,height:50,borderRadius:100,alignItems:'center',alignContent:'center',
        shadowColor: "#B0B0B0",
          shadowOffset: {
            width: 2,
            height: 2,
          },
          shadowOpacity: 1.5,
          shadowRadius: 1,
          elevation: 2,
    }
});

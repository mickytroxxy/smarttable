import "react-native-gesture-handler";
import "react-native-gesture-handler";
import useUsers from './src/screens/usersHook';
import React, { useEffect, useState } from "react";
import {ToastAndroid,StyleSheet,StatusBar } from "react-native";
import RootStackScreen from "./src/screens/RootStackScreen";
import Home from "./src/screens/Home";
import { AuthContext } from "./src/components/context";
import { socket } from "./src/screens/Socket";
import { db } from "./src/screens/service";
import { View } from "react-native-animatable";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Text,
  ActivityIndicator,
} from "react-native";
function App() {
  const [isLoading, setIsLoading] = React.useState(true);
  const [userToken, setUserToken] = React.useState(null);
  const [users,startCoords] = useUsers();
  const showToast = (message)=>{
    ToastAndroid.show(message, ToastAndroid.SHORT); 
  }
  const authContext = React.useMemo(
    () => ({
      setUserTokenFn: async (phoneNumber) => {
        try {
          await AsyncStorage.setItem("userToken", phoneNumber);
          setUserToken(phoneNumber), setIsLoading(false);
        } catch (e) {
          showToast(e);
        }
      },
      signOut: async () => {
        try {
          await AsyncStorage.removeItem("userToken");
          setUserToken(null), setIsLoading(false);
        } catch (e) {
          showToast(e);
        }
      },
      getUserToken: (cb) => {
        setTimeout( async() => {
          try {
            cb(await AsyncStorage.getItem("userToken"))
          } catch (e) {
            showToast(e);
          }
        }, 500);
      },
    }),
    []
  );
  useEffect(() => {
    const checkLoginStatus = async ()=>{
      try {
        setUserToken(await AsyncStorage.getItem("userToken")),
        setIsLoading(false);
      } catch (e) {
        showToast(e);
      }
    }
    checkLoginStatus();
  }, []);
  if (isLoading) {
    return (
      <View></View>
    );
  }else{
    return (
      <AuthContext.Provider value={authContext}>
        {userToken === null ? <RootStackScreen /> : <Home/>}
        <StatusBar backgroundColor="rgba(0, 0, 0, 0.1)" barStyle="dark-content"/>
      </AuthContext.Provider>
    );
  }
}
export default App;
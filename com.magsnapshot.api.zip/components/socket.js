import socketIOClient from "socket.io-client";
const ENDPOINT = "http://192.168.0.185:3000";
//const ENDPOINT = "http://192.168.1.138:3000";
export const socket = socketIOClient(ENDPOINT);
import { createStackNavigator } from '@react-navigation/stack';
import React, {useState,useContext } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView, Platform,TouchableOpacity,Text,TextInput} from "react-native";
import {MaterialIcons,FontAwesome,Feather,Ionicons } from "@expo/vector-icons";
import { Picker} from 'native-base';
import { UserContext } from '../../../components/context';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { socket } from '../../../components/socket'
import { set } from 'react-native-reanimated';
const RootStack = createStackNavigator();
let headerName;
const AddItemScreen = ({route,navigation}) =>{
    const { header } = route.params;
    headerName=header;
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="AddItemScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"BOOK NEW CLIENT",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const [isLoading,setIsLoading]=React.useState(false);
    const {fontFamilyObj,showToast,searchResults,setSearchResults,confirmDialog,imageUrl,setImageUrl,getNetworkStatus} = useContext(UserContext);
    const [clientDetails,setClientDetails]=React.useState({
        fname:'',lname:'',cellNo:'',regNo:'',make:'',branch:'SELECT BRANCH'
    });
    const handleNewClientDetails=(field,val)=>{
        if(field=="fname"){
            setClientDetails({...clientDetails,fname:val});
        }else if(field=="lname"){
            setClientDetails({...clientDetails,lname:val});
        }else if(field=="cellNo"){
            setClientDetails({...clientDetails,cellNo:val});
        }else if(field=="regNo"){
            setClientDetails({...clientDetails,regNo:val});
        }else if(field=="make"){
            setClientDetails({...clientDetails,make:val});
        }else if(field=="branch"){
            setClientDetails({...clientDetails,branch:val});
        }
    }
    const validateClientDetails = ()=>{
        if(clientDetails.fname.length>2 && clientDetails.lname.length>2 && clientDetails.cellNo.length>9 && clientDetails.regNo.length>4 && clientDetails.make!=""){
            confirmDialog("CONFIRM CLIENT`S DETAILS","Press the confirm button to add the specified user to our client`s list","Confirm","Cancel",(cb)=>{
                if(cb){
                    setIsLoading(true);
                    getNetworkStatus((socket,url)=>{
                        socket.emit("saveClient",clientDetails.fname,clientDetails.lname,clientDetails.cellNo,clientDetails.regNo,clientDetails.make,clientDetails.branch,(result)=>{
                            if(result!=false){
                                showToast("New client has been added successfully!");
                                setIsLoading(false);
                                navigation.goBack();
                            }else{
                                showToast("Could not save "+clientDetails.fname+", Please try again later!");
                            }
                        });
                    })
                }
            })
        }else{
            showToast("Error, You must carefully fill in all fields!");
        }
    }
    React.useEffect(()=>{
        if(searchResults){
            setClientDetails({...clientDetails,regNo:searchResults.regNo,make:searchResults.description});
            setSearchResults(null)
        }
        if(imageUrl){
            setStockDetails({...stockDetails,url:imageUrl});
            setImageUrl(null)   
        }
    },[searchResults,imageUrl])
    return(
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{marginTop:50,padding:10}}>
                    <TouchableOpacity style={{flexDirection:'row'}} onPress={()=>navigation.navigate("BarcodeScanner")}>
                        <Text style={{fontFamily:fontFamilyObj.customBold,marginTop:12}}>SCAN LICENCE DISK</Text>
                        <Ionicons name="scan" size={48} color="#5586cc"></Ionicons>
                    </TouchableOpacity>
                </View>
                <View style={{margin:5,backgroundColor:'#e8e9f5',padding:5,borderRadius:10}}>
                    <View style={{padding:5,backgroundColor:'#fff',borderRadius:10}}>
                        <Grid style={styles.searchInputHolder}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="user" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="CLIENT FIRST NAME" onChangeText={(val)=>handleNewClientDetails('fname',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="users" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="CLIENT LAST NAME" onChangeText={(val)=>handleNewClientDetails('lname',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <FontAwesome name="phone" color="#5586cc" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="CLIENT CELL NUMBER" keyboardType="phone-pad" onChangeText={(val)=>handleNewClientDetails('cellNo',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <FontAwesome name="list" color="#5586cc" size={18} style={{alignSelf:"center"}}></FontAwesome>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="VEHICLE REG NUMBER" value={clientDetails.regNo} onChangeText={(val)=>handleNewClientDetails('regNo',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Feather name="truck" color="#5586cc" size={18} style={{alignSelf:"center"}}></Feather>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <TextInput
                                    placeholder="VEHICLE MAKE" value={clientDetails.make} onChangeText={(val)=>handleNewClientDetails('make',val)}
                                    style={{borderColor:'#fff',fontFamily:fontFamilyObj.customLight,fontSize:12,color:'#757575'}}
                                />
                            </Col>
                        </Grid>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Ionicons name="chevron-down-circle-outline" color="#5586cc" size={20} style={{alignSelf:"center"}}></Ionicons>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Picker selectedValue={clientDetails.branch} style={{color:'#757575',fontSize:13,fontFamily:fontFamilyObj.customLight }} onValueChange={(itemValue, itemIndex) => handleNewClientDetails("branch",itemValue)}>
                                    <Picker.Item label="SELECT BRANCH" value="SELECT BRANCH"/>
                                    <Picker.Item label="MAG SELBY" value="MAG SELBY"/>
                                    <Picker.Item label="MAG LONGMEADOW" value="MAG LONGMEADOW"/>
                                    <Picker.Item label="MAG THE GLEN CUSTOMS" value="MAG THE GLEN CUSTOMS"/>
                                    <Picker.Item label="MAG THE GLEN EASTCLIFF" value="MAG THE GLEN EASTCLIFF"/>
                                </Picker>
                            </Col>
                        </Grid>
                    </View>
                </View>
                <View style={{marginTop:30,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                    {!isLoading?(
                        <TouchableOpacity onPress={validateClientDetails} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                            <FontAwesome size={75} color="green" name="check-circle"></FontAwesome>
                        </TouchableOpacity>
                    ):(
                        <ActivityIndicator size="large" color="#757575"></ActivityIndicator>
                    )}
                </View>
            </ScrollView>
        </View>
    )
};
export default AddItemScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#fff'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5'
    }
});

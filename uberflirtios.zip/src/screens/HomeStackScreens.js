import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import MapViewScreen from './MapViewScreen';
import KinList from  './KinList';
import AddKinScreen from  './AddKin';
import ProfileScreen from  './ProfileScreen';
import Settings from  './Settings';
import CreditScreen from  './CreditScreen';
import WebBrowser from  './WebBrowser';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { DrawerContent } from "../screens/DrawerContent";
//const RootStack = createStackNavigator();
const RootStack = createDrawerNavigator();
const HomeStackScreens = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "#009387",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        drawerContent={props=><DrawerContent {...props} />}>
          <RootStack.Screen
            name="MapViewScreen"
            component={MapViewScreen}
          />
          <RootStack.Screen
            name="KinList"
            component={KinList}
            options={{ title: "Next Of Kin", headerLeft:"" }}
          />
          <RootStack.Screen
            name="AddKinScreen"
            component={AddKinScreen}
            options={{ title: "add", headerLeft:"" }}
          />
          <RootStack.Screen
            name="ProfileScreen"
            component={ProfileScreen}
            unmountOnBlur={true}
            options={{ title: "add", headerLeft:"",unmountOnBlur: true}}
          />
          <RootStack.Screen
            name="Settings"
            component={Settings}
            options={{ title: "Settings", headerLeft:"" }}
          />
          <RootStack.Screen
            name="CreditScreen"
            component={CreditScreen}
            options={{ title: "CreditScreen", headerLeft:"" }}
          />
          <RootStack.Screen
            name="WebBrowser"
            component={WebBrowser}
            options={{ title: "", headerLeft:"",unmountOnBlur: true }}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    );
};
export default HomeStackScreens;
import React,{ useState } from 'react';
import { Text } from "react-native";
import { ToastAndroid,Platform,Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
export const UserContext = React.createContext();
import * as Font from "expo-font";
import socketIOClient from "socket.io-client";
import * as Network from 'expo-network';
import * as Permissions from 'expo-permissions';
import Geolocation from '@react-native-community/geolocation';
let isProcessing = false;
export const UserProvider = (props) =>{
    const [userState,setUserState]=useState({isUserLogged:false,isLoading:true,userDetails:{userId:'',branch:''}})
    const [carObj,setCarObj]=React.useState(null);
    const [searchResults,setSearchResults]=React.useState(null);
    const [carObject,setCarObject] = useState(null);
    const [imageUrl,setImageUrl]=useState(null);
    const [fontFamilyObj,setFontFamily]=React.useState({default:'sans-serif-thin'});
    const [socket,setSocket]=React.useState(socketIOClient("http://192.168.0.185:3000"))
    const [bookingsArray,setBookingsArray] = useState(['Licence Disk','Front Bumper','Bonnet','Right Front Fender','Right Front Door Mirror','Right Front Door','Right Rear Door','Right Rear Fender',
    'Boot','Right Rear Tyre','Left Rear Tyre','Left Rear Fender','Left Rear Door','Left Front Door','Left Front Door Mirror','Left Front Fender','Left Front Headlamp',
    'Right Front Headlamp','Front WindScreen','Roof','Engine','Left Front Tyre','Right Front Tyre','Spare wheel','Inside Boot','Left Front Door Inner Panel',
    'Right Front Door Inner Panel','Left Rear Door Inner Panel','Right Rear Door Inner Panel','Right Front Carpet','Left Front Carpet','Right Rear Carpet',
    'Left Rear Carpet','Left Front Seat','Right Front Seat','Rear Seats','Instrument Cover','Instrument Cluster','Console','Headlining','Radio','Keys']);
    const [lastIndex,setLastIndex]=useState(0);
    let customFonts = {
        'customLight': require('../fonts/MontserratAlternates-Light.otf'),
        'customBold': require('../fonts/MontserratAlternates-Bold.otf'),
    };
    React.useEffect(()=>{
        const loadFontsAsync = async ()=> {
            await Font.loadAsync(customFonts);
            setFontFamily({customLight:'customLight',customBold:'customBold'})
        }
        loadFontsAsync();
        isUserLogged();
    },[]);
    const isUserLogged = async()=>{
        try {
            const userId = await AsyncStorage.getItem("userId")
            if(userId){
                const branch = await AsyncStorage.getItem("branch")
                setUserState({...userState,isLoading:false,isUserLogged:true,userDetails:{userId:userId,branch:branch}}); 
            }else{
                setUserState({...userState,isLoading:false});
            }
        } catch (e) {
            showToast(e);
        }
    }
    const getLastIndex =async()=>{
        try {
            const savedIndex = await AsyncStorage.getItem("lastIndex")
            const Key_Ref = await AsyncStorage.getItem("Key_Ref")
            if(Key_Ref==carObj.Key_Ref){
                if(savedIndex){
                    setLastIndex(parseInt(savedIndex))
                }
            }else{
                setLastIndex(0);
            }
        } catch (e) {
            showToast(e);
        }
    }
    const saveToken =async(userId,branch)=>{
        userId = JSON.stringify(userId);
        await AsyncStorage.setItem("userId", userId);
        await AsyncStorage.setItem("branch", branch);
        setUserState({...userState,isLoading:false,isUserLogged:true,userDetails:{userId:userId,branch:branch}});
    }
    const signOutFn = async () => {
        try {
          await AsyncStorage.removeItem("userId");
          setUserState({...userState,isLoading:false,isUserLogged:false});
        } catch (e) {
          showToast(e);
        }
    }
    const processData = (initialText,errorText,timeout)=>{
        setUserState({...userState,isLoading:true});
        isProcessing=true;
        setTimeout(()=>{
            if(isProcessing){
                showToast(errorText);
                stopProcess();
            }
        },timeout)
    }
    const stopProcess = ()=>{
        isProcessing=false;
        setUserState({...userState,isLoading:false});
    }
    const changeLastIndex = async(currentIndex)=>{
        const newIndex=currentIndex + 1;
        setLastIndex(newIndex);
        await AsyncStorage.setItem("lastIndex", newIndex.toString());
        await AsyncStorage.setItem("Key_Ref", carObj.Key_Ref.toString());
    }
    const getNetworkStatus = async(cb)=>{
        try {
            const state = await Network.getNetworkStateAsync()
            if(state.type=="CELLULAR"){
                cb(socketIOClient("http://196.61.18.205:3000"),"http://196.61.18.205:3000");
            }else{
                cb(socketIOClient("http://192.168.0.185:3000"),"http://192.168.0.185:3000");
            }
        } catch (error) {
            showToast(error)
        }
    }
    return(
        <UserContext.Provider value={{userState,getCurrentLocation,getLastIndex,getNetworkStatus,bookingsArray,confirmDialog,setSearchResults,searchResults,stopProcess,changeLastIndex,signOutFn,setUserState,showToast,setCarObj,fontFamilyObj,carObject,setCarObject,carObj,saveToken,processData,lastIndex,setLastIndex,imageUrl,setImageUrl}}>
            {props.children}
        </UserContext.Provider>
    )
}
const showToast = (message)=>{
    if (Platform.OS == 'android') {
        ToastAndroid.show(message, ToastAndroid.SHORT); 
    }else{
        alert(message);
    }
}
function confirmDialog(confirmHeader,ConfirmText,Btn1,Btn2,cb) {
    if (Platform.OS == 'android') {
        Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
    }else{
        setTimeout(() => {
            Alert.alert(confirmHeader,ConfirmText,[{text: Btn2, onPress: () => {cb(false)}},{ text: Btn1, onPress: () => {cb(true)} }],{ cancelable: false });
        }, 1000);
    }
}
const getCurrentLocation =(cb)=>{
    if(askPermissionsAsync()){
        Geolocation.getCurrentPosition(position => {
            const { latitude, longitude } = position.coords;
            cb(latitude,longitude);
        },error => {
            showToast(error.message)
            const latitude= -26.2163;
            const longitude=28.0369;
            cb(latitude,longitude);
        },{ 
            enableHighAccuracy: true, timeout: 30000, maximumAge: 10000 }
        );
    }else{
        showToast("You did not grant us permission to get your current location");
        cb(latitude,longitude);
    }
}
const askPermissionsAsync = async () => {
    const { status: location } = await Permissions.askAsync(Permissions.LOCATION);
    if (location !== "granted") {
        return false;
    }else{
        return true;
    }
};
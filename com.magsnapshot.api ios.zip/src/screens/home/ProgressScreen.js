import { createStackNavigator } from '@react-navigation/stack';
import React, {useState,useContext } from "react";
import { StyleSheet, View, Dimensions ,ActivityIndicator,ScrollView, Platform,TouchableOpacity,Text,TextInput} from "react-native";
import {MaterialIcons,FontAwesome,Feather,Ionicons,FontAwesome5 } from "@expo/vector-icons";
import { Picker} from 'native-base';
import { UserContext } from '../../../components/context';
import { Col, Row, Grid } from 'react-native-easy-grid';
import { socket } from '../../../components/socket'
import { set } from 'react-native-reanimated';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';
const RootStack = createStackNavigator();
const ProgressScreen = ({route,navigation}) =>{
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="AddItemScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"CHECK YOUR PROGRESS",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = ({navigation}) =>{
    const {fontFamilyObj,getNetworkStatus,userState} = useContext(UserContext);
    const [show, setShow] = useState({isVisible:false,type:'fromDate'});
    const [fromDate, setFromDate] = useState(moment(new Date(Date.now())).format("YYYY-MM-DD"));
    const [toDate, setToDate] = useState(moment(new Date(Date.now())).format("YYYY-MM-DD"));
    const [progressResult,setProgressResult]=useState([]);
    const [isLoading,setIsLoading]=useState(false);
    const showDatepicker = (type) => {
        setShow({...show,isVisible:true,type:type});
    };
    const onChange = (event, selectedDate) => {
        setShow({...show,isVisible:false});
        if(selectedDate){
            if(show.type=="fromDate"){
                setFromDate(moment(selectedDate).format("YYYY-MM-DD"))
            }else{
                setToDate(moment(selectedDate).format("YYYY-MM-DD"))
            }
        }
    };
    const handleProgress =()=>{
        setIsLoading(true);
        getNetworkStatus(socket=>{
            socket.emit("getProgress",fromDate,toDate,userState.userDetails.userId,(result)=>{
                setIsLoading(false);
                setProgressResult(result);
            });
        })
    }
    React.useEffect(()=>{
    },[])
    return(
        <View style={styles.container}>
            <View style={{flex:3.5}}>
                <View style={{margin:5,backgroundColor:'#e8e9f5',padding:5,borderRadius:10}}>
                    <View style={{padding:5,backgroundColor:'#fff',borderRadius:10,height:60}}>
                        <TouchableOpacity onPress={()=>showDatepicker("fromDate")} style={{height:50}}>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Ionicons name="md-timer" color="#5586cc" size={20} style={{alignSelf:"center"}}></Ionicons>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>FROM DATE</Text>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>{fromDate}</Text>
                            </Col>
                        </Grid>
                        </TouchableOpacity>
                    </View>
                    <View style={{padding:5,backgroundColor:'#fff',borderRadius:10,height:60}}>
                        <TouchableOpacity onPress={()=>showDatepicker("toDate")} style={{height:50}}>
                        <Grid style={[styles.searchInputHolder,{marginTop:5}]}>
                            <Col size={0.15} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Ionicons name="md-timer" color="#5586cc" size={20} style={{alignSelf:"center"}}></Ionicons>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>TO DATE</Text>
                            </Col>
                            <Col style={{justifyContent:'center'}}>
                                <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:11}}>{toDate}</Text>
                            </Col>
                        </Grid>
                        </TouchableOpacity>
                    </View>
                </View>
                {progressResult.length>0&&(
                    <View style={{margin:5}}>
                        <View style={{height:40}}>
                            <Grid style={{backgroundColor:"#5586cc",borderRadius:10,justifyContent:'center',padding:5}}>
                                <Col size={0.6} style={{justifyContent:'center'}}><Text style={{fontFamily:fontFamilyObj.customLight,fontSize:10,color:'#fff'}}>TYPE</Text></Col>
                                <Col size={0.20} style={{justifyContent:'center'}}>
                                    <FontAwesome5 name="camera" size={20} color="#fff"></FontAwesome5>
                                </Col>
                                <Col size={0.20} style={{justifyContent:'center'}}>
                                    <FontAwesome5 name="car" size={20} color="#fff"></FontAwesome5>
                                </Col>
                            </Grid>
                        </View>
                        {progressResult.map((item,i)=>(
                            <View style={{height:30,padding:5}} key={i}>
                                <Grid>
                                    <Col size={0.6}><Text style={{fontFamily:fontFamilyObj.customLight,fontSize:10}}>{item.category}</Text></Col>
                                    <Col size={0.20}>
                                        <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:10}}>{item.photos}</Text>
                                    </Col>
                                    <Col size={0.20}>
                                        <Text style={{fontFamily:fontFamilyObj.customLight,fontSize:10}}>{item.cars}</Text>
                                    </Col>
                                </Grid>
                            </View>
                        ))}
                    </View>
                )}
                <View>
                    {show.isVisible && (
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={new Date(Date.now())}
                            mode="date"
                            is24Hour={true}
                            display="default"
                            onChange={onChange}
                        />
                    )}
                </View>
            </View>
            <View style={{flex:0.5,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                {!isLoading?(
                    <TouchableOpacity onPress={handleProgress} style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                        <FontAwesome name="check-circle-o" color="green" size={50}></FontAwesome>
                    </TouchableOpacity>
                ):(
                    <ActivityIndicator size="large" color="#757575"></ActivityIndicator>
                )}
            </View>
        </View>
    )
};
export default ProgressScreen;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#fff'
    },
    searchInputHolder:{
        height:40,
        borderRadius:10,
        flexDirection:'row',
        borderWidth:0.5,
        borderColor:'#a8a6a5'
    }
});

import 'react-native-gesture-handler';
import 'react-native-gesture-handler';
import React,{useContext} from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Platform, Text, View, ActivityIndicator, TextInput, TouchableOpacity, Image, Dimensions, ToastAndroid } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {MaterialIcons,FontAwesome,Feather} from 'react-native-vector-icons';
import * as Animatable from 'react-native-animatable';
import { UserContext } from '../../../components/context'
import * as Font from "expo-font";
const {height} = Dimensions.get("screen");
const {width} = Dimensions.get("screen");
const Stack = createStackNavigator();

const LoginScreen = ({navigation}) =>{
    const {userState,setUserState,showToast,saveToken,processData,stopProcess,getNetworkStatus} = useContext(UserContext);
    const [fontsLoaded,setFontsLoaded]=React.useState(false);
    const [data,setData]=React.useState({
        branch: '',password:'',check_textInputChange:false,secureTextEntry:true
    })
    let customFonts = {
        'MontserratAlternates-Light': require('..//../../fonts/MontserratAlternates-Light.otf'),
    };
    const loadFontsAsync = async ()=> {
        await Font.loadAsync(customFonts);
        setFontsLoaded(true);
    }
    let fontFamily = 'sans-serif-thin';
    if(fontsLoaded){
        fontFamily = 'MontserratAlternates-Light';
    }
    const textInputChange = (val)=>{
        if(val.length!=0){
            setData({
                ...data,
                branch:val,
                check_textInputChange:true
            })
        }else{
            setData({
                ...data,
                branch:val,
                check_textInputChange:false
            })
        }
    }
    const handlePasswordChange = (val)=>{
        setData({
            ...data,
            password:val
        })
    }
    const updateSecureTextEntry = ()=>{
        setData({
            ...data,
            secureTextEntry: !data.secureTextEntry,
        })
    }
    const Login = (branch,password)=>{
        if(branch.length>5 && password!=""){
            processData("","Opps, we could not log you in, Is your internet connection stable?",10000)
            getNetworkStatus((socket)=>{
                socket.emit("login",branch,password,(result)=>{
                    if(result!=false){
                        saveToken(result,branch); 
                    }else{
                        showToast("Invalid login credentials!");
                        setUserState({...userState,isLoading:false});
                    }
                    stopProcess();
                })
            })
        }else{
            alert("Invalid login credentials!")
        }
    }
    React.useEffect(()=>{
        loadFontsAsync();
        //alert(socket)
    },[])
    if(userState.isLoading){
        return(
            <View style={{alignItems:'center',alignContent:'center',justifyContent:'center',flex:1}}>
                <ActivityIndicator color="gray" size="large"></ActivityIndicator>
            </View>
        )
    }else{
        return(            
            <View style={styles.container}>
                <View style={{flex:2,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                    <Feather name="camera" color="#5586cc" size={200}></Feather>
                </View>
                <View style={styles.loginFooter}>
                    <View style={styles.loginFooterHeader}>
                        <Text style={{fontFamily:fontFamily,color:'#fff',fontWeight:'500'}}>LOGIN BELOW</Text>
                    </View>
                    <LinearGradient colors={["#fff","#fff","#dbdefa"]}start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={{flex:1}}>
                        <View style={{padding:20}}>
                            <Text style={[styles.text_footer,{fontFamily:fontFamily}]}>BRANCH CODE</Text>
                            <View style={styles.action}>
                                <Feather name="key" color="#009387" size={20}></Feather>
                                <TextInput style={[styles.textInput,{fontFamily:fontFamily}]} placeholder="Enter your branch code" autoCapitalize='none' onChangeText={(val)=>textInputChange(val)}></TextInput>
                                {data.check_textInputChange? <Animatable.View animation="bounceIn"><Feather name="check-circle" color="green" size={20}></Feather></Animatable.View> : null}
                            </View>
                            <Text style={[styles.text_footer],{marginTop:35,color: '#05375a',fontSize: 18,fontFamily:fontFamily}}>PASSWORD</Text>
                            <View style={styles.action}>
                                <Feather name="lock" color="#009387" size={20}></Feather>
                                <TextInput style={[styles.textInput,{fontFamily:fontFamily}]} placeholder="Enter your password" autoCapitalize='none' secureTextEntry={data.secureTextEntry?true:false} onChangeText={(val)=>handlePasswordChange(val)}></TextInput>
                                <TouchableOpacity onPress={()=>updateSecureTextEntry()}>
                                    {data.secureTextEntry? <Feather name="eye-off" color="grey" size={20}></Feather>:<Feather name="eye" color="grey" size={20}></Feather>}
                                </TouchableOpacity>
                            </View>
                            <View style={styles.button}>
                                <TouchableOpacity onPress={()=>{Login(data.branch,data.password)}}>
                                    <FontAwesome name="check-circle" color="green" size={75}></FontAwesome>
                                </TouchableOpacity>  
                            </View>
                        </View>
                    </LinearGradient>
                </View>
            </View>
        )
    }
};
export default LoginScreen;
const styles = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignContent:'center',
        alignItems:'center',
        flex:1,
        backgroundColor:'#e8e9f5'
    },
    loginFooter: {
        flex: 2,
        backgroundColor: "#fff",
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        shadowColor: "#B0B0B0",
        elevation: 5,
        width:'96%',
        alignSelf:'center',
        paddingLeft:5,paddingRight:5,paddingTop:5,
    },
    loginFooterHeader:{
        height:50,
        backgroundColor:'#5586cc',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        alignItems:'center',alignContent:'center',
        justifyContent:'center'
    },
    text_header: {
        color: '#009387',
        fontWeight: 'bold',
        fontSize: 30
    },
    text_footer: {
        color: '#05375a',
        fontSize: 18
    },
    action: {
        flexDirection: 'row',
        marginTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#f2f2f2',
        paddingBottom: 5
    },
    actionError: {
        flexDirection: 'row',
        marginTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#FF0000',
        paddingBottom: 5
    },
    textInput: {
        flex: 1,
        marginTop: Platform.OS === 'ios' ? 0 : -8,
        paddingLeft: 10,
        color: '#05375a',
    },
    errorMsg: {
        color: '#FF0000',
        fontSize: 14,
    },
    button: {
        alignItems: 'center',
        marginTop: 50
    },
    signIn: {
        width: Dimensions.get("screen").width - 20,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 15
    },
    signUp: {
        width: Dimensions.get("screen").width - 20,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 15,
    },
    textSign: {
        fontSize: 18,
    }
});
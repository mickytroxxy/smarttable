import React,{useContext,useState} from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet, Text, View, TouchableOpacity, Dimensions } from 'react-native';
import {FontAwesome,Feather} from 'react-native-vector-icons';
import { UserContext } from '../../../components/context'
import { socket } from '../../../components/socket';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import { Grid,Col } from 'react-native-easy-grid';
import { Picker} from 'native-base';
const RootStack = createStackNavigator();
let fontFamily=null;
const SecurityScreen = ({route,navigation}) =>{
    return(
        <RootStack.Navigator screenOptions={{headerStyle: {elevation: 1,shadowOpacity: 0,backgroundColor: "#fff",borderBottomWidth: 0},headerTintColor: "#fff",headerTitleStyle: { fontWeight: "bold" }}}>
        <RootStack.Screen name="AddItemScreen" component={PageContent} options={{
            headerLeft: () => (
                <Feather.Button backgroundColor="#fff" name="arrow-left" size={36} color="#757575" onPress={()=>{navigation.goBack()}}></Feather.Button>
            ), 
            title:"SECURITY CHECKLIST",
            headerTintColor: '#757575',
            headerTitleStyle: {
                fontWeight: '900',
                fontSize:16,
            },
        }}/>
        </RootStack.Navigator>
    )
};
const PageContent = () =>{
    const {fontFamilyObj,carObj,showToast} = useContext(UserContext);
    fontFamily=fontFamilyObj;
    const [tyres,setTyres]=useState([
        {pos:'R/F',make:'',status:'SELECT'},{pos:'L/F',make:'',status:'SELECT'},
        {pos:'R/R',make:'',status:'SELECT'},{pos:'L/R',make:'',status:'SELECT'}
    ]);
    const [spareWheel,setSpareWheel]=useState({type:'SELECT',make:'',status:'SELECT'});
    const [mag,setMag]=useState([
        {pos:'R/F',desc:'SELECT',scratched:'SELECT'},{pos:'L/F',desc:'SELECT',scratched:'SELECT'},
        {pos:'R/R',desc:'SELECT',scratched:'SELECT'},{pos:'L/R',desc:'SELECT',scratched:'SELECT'}
    ]);
    const handleTyres=(item,attributes,i)=>{
        setTyres([
            ...tyres.slice(0, i),
            Object.assign({}, item, attributes),
            ...tyres.slice(i + 1)
        ]);
    }
    React.useEffect(()=>{
       
    },[])
    return(
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false} style={{padding:5}}>
                <View style={{borderRadius:5,backgroundColor:'#f2f5f9',paddingBottom:10}}>
                    <View style={[{backgroundColor:'#e3e6ea'},styles.cardHeader]}>
                        <Text style={{fontFamily:fontFamilyObj.customBold}}>TYRES</Text>
                    </View>
                    <View style={{height:20,borderBottomWidth:1,borderBottomColor:'#e3e6ea'}}>
                        <Grid >
                            <Col size={0.28} style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>POS</Text></Col>
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>MAKE</Text></Col>
                            <Col style={{alignItems:'center'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>STATUS</Text></Col>
                        </Grid>
                    </View>
                    {tyres.map((item,i)=>(
                        <View style={styles.cardRows} key={i}>
                            <Grid style={{justifyContent:'center'}}>
                                <Col size={0.28} style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}><Text style={{fontFamily:fontFamily.customLight,fontSize:11,color:'#757575'}}>{item.pos}</Text></Col>
                                <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}>
                                    <TextInput style={{width:'98%',height:40,fontSize:11,fontFamily:fontFamily.customLight}} placeholder="Make" onChangeText={(val)=>setTyres([...tyres.slice(0, i),Object.assign({}, item, {make:val}),...tyres.slice(i + 1)])}></TextInput>
                                </Col>
                                <Col style={{alignItems:'center',justifyContent:'center'}}>
                                    <Picker selectedValue={item.status} style={{width:'100%',color:'#757575'}} onValueChange={(val, i) => handleTyres(item,{status:val},i)}>
                                        <Picker.Item label="SELECT" value="SELECT"/>
                                        <Picker.Item label="GOOD" value="GOOD"/>
                                        <Picker.Item label="FAIR" value="FAIR"/>
                                        <Picker.Item label="WORN" value="WORN"/>
                                    </Picker>
                                </Col>
                            </Grid>
                        </View>
                    ))}
                </View>

                <View style={{borderRadius:5,backgroundColor:'#f2f5f9',paddingBottom:10,marginTop:5}}>
                    <View style={[{backgroundColor:'#e3e6ea'},styles.cardHeader]}>
                        <Text style={{fontFamily:fontFamilyObj.customBold}}>SPARE WHEEL</Text>
                    </View>
                    <View style={{height:20,borderBottomWidth:1,borderBottomColor:'#e3e6ea'}}>
                        <Grid >
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>TYPE</Text></Col>
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>MAKE</Text></Col>
                            <Col style={{alignItems:'center'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>STATUS</Text></Col>
                        </Grid>
                    </View>
                    <View style={styles.cardRows}>
                        <Grid style={{justifyContent:'center'}}>
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}>
                                <Picker selectedValue={spareWheel.type} style={{width:'100%',color:'#757575'}} onValueChange={(val, i) => setSpareWheel({...spareWheel,type:val})}>
                                    <Picker.Item label="SELECT" value="SELECT"/>
                                    <Picker.Item label="MARIE BISCUIT" value="MARIE BISCUIT"/>
                                    <Picker.Item label="STEEL RIM" value="STEEL RIM"/>
                                    <Picker.Item label="MAG RIM" value="MAG RIM"/>
                                    <Picker.Item label="HUB CAP" value="HUB CAP"/>
                                    <Picker.Item label="NONE" value="NONE"/>
                                </Picker>
                            </Col>
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}>
                                <TextInput style={{width:'98%',height:40,fontSize:11,fontFamily:fontFamily.customLight}} placeholder="Make" onChangeText={(val)=>setSpareWheel({...spareWheel,make:val})}></TextInput>
                            </Col>
                            <Col style={{alignItems:'center',justifyContent:'center'}}>
                                <Picker selectedValue={spareWheel.status} style={{width:'100%',color:'#757575'}} onValueChange={(val, i) => setSpareWheel({...spareWheel,status:val})}>
                                    <Picker.Item label="SELECT" value="SELECT"/>
                                    <Picker.Item label="GOOD" value="GOOD"/>
                                    <Picker.Item label="FAIR" value="FAIR"/>
                                    <Picker.Item label="WORN" value="WORN"/>
                                </Picker>
                            </Col>
                        </Grid>
                    </View>
                </View>
                
                <View style={{borderRadius:5,backgroundColor:'#f2f5f9',paddingBottom:10,marginTop:5}}>
                    <View style={[{backgroundColor:'#e3e6ea'},styles.cardHeader]}>
                        <Text style={{fontFamily:fontFamilyObj.customBold}}>MAG</Text>
                    </View>
                    <View style={{height:20,borderBottomWidth:1,borderBottomColor:'#e3e6ea'}}>
                        <Grid >
                            <Col size={0.28} style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>POS</Text></Col>
                            <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>DESC</Text></Col>
                            <Col style={{alignItems:'center'}}><Text style={{fontFamily:fontFamilyObj.customBold,fontSize:11,color:'#757575'}}>SCRATCHED</Text></Col>
                        </Grid>
                    </View>
                    {mag.map((item,i)=>(
                        <View style={styles.cardRows} key={i}>
                            <Grid style={{justifyContent:'center'}}>
                                <Col size={0.28} style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}><Text style={{fontFamily:fontFamily.customLight,fontSize:11,color:'#757575'}}>{item.pos}</Text></Col>
                                <Col style={{alignItems:'center',borderRightWidth:1,borderRightColor:'#e3e6ea',justifyContent:'center'}}>
                                    <Picker selectedValue={item.desc} style={{width:'100%',color:'#757575'}} onValueChange={(val, i) => setMag([...mag.slice(0, i),Object.assign({}, item, {desc:val}),...mag.slice(i + 1)])}>
                                        <Picker.Item label="SELECT" value="SELECT"/>
                                        <Picker.Item label="MAG" value="MAG"/>
                                        <Picker.Item label="STEEL" value="STEEL"/>
                                    </Picker>
                                </Col>
                                <Col style={{alignItems:'center',justifyContent:'center'}}>
                                    <Picker selectedValue={item.scratched} style={{width:'100%',color:'#757575'}} onValueChange={(val, i) => setMag([...mag.slice(0, i),Object.assign({}, item, {scratched:val}),...mag.slice(i + 1)])}>
                                        <Picker.Item label="SELECT" value="SELECT"/>
                                        <Picker.Item label="GOOD" value="GOOD"/>
                                        <Picker.Item label="SCRATCHED" value="SCRATCHED"/>
                                        <Picker.Item label="DAMAGED" value="DAMAGED"/>
                                    </Picker>
                                </Col>
                            </Grid>
                        </View>
                    ))}
                </View>
            </ScrollView>
        </View>
    )
};
export default SecurityScreen;
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#fff'
    },
    cardHeader:{
        elevation:1,height:40,justifyContent:'center',padding:3,borderTopLeftRadius:5,borderTopRightRadius:5
    },
    cardRows:{
        height:40,borderBottomWidth:1,borderBottomColor:'#e3e6ea',
        justifyContent:'center',backgroundColor:'#fff',marginLeft:2,marginRight:2
    },
    center:{
        alignContent:'center',alignItems:'center',justifyContent:'center'
    },
    carDetails:{
        width:'98%',
        alignSelf:'center',
        backgroundColor:'#fff',
        flex:1.5,
        borderRadius:20,
        marginTop:35,
    },
    performAction:{
        width:'98%',
        alignSelf:'center',
        flex:2.5,
    },
    cardBtn:{
        justifyContent:'center',
        alignItems:'center',
        alignContent:'center',
        height:100,
        width:'94%',
        borderRadius:20
    },
    galleryOptionFooter: {
        flex: 1,
        backgroundColor: "#fff",
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        //paddingVertical: 10,
        //paddingHorizontal: 5,
        shadowColor: "#B0B0B0",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        zIndex:100,
    },
});
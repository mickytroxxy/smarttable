import { db } from '../screens/service';
let requestNum = 0;
export const getRequests = async (userToken)=>{
  if(userToken){
    requestNum=0;
    await db.collection("requests").where("sender", "==", userToken).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        requestNum = requestNum + data.length;
        getWhereIreceived();
    });
    function getWhereIreceived() {
        db.collection("requests").where("receiver", "==", userToken).get().then(querySnapshot => {
        const data = querySnapshot.docs.map(doc => doc.data());
        requestNum = requestNum + data.length;
            return requestNum;
        });
    }
  }
}
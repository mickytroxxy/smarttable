import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet, Text, View, SafeAreaView, Button, TextInput, TouchableOpacity,Image } from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import HomeScreen from  './Home';
import CarActionsScreen from  './CarActions';
import CameraScreen from  './Camera';
import BarcodeScanner from  './BarcodeScanner';
import BookingPhotos from  './BookingPhotos';
import AddItemScreen from  './AddItemScreen';
import ProgressScreen from  './ProgressScreen';
import SecurityScreen from  './SecurityScreen';
import PreviewScreen from  './PreviewScreen';
import PDFScannerScreen from  './PDFScanner';
import AddStockScreen from  './AddStockScreen';
import AddPaintScreen from  './AddPaintScreen';
import TaskScreen from  './TaskScreen';
import QualityControlScreen from  './QualityControl';
const RootStack = createDrawerNavigator();
const HomeStackScreens = ({navigation}) => {
    return (
      <NavigationContainer>
        <RootStack.Navigator
          screenOptions={{
            headerStyle: {
              elevation: 0,
              shadowOpacity: 0,
              backgroundColor: "none",
              borderBottomWidth: 0
            },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" }
          }}
        >
          <RootStack.Screen
            name="HomeScreen"
            component={HomeScreen}
            options={{
              //headerLeft: () => (<View style={{paddingLeft:10}}><Image source={require("../../../assets/ubertext.png")} style={{height:50,width:120}} resizeMode="center"></Image></View>),
              title:"",
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <RootStack.Screen
            name="CarActionsScreen"
            component={CarActionsScreen}
            options={{
              title: 'WHAT WOULD YOU LIKE TO DO?',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <RootStack.Screen
            name="CameraScreen"
            component={CameraScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="BarcodeScanner"
            component={BarcodeScanner}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="BookingPhotos"
            component={BookingPhotos}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="AddItemScreen"
            component={AddItemScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              //unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="AddStockScreen"
            component={AddStockScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              //unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="AddPaintScreen"
            component={AddPaintScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              //unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="ProgressScreen"
            component={ProgressScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              //unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="SecurityScreen"
            component={SecurityScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="PreviewScreen"
            component={PreviewScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              //unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="PDFScannerScreen"
            component={PDFScannerScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              unmountOnBlur: true
            }}
          />
          <RootStack.Screen
            name="TaskScreen"
            component={TaskScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <RootStack.Screen
            name="QualityControlScreen"
            component={QualityControlScreen}
            options={{
              title: '',
              headerStyle: {
                backgroundColor: 'transparent',
                elevation: 0,
                shadowOpacity: 0,
              },
              headerTintColor: '#009387',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
        </RootStack.Navigator>
      
      </NavigationContainer>
    );
};
export default HomeStackScreens;
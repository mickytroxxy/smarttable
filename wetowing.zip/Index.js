import React, { useEffect, useState } from "react";
//import * as React from "react";
import {
  View,
  Text,
  Button,
  Alert,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { AuthContext } from "../components/context";
import Icon from "react-native-vector-icons/Ionicons";
import MapView, { Marker } from "react-native-maps";
import { Location, Permissions } from "expo";
import { HelperText } from "react-native-paper";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { LinearGradient } from "expo-linear-gradient";
import { GlobalStyles } from "../styles/Global";
import { StatusBar } from "expo-status-bar";
import { socket } from "../screens/Socket";
import AsyncStorage from "@react-native-async-storage/async-storage";
function HomeScreen() {
  const { signOut, getUserToken } = React.useContext(AuthContext);
  const [location, setLocation] = React.useState({
    currentLongitude: 0,
    currentLatitude: 0,
    latitudeDelta: 10,
    longitudeDelta: 10
  });
  const [isLoading, setIsLoading] = React.useState({
    isLoadingStatus: false,
    message: ""
  });
  const [userToken, setUserToken] = React.useState(null);
  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      position => {
        setLocation({
          ...location,
          currentLongitude: position.coords.longitude,
          currentLatitude: position.coords.latitude
        });
      },
      error => alert(error.message),
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 1000
      }
    );
  }, []);
  const confirmDialog = () =>
    Alert.alert(
      "CONFIRM LOGOUT",
      "You will be asked to provide your login credentials the next time you try to access this portal?",
      [
        {
          text: "Cancel"
        },
        {
          text: "Logout",
          onPress: () => {
            signOut();
          }
        }
      ],
      { cancelable: false }
    );
  const sendMyLocation = async () => {
    Alert.alert(
      "SEND MY LOCATION",
      "Please confirm this action by pressing confirm button and our towing drivers will be with you soon!",
      [
        {
          text: "Cancel"
        },
        {
          text: "Confirm",
          onPress: () => {
            setIsLoading({
              ...isLoading,
              isLoadingStatus: true,
              message: "Sending your location, Please wait..."
            });
            socket.emit(
              "sendMyLocation",
              getUserToken(),
              location.currentLatitude,
              location.currentLongitude,
              response => {
                setIsLoading({
                  ...isLoading,
                  isLoadingStatus: false,
                  message: ""
                });
                alert(response);
              }
            );
          }
        }
      ],
      { cancelable: false }
    );
  };
  HomeScreen.confirmDialog = confirmDialog;
  if (!isLoading.isLoadingStatus) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <TouchableOpacity
          style={GlobalStyles.sendToFront}
          onPress={() => {
            sendMyLocation();
          }}
        >
          <LinearGradient
            colors={["#08d4c4", "#01ab9d"]}
            style={GlobalStyles.requestBtn}
          >
            <Text style={GlobalStyles.requestTxt}>REQUEST</Text>
          </LinearGradient>
        </TouchableOpacity>
        <MapView
          style={styles.mapStyle}
          region={{
            latitude: location.currentLatitude,
            longitude: location.currentLongitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01
          }}
          showsCompass={true}
          rotateEnabled={false}
          showsUserLocation={true}
        >
          <Marker
            backgroundColor="tomato"
            coordinate={{
              latitude: location.currentLatitude,
              longitude: location.currentLongitude
            }}
          />
        </MapView>
        <StatusBar style="light" />
      </View>
    );
  } else {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="green"></ActivityIndicator>
        <Text>{isLoading.message}</Text>
      </View>
    );
  }
}
const Stack = createStackNavigator();
function Home() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: "#009387",
            borderBottomWidth: 0
          },
          headerTintColor: "#fff",
          headerTitleStyle: { fontWeight: "bold" }
        }}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: "YOUR LOCATION",
            headerLeft: () => (
              <Icon.Button
                name="ios-camera"
                size={25}
                backgroundColor="#009387"
              ></Icon.Button>
            ),
            headerRight: () => (
              <Icon.Button
                name="ios-menu"
                size={25}
                backgroundColor="#009387"
                onPress={() => {
                  HomeScreen.confirmDialog();
                }}
              ></Icon.Button>
            )
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  mapStyle: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height
  }
});
export default Home;


import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
//import MapView from 'react-native-maps';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {MapView, Permissions} from 'expo';
import Icon from 'react-native-vector-icons/Ionicons'

import HomeScreen from './Login';
import Registration from './Registration';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { AuthContext } from '../components/context'
const HomeStack = createStackNavigator();
const RegisterStack = createStackNavigator();
const Tab = createMaterialBottomTabNavigator();
const MainTabScreen = ()=>(
  //const { signIn } = React.useContext(AuthContext);
  (<Tab.Navigator initialRouteName="Home" activeColor="#fff" >
    <Tab.Screen name="Home" component={HomeStackScreen}
      options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({ color }) => (
          <Icon name="ios-home" color={color} size={26} />
        ),
      }}/>
    <Tab.Screen name="Notifications" component={RegisterStackScreen}
      options={{
        tabBarLabel: 'Profile',
        tabBarIcon: ({ color }) => (
          <Icon name="ios-person" color={color} size={26} />
        ),
      }}/>
  </Tab.Navigator>
  )
)
export default MainTabScreen;
const HomeStackScreen = ({navigation})=>(
  <HomeStack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
      <HomeStack.Screen name="WELCOME" component={HomeScreen} options={{title:'CURRENT LOCATION', headerRight: () =>(<Icon.Button name="ios-menu" size={25} backgroundColor="#009387" onPress={()=>navigation.toggleDrawer()}></Icon.Button>) }}/>
  </HomeStack.Navigator>
)
const RegisterStackScreen = ({navigation})=>(
  <RegisterStack.Navigator screenOptions={{headerStyle:{ backgroundColor:'#009387',},headerTintColor:'#fff',headerTitleStyle:{fontWeight:'bold',}}}>
      <RegisterStack.Screen name="Register" component={Registration} />
  </RegisterStack.Navigator>
)
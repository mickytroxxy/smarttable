import socketIOClient from "socket.io-client";
const ENDPOINT = "http://192.168.1.27:4400";
export const socket = socketIOClient(ENDPOINT);